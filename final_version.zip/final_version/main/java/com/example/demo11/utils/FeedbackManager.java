package com.example.demo11.utils;

import com.example.demo11.config.APIConfig;
import javax.swing.*;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Utility class to manage feedback operations including ratings and comments
 */
public class FeedbackManager {
    
    /**
     * Submits feedback (rating or comment) to the backend API
     *
     * @param responseId The ID of the response being rated/commented on
     * @param rating The star rating (1-5) or null if not rating
     * @param comment The user comment or null if not commenting
     * @return True if the API call was successful, false otherwise
     */
    public static boolean submitFeedback(String responseId, Integer rating, String comment) {
        // Validate responseId - do not continue if it's not valid
        if (responseId == null || responseId.isEmpty()) {
            System.err.println("ERROR: Cannot submit feedback without a valid response ID");
            return false;
        }
        
        System.out.println("Processing feedback for response ID: " + responseId);
        
        // Extract numeric ID if the ID contains non-numeric parts
        String numericId = responseId;
        if (!responseId.matches("\\d+")) {
            // Try to extract numeric portion for the API
            try {
                // Look for numeric ID in formats like "resp_sessionId_12345" or 
                // JSON formats like {"id":12345}
                if (responseId.contains("_")) {
                    String[] parts = responseId.split("_");
                    // Take the last part if it's numeric
                    if (parts.length > 0 && parts[parts.length-1].matches("\\d+")) {
                        numericId = parts[parts.length-1];
                    }
                } else if (responseId.contains("\"result\"") && responseId.contains("\"id\"")) {
                    // Handle nested result object format: {"status":"success","result":{"id":345,...}}
                    java.util.regex.Pattern nestedPattern = 
                        java.util.regex.Pattern.compile("\"result\"\\s*:\\s*\\{.*?\"id\"\\s*:\\s*(\\d+)");
                    java.util.regex.Matcher nestedMatcher = nestedPattern.matcher(responseId);
                    if (nestedMatcher.find()) {
                        numericId = nestedMatcher.group(1);
                        System.out.println("Extracted ID from nested result object: " + numericId);
                    }
                } else if (responseId.contains("\"id\"")) {
                    // Try to extract from JSON {"id":"12345"}
                    int idIndex = responseId.indexOf("\"id\"");
                    if (idIndex >= 0) {
                        int valueStart = responseId.indexOf(":", idIndex) + 1;
                        // Skip whitespace and quotes
                        while (valueStart < responseId.length() && 
                               (responseId.charAt(valueStart) == ' ' || 
                                responseId.charAt(valueStart) == '"')) {
                            valueStart++;
                        }
                        
                        int valueEnd = valueStart;
                        while (valueEnd < responseId.length() && 
                               Character.isDigit(responseId.charAt(valueEnd))) {
                            valueEnd++;
                        }
                        
                        if (valueEnd > valueStart) {
                            numericId = responseId.substring(valueStart, valueEnd);
                            if (!numericId.matches("\\d+")) {
                                numericId = responseId; // Revert if not numeric
                            }
                        }
                    }
                }
                
                if (!numericId.equals(responseId)) {
                    System.out.println("Using numeric ID for feedback API: " + numericId + 
                                     " (original: " + responseId + ")");
                }
            } catch (Exception e) {
                System.err.println("Error extracting numeric ID: " + e.getMessage());
                // Continue with original ID
                numericId = responseId;
            }
        }
        
        // Validate the extracted ID
        if (!numericId.matches("\\d+")) {
            System.err.println("WARNING: Extracted ID is not numeric: " + numericId);
            // Try one last method - extract any number in the string
            try {
                java.util.regex.Pattern numPattern = java.util.regex.Pattern.compile("(\\d+)");
                java.util.regex.Matcher numMatcher = numPattern.matcher(responseId);
                if (numMatcher.find()) {
                    String foundNumber = numMatcher.group(1);
                    System.out.println("Extracted number from response ID: " + foundNumber);
                    numericId = foundNumber;
                }
            } catch (Exception e) {
                System.err.println("Error extracting any number from ID: " + e.getMessage());
            }
        }
        
        // Store final responseId for use in lambda
        final String finalResponseId = numericId;
        
        // Run the API call in a background thread to avoid freezing the UI
        SwingWorker<Boolean, Void> worker = new SwingWorker<Boolean, Void>() {
            @Override
            protected Boolean doInBackground() throws Exception {
                try {
                    // Create API call to submit feedback
                    String endpoint = APIConfig.FEEDBACK_ENDPOINT;
                    URL url = new URL(endpoint);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(5000);
                    connection.setReadTimeout(5000);
                    connection.setRequestProperty("Content-Type", "application/json");
                    connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
                    connection.setDoOutput(true);
                    
                    // Prepare payload data - use only the numeric ID without quotes for numeric types
                    StringBuilder payloadBuilder = new StringBuilder();
                    if (finalResponseId.matches("\\d+")) {
                        // If ID is numeric, don't quote it
                        payloadBuilder.append("{\"response_id\": ").append(finalResponseId);
                    } else {
                        // If ID is not numeric (unlikely at this point), quote it
                        payloadBuilder.append("{\"response_id\": \"").append(finalResponseId).append("\"");
                    }
                    
                    // Add session ID to help with tracking
                    String sessionId = com.example.demo11.SidepanelFactory.getSessionId();
                    if (sessionId != null && !sessionId.isEmpty()) {
                        payloadBuilder.append(", \"session_id\": \"").append(sessionId).append("\"");
                    }
                    
                    // Add rating if provided
                    if (rating != null) {
                        payloadBuilder.append(", \"rating\": ").append(rating);
                    }
                    
                    // Add comment if provided
                    if (comment != null && !comment.isEmpty()) {
                        // Clean the comment for JSON
                        String cleanedComment = comment.replace("\"", "\\\"")
                                                      .replace("\n", "\\n")
                                                      .replace("\r", "\\r");
                        payloadBuilder.append(", \"comment\": \"").append(cleanedComment).append("\"");
                    }
                    
                    // Close JSON object
                    payloadBuilder.append("}");
                    
                    String jsonPayload = payloadBuilder.toString();
                    System.out.println("Sending feedback: " + jsonPayload);
                    
                    try (OutputStream os = connection.getOutputStream()) {
                        byte[] input = jsonPayload.getBytes("utf-8");
                        os.write(input, 0, input.length);
                    }
                    
                    int responseCode = connection.getResponseCode();
                    
                    if (responseCode != 200) {
                        System.err.println("Failed to submit feedback: HTTP " + responseCode);
                        return false;
                    } else {
                        String feedbackType = rating != null ? "Rating" : "Comment";
                        System.out.println(feedbackType + " submitted successfully");
                        return true;
                    }
                } catch (Exception e) {
                    System.err.println("Error submitting feedback: " + e.getMessage());
                    e.printStackTrace();
                    return false;
                }
            }
        };
        
        worker.execute();
        
        try {
            return worker.get(); // Wait for result
        } catch (Exception e) {
            System.err.println("Error waiting for feedback submission: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Submit just a rating
     */
    public static boolean submitRating(String responseId, int rating) {
        return submitFeedback(responseId, rating, null);
    }
    
    /**
     * Submit just a comment
     */
    public static boolean submitComment(String responseId, String comment) {
        return submitFeedback(responseId, null, comment);
    }
} 