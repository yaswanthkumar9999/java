package com.example.demo11.ui;

import com.example.demo11.api.SessionHistory;
import com.example.demo11.api.SessionHistoryWorker;
import com.example.demo11.api.ChatHistoryWorker;
import com.example.demo11.api.ChatHistoryWorker.ChatHistoryItem;
import com.example.demo11.utils.RoundedBorder;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.ArrayList;

public class HistoryPanel extends JPanel {
    private final JPanel historyContainer;
    private final JScrollPane scrollPane;
    private final ChatPanel chatPanel;
    private boolean isVisible = false;
    private HeaderPanel headerPanel;
    private static final int PADDING = 10;
    private static final Color BUBBLE_COLOR = new Color(70, 70, 70);
    private static final Color TEXT_COLOR = Color.WHITE;
    private static final Color DATE_COLOR = new Color(180, 180, 180);
    
    // Lazy loading variables
    private String currentSessionId = null;
    private int currentLimit = 0;
    private boolean isLoading = false;
    private boolean hasMoreData = true;
    private final List<ChatHistoryItem> loadedHistory = new ArrayList<>();
    private static final int CHUNK_SIZE = 5;
    private int totalMessageCount = 0; // Track total messages for current session
    private int lastVisibleItemCount = 0; // Track how many items we've added to UI

    public HistoryPanel(ChatPanel chatPanel, HeaderPanel headerPanel) {
        this.chatPanel = chatPanel;
        this.headerPanel = headerPanel;
        setLayout(new BorderLayout());
        setBackground(new Color(43, 43, 43));
        setVisible(false);

        historyContainer = new JPanel();
        historyContainer.setLayout(new BoxLayout(historyContainer, BoxLayout.Y_AXIS));
        historyContainer.setBackground(new Color(43, 43, 43));

        scrollPane = new JScrollPane(historyContainer);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        // Add scroll listener for lazy loading
        scrollPane.getVerticalScrollBar().addAdjustmentListener(e -> {
            if (!e.getValueIsAdjusting() && !isLoading && hasMoreData && currentSessionId != null) {
                JScrollBar scrollBar = (JScrollBar) e.getSource();
                int visibleHeight = scrollPane.getViewport().getHeight();
                int totalHeight = historyContainer.getPreferredSize().height;
                int scrollPosition = scrollBar.getValue();
                
                // Calculate how far down the user has scrolled (as a percentage)
                double scrollPercent = (double)(scrollPosition + visibleHeight) / totalHeight;
                
                // Load more when user is at 80% of loaded content
                if (scrollPercent > 0.8) {
                    loadMoreHistory();
                }
            }
        });

        add(scrollPane, BorderLayout.CENTER);

        // Add comprehensive resize listener with debounce
        Timer resizeTimer = new Timer(150, e -> {
            updateBubbleSizes();
        });
        resizeTimer.setRepeats(false);
        
        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                // Restart the timer to debounce resize events
                resizeTimer.restart();
            }
        });
        
        // Add listener for bounds changes (for drag operations)
        addHierarchyBoundsListener(new java.awt.event.HierarchyBoundsAdapter() {
            @Override
            public void ancestorResized(java.awt.event.HierarchyEvent e) {
                // Also restart timer when ancestor is resized
                resizeTimer.restart();
            }
        });
    }

    public void toggleVisibility() {
        isVisible = !isVisible;
        setVisible(isVisible);
        
        if (isVisible) {
            // Always refresh session history when toggling visibility
            clearHistory();
            loadSessionHistory();
            headerPanel.showHistoryMode(true);
            
            // Hide category panel if history panel is shown
            CategoryPanel categoryPanel = com.example.demo11.SidepanelFactory.getCurrentCategoryPanel();
            if (categoryPanel != null) {
                categoryPanel.setVisible(false);
            }
        } else {
            headerPanel.showHistoryMode(false);
            clearHistory();
        }
        
        revalidate();
        repaint();
    }

    private void clearHistory() {
        historyContainer.removeAll();
        loadedHistory.clear();
        currentSessionId = null;
        currentLimit = 0;
        hasMoreData = true;
        isLoading = false;
        lastVisibleItemCount = 0;
    }

    public void loadSessionHistory() {
        historyContainer.removeAll();
        loadedHistory.clear();
        currentSessionId = null;
        currentLimit = 0;
        hasMoreData = true;
        isLoading = false;
        
        try {
            List<SessionHistory> sessionHistoryList = SessionHistoryWorker.getSessionHistory();
            
            if (sessionHistoryList.isEmpty()) {
                JLabel noHistoryLabel = new JLabel("No chat history found", SwingConstants.CENTER);
                noHistoryLabel.setForeground(Color.WHITE);
                historyContainer.add(noHistoryLabel);
            } else {
                for (SessionHistory session : sessionHistoryList) {
                    addHistoryBubble(session);
                }
            }
            
            historyContainer.revalidate();
            historyContainer.repaint();
            
        } catch (Exception e) {
            JLabel errorLabel = new JLabel("Error loading history: " + e.getMessage(), SwingConstants.CENTER);
            errorLabel.setForeground(Color.RED);
            historyContainer.add(errorLabel);
            e.printStackTrace();
        }
    }

    private void addHistoryBubble(SessionHistory session) {
        JPanel bubble = createHistoryBubble(session);
        
        // Simple wrapper with padding
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.add(bubble, BorderLayout.CENTER);
        wrapper.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        
        historyContainer.add(wrapper);
        historyContainer.add(Box.createVerticalStrut(5));
    }

    private JPanel createHistoryBubble(SessionHistory session) {
        // Main wrapper panel that will contain both bubble and confirmation buttons
        JPanel wrapperPanel = new JPanel(new BorderLayout());
        wrapperPanel.setOpaque(false);
        
        // Bubble panel for session info
        JPanel bubblePanel = new JPanel(new BorderLayout());
        bubblePanel.setBackground(BUBBLE_COLOR);
        bubblePanel.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(1, 10, new Color(90, 90, 90), null, false),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // Create content panel for session info
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setOpaque(false);
        
        // Session name (first prompt)
        JLabel nameLabel = new JLabel(session.getDisplayName());
        nameLabel.setName("session_" + session.getSessionId()); // Add name for identification
        nameLabel.setForeground(TEXT_COLOR);
        nameLabel.setFont(new Font(nameLabel.getFont().getName(), Font.BOLD, 14));
        nameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Created date
        JLabel dateLabel = new JLabel(session.getCreatedDate());
        dateLabel.setForeground(DATE_COLOR);
        dateLabel.setFont(new Font(dateLabel.getFont().getName(), Font.PLAIN, 12));
        dateLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Add content to panel
        contentPanel.add(nameLabel);
        contentPanel.add(Box.createVerticalStrut(5));
        contentPanel.add(dateLabel);
        
        // Delete icon
        ImageIcon deleteIcon = new ImageIcon(getClass().getResource("/icons/delete.png"));
        Image deleteImg = deleteIcon.getImage().getScaledInstance(16, 16, Image.SCALE_SMOOTH);
        JButton deleteButton = new JButton(new ImageIcon(deleteImg));
        deleteButton.setBorderPainted(false);
        deleteButton.setContentAreaFilled(false);
        deleteButton.setFocusPainted(false);
        deleteButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        deleteButton.setToolTipText("Delete session");
        
        // Store session ID directly on the bubble panel for easier retrieval
        bubblePanel.putClientProperty("sessionId", session.getSessionId());
        
        // Create confirmation panel (initially hidden)
        JPanel confirmPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        confirmPanel.setOpaque(false);
        confirmPanel.setVisible(false);
        
        // Done button
        ImageIcon doneIcon = new ImageIcon(getClass().getResource("/icons/done.jfif"));
        Image doneImg = doneIcon.getImage().getScaledInstance(16, 16, Image.SCALE_SMOOTH);
        JButton doneButton = new JButton(new ImageIcon(doneImg));
        doneButton.setBorderPainted(false);
        doneButton.setContentAreaFilled(false);
        doneButton.setFocusPainted(false);
        doneButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        doneButton.setToolTipText("Confirm delete");
        
        // Cancel button
        ImageIcon cancelIcon = new ImageIcon(getClass().getResource("/icons/cancel.jpg"));
        Image cancelImg = cancelIcon.getImage().getScaledInstance(16, 16, Image.SCALE_SMOOTH);
        JButton cancelButton = new JButton(new ImageIcon(cancelImg));
        cancelButton.setBorderPainted(false);
        cancelButton.setContentAreaFilled(false);
        cancelButton.setFocusPainted(false);
        cancelButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        cancelButton.setToolTipText("Cancel delete");
        
        // Add buttons to confirmation panel
        confirmPanel.add(doneButton);
        confirmPanel.add(cancelButton);
        
        // Add components to bubble
        bubblePanel.add(contentPanel, BorderLayout.CENTER);
        bubblePanel.add(deleteButton, BorderLayout.EAST);
        
        // Add bubble to wrapper panel
        wrapperPanel.add(bubblePanel, BorderLayout.CENTER);
        
        // Add click listener for the bubblePanel only
        bubblePanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Intercept click event if it's not on the delete button
                Point clickPoint = SwingUtilities.convertPoint(e.getComponent(), e.getPoint(), deleteButton.getParent());
                
                if (!deleteButton.getBounds().contains(clickPoint)) {
                    // Get sessionId from client property
                    String sessionId = (String) bubblePanel.getClientProperty("sessionId");
                    System.out.println("Clicked on session bubble with ID: " + sessionId);
                    loadChatHistory(sessionId, session.getCount());
                    e.consume(); // Prevent event from propagating
                }
            }
            
            @Override
            public void mouseEntered(MouseEvent e) {
                bubblePanel.setCursor(new Cursor(Cursor.HAND_CURSOR));
                bubblePanel.setBackground(new Color(80, 80, 80));
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                bubblePanel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                bubblePanel.setBackground(BUBBLE_COLOR);
            }
        });
        
        // Delete button action
        deleteButton.addActionListener(e -> {
            // Hide the delete button
            deleteButton.setVisible(false);
            
            // Move bubble to left by setting preferred sizes and constraints
            bubblePanel.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(1, 10, new Color(90, 90, 90), null, false),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
            ));
            
            // Remove center constraint and add to west to move bubble left
            wrapperPanel.remove(bubblePanel);
            wrapperPanel.add(bubblePanel, BorderLayout.WEST);
            
            // Add confirmation panel to the right
            wrapperPanel.add(confirmPanel, BorderLayout.EAST);
            confirmPanel.setVisible(true);
            
            wrapperPanel.revalidate();
            wrapperPanel.repaint();
        });
        
        // Done button action
        doneButton.addActionListener(e -> {
            try {
                boolean success = SessionHistoryWorker.deleteSession(session.getSessionId());
                if (success) {
                    // Remove this session bubble
                    Container parent = wrapperPanel.getParent();
                    if (parent != null) {
                        Container wrapper = parent.getParent();
                        if (wrapper == historyContainer) {
                            // If this was the current session being displayed, clear it first
                            if (session.getSessionId().equals(currentSessionId)) {
                                // Find all components to remove - all components after this session until next session
                                Component[] allComponents = historyContainer.getComponents();
                                List<Component> toRemove = new ArrayList<>();
                                
                                // Find index of this session panel
                                int sessionIndex = -1;
                                for (int i = 0; i < allComponents.length; i++) {
                                    if (allComponents[i] == parent) {
                                        sessionIndex = i;
                                        break;
                                    }
                                }
                                
                                if (sessionIndex != -1) {
                                    // Find next session position
                                    int nextSessionPos = -1;
                                    for (int i = sessionIndex + 1; i < allComponents.length; i++) {
                                        if (allComponents[i] instanceof JPanel) {
                                            JPanel panelToCheck = (JPanel) allComponents[i];
                                            if (isSessionBubble(panelToCheck)) {
                                                nextSessionPos = i;
                                                break;
                                            }
                                        }
                                    }
                                    
                                    // Add all components between session and next session (or end) to removal list
                                    int endPos = nextSessionPos != -1 ? nextSessionPos : allComponents.length;
                                    for (int i = sessionIndex + 1; i < endPos; i++) {
                                        toRemove.add(allComponents[i]);
                                    }
                                    
                                    // Remove all these components
                                    for (Component compToRemove : toRemove) {
                                        historyContainer.remove(compToRemove);
                                    }
                                }
                                
                                // Reset session state
                                currentSessionId = null;
                                currentLimit = 0;
                                hasMoreData = true;
                                isLoading = false;
                                loadedHistory.clear();
                                lastVisibleItemCount = 0;
                            }
                            
                            // Find the wrapper and the strut that follows it
                            Component[] components = historyContainer.getComponents();
                            for (int i = 0; i < components.length - 1; i++) {
                                if (components[i] == parent) {
                                    historyContainer.remove(components[i]); // Remove wrapper
                                    if (i+1 < components.length && components[i+1] instanceof Box.Filler) {
                                        historyContainer.remove(components[i+1]); // Remove strut
                                    }
                                    break;
                                }
                            }
                            historyContainer.revalidate();
                            historyContainer.repaint();
                        }
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(
                    bubblePanel,
                    "Failed to delete session: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> {
            // Make delete button visible again
            deleteButton.setVisible(true);
            
            // Move bubble back to center
            wrapperPanel.remove(bubblePanel);
            wrapperPanel.add(bubblePanel, BorderLayout.CENTER);
            
            // Hide confirmation panel
            wrapperPanel.remove(confirmPanel);
            confirmPanel.setVisible(false);
            
            wrapperPanel.revalidate();
            wrapperPanel.repaint();
        });
        
        return wrapperPanel;
    }

    private void loadChatHistory(String sessionId, int totalCount) {
        // If clicking the same session, remove its history
        if (sessionId.equals(currentSessionId)) {
            removeHistoryForSession(sessionId);
            currentSessionId = null;
            return;
        }
        
        // Store the previous session ID
        String previousSessionId = currentSessionId;
        
        // Update current session ID without removing previous history
        currentSessionId = sessionId;
        currentLimit = 0;
        totalMessageCount = totalCount; // Set the total message count
        loadedHistory.clear();
        lastVisibleItemCount = 0;
        
        // Determine if there should be more data based on total count
        hasMoreData = totalMessageCount > 0;
        
        // For debugging
        System.out.println("Loading chat history for session: " + sessionId + " with count: " + totalCount);
        
        // Find the clicked session bubble and add chat history below it
        Component[] components = historyContainer.getComponents();
        int insertPosition = -1;
        
        for (int i = 0; i < components.length; i++) {
            if (components[i] instanceof JPanel) {
                JPanel wrapper = (JPanel) components[i];
                if (wrapper.getComponentCount() > 0) {
                    Component innerComp = wrapper.getComponent(0);
                    if (innerComp instanceof JPanel) {
                        JPanel wrapperPanel = (JPanel) innerComp;
                        
                        // Navigate through the component hierarchy to find bubblePanel
                        for (Component wp : wrapperPanel.getComponents()) {
                            if (wp instanceof JPanel) {
                                JPanel bubblePanel = (JPanel) wp;
                                
                                // Use the client property we added directly to the bubblePanel
                                String bpSessionId = (String) bubblePanel.getClientProperty("sessionId");
                                if (sessionId.equals(bpSessionId)) {
                                    System.out.println("Found session bubble at position: " + i);
                                    insertPosition = i;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if (insertPosition != -1) break;
        }
        
        if (insertPosition == -1) {
            System.out.println("Could not find session bubble for session ID: " + sessionId);
            return;
        }
        
        // Add a separator after the session
        historyContainer.add(Box.createVerticalStrut(10), insertPosition + 1);
        
        // Add loading indicator
        JLabel loadingLabel = new JLabel("Loading chat history...");
        loadingLabel.setForeground(Color.WHITE);
        loadingLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        historyContainer.add(loadingLabel, insertPosition + 2);
        
        historyContainer.revalidate();
        historyContainer.repaint();
        
        // Load initial chunk
        loadMoreHistory();
    }

    private void loadMoreHistory() {
        if (isLoading || !hasMoreData || currentSessionId == null) return;
        
        isLoading = true;
        System.out.println("Loading more history. Current loaded count: " + loadedHistory.size() + ", Total count: " + totalMessageCount);
        
        try {
            // Calculate how many messages we've loaded so far
            int loadedCount = loadedHistory.size();
            
            // Check if we've already loaded everything
            if (loadedCount >= totalMessageCount) {
                hasMoreData = false;
                isLoading = false;
                System.out.println("All messages loaded. No more API calls needed.");
                return;
            }
            
            // Determine how many more items we can load (to avoid multiple API calls for small counts)
            int itemsRemaining = totalMessageCount - loadedCount;
            int adjustedChunkSize = Math.min(CHUNK_SIZE, itemsRemaining);
            
            System.out.println("Making API call with limit=" + currentLimit + ", chunk size=" + adjustedChunkSize);
            
            // Load the next chunk
            List<ChatHistoryItem> newItems = ChatHistoryWorker.getChatHistory(currentSessionId, adjustedChunkSize, currentLimit);
            
            if (newItems.isEmpty()) {
                hasMoreData = false;
                isLoading = false;
                System.out.println("No more items returned from API.");
                return;
            }
            
            loadedHistory.addAll(newItems);
            currentLimit++;
            
            // Update hasMoreData based on how many messages we've loaded versus total count
            hasMoreData = loadedHistory.size() < totalMessageCount;
            
            // Find the loading indicator and remove it
            Component[] components = historyContainer.getComponents();
            for (int i = 0; i < components.length; i++) {
                if (components[i] instanceof JLabel && 
                    ((JLabel) components[i]).getText().equals("Loading chat history...")) {
                    historyContainer.remove(i);
                    break;
                }
            }
            
            // Add new items to the container
            for (ChatHistoryItem item : newItems) {
                addChatHistoryItem(item);
                lastVisibleItemCount++;
            }
            
            System.out.println("Added " + newItems.size() + " items. Total loaded: " + loadedHistory.size() + "/" + totalMessageCount);
            System.out.println("Has more data: " + hasMoreData);
            
            historyContainer.revalidate();
            historyContainer.repaint();
            
        } catch (Exception e) {
            System.out.println("Error loading history: " + e.getMessage());
            e.printStackTrace();
        } finally {
            isLoading = false;
        }
    }

    private void addChatHistoryItem(ChatHistoryItem item) {
        // Find the position after the clicked session
        Component[] components = historyContainer.getComponents();
        int insertPosition = -1;
        
        // First find the session position
        System.out.println("Looking for session: " + currentSessionId + " to add chat item");
        
        for (int i = 0; i < components.length; i++) {
            if (components[i] instanceof JPanel) {
                JPanel wrapper = (JPanel) components[i];
                if (wrapper.getComponentCount() > 0) {
                    Component innerComp = wrapper.getComponent(0);
                    if (innerComp instanceof JPanel) {
                        JPanel wrapperPanel = (JPanel) innerComp;
                        
                        // Navigate through the component hierarchy to find bubblePanel
                        for (Component wp : wrapperPanel.getComponents()) {
                            if (wp instanceof JPanel) {
                                JPanel bubblePanel = (JPanel) wp;
                                
                                // Use the client property we added directly to the bubblePanel
                                String bpSessionId = (String) bubblePanel.getClientProperty("sessionId");
                                if (currentSessionId.equals(bpSessionId)) {
                                    System.out.println("Found session bubble at position: " + i);
                                    insertPosition = i;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if (insertPosition != -1) break;
        }
        
        if (insertPosition == -1) {
            System.out.println("Could not find session bubble for current session: " + currentSessionId);
            return; // Session not found
        }
        
        // Determine where to insert based on how many items we've already loaded
        int offset = 2 + (lastVisibleItemCount * 6); // 2 for initial strut + loading label, 6 components per history item
        insertPosition += offset;
        
        System.out.println("Adding chat history item at position: " + insertPosition + 
            " (lastVisibleItemCount=" + lastVisibleItemCount + ")");
        
        // Create user message bubble
        JPanel userBubble = chatPanel.createMessageBubble(
            "You",
            "/icons/user.png",
            item.getPrompt(),
            true
        );
        
        // Create wrapper for user bubble
        JPanel userWrapper = new JPanel(new BorderLayout());
        userWrapper.setOpaque(false);
        userWrapper.add(userBubble, BorderLayout.CENTER);
        userWrapper.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        // Make transparent but preserve sizing properties
        makeTransparentPreservingSizing(userBubble);
        
        // Add to history container
        historyContainer.add(userWrapper, insertPosition);
        historyContainer.add(Box.createVerticalStrut(5), insertPosition + 1);
        
        // Create assistant message bubble
        JPanel assistantBubble = chatPanel.createMessageBubble(
            "Assistant",
            "/icons/assistant.png",
            item.getResponse(),
            false
        );
        
        // Create wrapper for assistant bubble
        JPanel assistantWrapper = new JPanel(new BorderLayout());
        assistantWrapper.setOpaque(false);
        assistantWrapper.add(assistantBubble, BorderLayout.CENTER);
        assistantWrapper.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        // Make transparent but preserve sizing properties
        makeTransparentPreservingSizing(assistantBubble);
        
        // Add to history container
        historyContainer.add(assistantWrapper, insertPosition + 2);
        historyContainer.add(Box.createVerticalStrut(5), insertPosition + 3);
        
        // Always add feedback panel, even if rating and feedback are null
        JPanel feedbackPanel = chatPanel.createFeedbackPanel(
            item.getId(),
            item.getRating(),
            item.getFeedback()
        );
        makeTransparentPreservingSizing(feedbackPanel);
        historyContainer.add(feedbackPanel, insertPosition + 4);
        historyContainer.add(Box.createVerticalStrut(5), insertPosition + 5);
        
        // Force bubble sizing right after adding
        int panelWidth = getWidth();
        if (panelWidth > 0) {
            JTextArea userTextArea = findTextAreaInPanel(userBubble);
            if (userTextArea != null) {
                resizeBubbleToFitContent(userBubble, userTextArea, item.getPrompt(), panelWidth);
            }
            
            JTextArea assistantTextArea = findTextAreaInPanel(assistantBubble);
            if (assistantTextArea != null) {
                resizeBubbleToFitContent(assistantBubble, assistantTextArea, item.getResponse(), panelWidth);
            }
        }
        
        historyContainer.revalidate();
        historyContainer.repaint();
    }

    // Modified transparency method that preserves sizing properties
    private void makeTransparentPreservingSizing(Component component) {
        if (component instanceof JPanel) {
            JPanel panel = (JPanel) component;
            panel.setOpaque(false);
            
            // Process children
            for (Component child : panel.getComponents()) {
                makeTransparentPreservingSizing(child);
            }
        } else if (component instanceof JScrollPane) {
            JScrollPane scrollPane = (JScrollPane) component;
            scrollPane.setOpaque(false);
            scrollPane.getViewport().setOpaque(false);
            
            // Process viewport view
            Component view = scrollPane.getViewport().getView();
            if (view != null) {
                makeTransparentPreservingSizing(view);
            }
        } else if (component instanceof JTextArea) {
            JTextArea textArea = (JTextArea) component;
            textArea.setOpaque(false);
            // Preserve text wrapping settings
            textArea.setLineWrap(true);
            textArea.setWrapStyleWord(true);
        } else if (component instanceof JLabel) {
            ((JLabel) component).setOpaque(false);
        } else if (component instanceof Container) {
            Container container = (Container) component;
            if (container instanceof JComponent) {
                ((JComponent) container).setOpaque(false);
            }
            
            // Process children
            for (Component child : container.getComponents()) {
                makeTransparentPreservingSizing(child);
            }
        }
    }

    private void resizeBubbleToFitContent(JPanel bubblePanel, JTextArea textArea, String message, int panelWidth) {
        if (message == null || message.isEmpty()) return;
        
        // Create a temporary text area to measure text dimensions
        JTextArea measureArea = new JTextArea();
        measureArea.setFont(textArea.getFont());
        measureArea.setLineWrap(true);
        measureArea.setWrapStyleWord(true);
        measureArea.setColumns(1); // Start with minimum columns
        measureArea.setText(message);
        
        // Calculate maximum allowed width (90% of panel width to account for scrollbar)
        int maxAllowedWidth = (int)(panelWidth * 0.9);
        
        // Calculate required width based on text content
        int requiredWidth = Math.min(maxAllowedWidth, Math.max(50, measureArea.getPreferredSize().width + PADDING));
        
        // Calculate required height based on text content
        int requiredHeight = measureArea.getPreferredSize().height + PADDING;
        
        // Update text area width first
        int textAreaWidth = requiredWidth - PADDING;
        textArea.setSize(new Dimension(textAreaWidth, 10)); // Force wrapping calculation
        
        // Get preferred size after wrapping
        Dimension prefSize = textArea.getPreferredSize();
        
        // Update text area size
        textArea.setPreferredSize(new Dimension(textAreaWidth, prefSize.height));
        textArea.setMaximumSize(new Dimension(textAreaWidth, Integer.MAX_VALUE));
        
        // Update bubble panel size
        bubblePanel.setPreferredSize(new Dimension(requiredWidth, prefSize.height + PADDING * 2));
        bubblePanel.setMaximumSize(new Dimension(requiredWidth, Integer.MAX_VALUE));
        
        // Force immediate layout update
        textArea.invalidate();
        textArea.revalidate();
        textArea.doLayout();
        textArea.repaint();
        
        bubblePanel.invalidate();
        bubblePanel.revalidate();
        bubblePanel.doLayout();
        bubblePanel.repaint();
        
        // Update parent containers (scrollpanes, panels, etc.)
        Component parent = textArea.getParent();
        while (parent != null && parent != bubblePanel) {
            if (parent instanceof JComponent) {
                JComponent component = (JComponent) parent;
                
                // Special handling for scroll pane
                if (parent instanceof JScrollPane) {
                    component.setPreferredSize(new Dimension(textAreaWidth, prefSize.height + 5));
                } else {
                    component.setPreferredSize(new Dimension(textAreaWidth, prefSize.height));
                }
                
                component.setMaximumSize(new Dimension(textAreaWidth, Integer.MAX_VALUE));
                component.invalidate();
                component.revalidate();
                component.doLayout();
                component.repaint();
            }
            parent = parent.getParent();
        }
    }

    // Helper method to remove history items for a specific session
    private void removeHistoryForSession(String sessionId) {
        Component[] components = historyContainer.getComponents();
        List<Component> toRemove = new ArrayList<>();
        
        // Find the session position
        int sessionPos = -1;
        
        // Print debugging info
        System.out.println("Removing history for session: " + sessionId);
        
        for (int i = 0; i < components.length; i++) {
            if (components[i] instanceof JPanel) {
                JPanel wrapper = (JPanel) components[i];
                if (wrapper.getComponentCount() > 0) {
                    Component innerComp = wrapper.getComponent(0);
                    if (innerComp instanceof JPanel) {
                        JPanel wrapperPanel = (JPanel) innerComp;
                        
                        // Navigate through the component hierarchy to find bubblePanel
                        for (Component wp : wrapperPanel.getComponents()) {
                            if (wp instanceof JPanel) {
                                JPanel bubblePanel = (JPanel) wp;
                                
                                // Check sessionId in client property
                                String bpSessionId = (String) bubblePanel.getClientProperty("sessionId");
                                if (sessionId.equals(bpSessionId)) {
                                    sessionPos = i;
                                    System.out.println("Found session to remove at position: " + i);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if (sessionPos != -1) break;
        }
        
        if (sessionPos == -1) {
            System.out.println("Could not find session to remove: " + sessionId);
            return; // Session not found
        }
        
        // Find next session position
        int nextSessionPos = -1;
        for (int i = sessionPos + 1; i < components.length; i++) {
            if (components[i] instanceof JPanel) {
                JPanel wrapper = (JPanel) components[i];
                if (wrapper.getComponentCount() > 0) {
                    Component innerComp = wrapper.getComponent(0);
                    if (innerComp instanceof JPanel) {
                        JPanel wrapperPanel = (JPanel) innerComp;
                        
                        for (Component wp : wrapperPanel.getComponents()) {
                            if (wp instanceof JPanel) {
                                JPanel bubblePanel = (JPanel) wp;
                                
                                // Check if this is another session
                                String bpSessionId = (String) bubblePanel.getClientProperty("sessionId");
                                if (bpSessionId != null) {
                                    nextSessionPos = i;
                                    System.out.println("Found next session at position: " + i);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            if (nextSessionPos != -1) break;
        }
        
        // Collect all components between this session and next (or the end)
        int endPos = nextSessionPos != -1 ? nextSessionPos : components.length;
        System.out.println("Removing components from " + (sessionPos + 1) + " to " + (endPos - 1));
        
        for (int i = sessionPos + 1; i < endPos; i++) {
            toRemove.add(components[i]);
        }
        
        // Remove all collected components
        for (Component comp : toRemove) {
            historyContainer.remove(comp);
        }
        
        historyContainer.revalidate();
        historyContainer.repaint();
    }

    private void updateBubbleSizes() {
        int panelWidth = getWidth();
        if (panelWidth <= 0) return;
        
        // Use a timer to debounce resize events
        Timer resizeTimer = new Timer(150, e -> {
            resizeAllBubbles(panelWidth);
        });
        resizeTimer.setRepeats(false);
        resizeTimer.start();
    }
    
    private void resizeAllBubbles(int panelWidth) {
        // Process all components in the history container
        Component[] components = historyContainer.getComponents();
        for (Component comp : components) {
            if (comp instanceof JPanel) {
                JPanel wrapper = (JPanel) comp;
                for (Component bubbleComp : wrapper.getComponents()) {
                    if (bubbleComp instanceof JPanel) {
                        JPanel bubblePanel = (JPanel) bubbleComp;
                        
                        // Find any text areas in the bubble
                        JTextArea textArea = findTextAreaInPanel(bubblePanel);
                        if (textArea != null) {
                            // Get the text content
                            String message = textArea.getText();
                            resizeBubbleToFitContent(bubblePanel, textArea, message, panelWidth);
                        }
                    }
                }
            }
        }
        
        // Force layout updates
        historyContainer.revalidate();
        historyContainer.repaint();
        scrollPane.revalidate();
        scrollPane.repaint();
    }
    
    private JTextArea findTextAreaInPanel(Container container) {
        // First try direct search for JTextArea
        for (Component comp : container.getComponents()) {
            if (comp instanceof JTextArea) {
                return (JTextArea) comp;
            } else if (comp instanceof JScrollPane) {
                JScrollPane scrollPane = (JScrollPane) comp;
                Component view = scrollPane.getViewport().getView();
                if (view instanceof JTextArea) {
                    return (JTextArea) view;
                }
            } else if (comp instanceof Container) {
                // Recursive search in nested containers
                JTextArea textArea = findTextAreaInPanel((Container) comp);
                if (textArea != null) {
                    return textArea;
                }
            }
        }
        return null;
    }
    
    public JScrollPane getScrollPane() {
        return scrollPane;
    }
    
    // Override standard resize methods to ensure bubbles update properly
    @Override
    public void setBounds(int x, int y, int width, int height) {
        boolean sizeChanged = getWidth() != width || getHeight() != height;
        super.setBounds(x, y, width, height);
        
        if (sizeChanged) {
            SwingUtilities.invokeLater(this::updateBubbleSizes);
        }
    }
    
    @Override
    public void setSize(int width, int height) {
        boolean sizeChanged = getWidth() != width || getHeight() != height;
        super.setSize(width, height);
        
        if (sizeChanged) {
            SwingUtilities.invokeLater(this::updateBubbleSizes);
        }
    }
    
    @Override
    public void setSize(Dimension d) {
        boolean sizeChanged = getWidth() != d.width || getHeight() != d.height;
        super.setSize(d);
        
        if (sizeChanged) {
            SwingUtilities.invokeLater(this::updateBubbleSizes);
        }
    }
    
    @Override
    public void reshape(int x, int y, int width, int height) {
        boolean sizeChanged = getWidth() != width || getHeight() != height;
        super.reshape(x, y, width, height);
        
        if (sizeChanged) {
            SwingUtilities.invokeLater(this::updateBubbleSizes);
        }
    }
    
    @Override
    public void setPreferredSize(Dimension preferredSize) {
        super.setPreferredSize(preferredSize);
        SwingUtilities.invokeLater(this::updateBubbleSizes);
    }

    // Helper method to make a component and all its children transparent
    private void makeTransparent(Component component) {
        makeTransparentPreservingSizing(component);
    }

    // Helper method to check if a panel is a session bubble
    private boolean isSessionBubble(JPanel panel) {
        if (panel.getComponentCount() > 0) {
            Component innerComp = panel.getComponent(0);
            if (innerComp instanceof JPanel) {
                JPanel innerPanel = (JPanel) innerComp;
                
                for (Component comp : innerPanel.getComponents()) {
                    if (comp instanceof JPanel) {
                        JPanel bubblePanel = (JPanel) comp;
                        // Check if it has the sessionId client property
                        if (bubblePanel.getClientProperty("sessionId") != null) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
} 