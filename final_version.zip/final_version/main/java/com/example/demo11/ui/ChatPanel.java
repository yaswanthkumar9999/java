package com.example.demo11.ui;

import com.example.demo11.utils.RoundedBorder;
import com.example.demo11.config.APIConfig;
import com.intellij.openapi.util.IconLoader;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.Border;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.HashSet;
import java.util.Set;
import java.util.HashMap;
import java.util.Map;

public class ChatPanel extends JPanel {
    private final JPanel messageContainer;
    private final JScrollPane scrollPane;
    private static final int MIN_BUBBLE_WIDTH = 50;
    private static final double BUBBLE_WIDTH_PERCENT = 0.95;
    private static final int MIN_TEXT_AREA_WIDTH = 50;
    private static final int MIN_COLUMNS = 3;
    private static final int CHAR_WIDTH = 8;
    private static final int LINE_HEIGHT = 20;
    private static final int PADDING = 5;
    
    // Add star icon variables
    private final Icon emptyStarIcon = IconLoader.getIcon("/icons/empty_star.png");
    private final Icon filledStarIcon = IconLoader.getIcon("/icons/filled_star.png");
    
    // Track message bubbles for updating when resized
    private final List<JPanel> messageBubbles = new ArrayList<>();
    
    // Track the currently selected bubble
    private JPanel selectedBubble = null;
    private final Color selectedColor = new Color(51, 153, 255); // Blue color for selection
    private final Color defaultBorderColor = new Color(169, 169, 169); // Default grey border

    // Colors for star rating
    private final Color starDefaultColor = Color.WHITE;
    private final Color starHoverColor = new Color(255, 215, 0); // Gold
    private final Color feedbackButtonColor = new Color(51, 153, 255); // Blue

    // Add these variables at the class level
    private JPanel currentStreamingBubble = null;
    private JTextArea currentStreamingTextArea = null;
    private StringBuilder streamingResponseBuilder = new StringBuilder();
    private boolean isStreaming = false;
    private JPanel currentStreamingWrapper = null;
    private JPanel temporaryStreamingBubble = null;
    private JTextArea temporaryStreamingTextArea = null;
    private boolean useTemporaryBubbleDuringStreaming = true;
    private long streamingStartTime = 0; // Track when streaming begins
    private int apiResponseCode = 200; // Default success code

    // Add this class level variable to track feedback already shown
    private final Set<String> displayedFeedbacks = new HashSet<>();
    
    // Add a Map to track response IDs per message to avoid duplicate feedback
    private final Map<JPanel, String> messageBubbleResponseIds = new HashMap<>();

    // Add a new variable to store the current category ID
    private int currentCategoryId = 1; // Default to Test (1)

    private String currentQuestion = ""; // Add this field at the class level with other fields
    private String currentModel = "default"; // Add this field to store the current model

    public ChatPanel() {
        setLayout(new BorderLayout());
        messageContainer = new JPanel();
        messageContainer.setLayout(new BoxLayout(messageContainer, BoxLayout.Y_AXIS));
        messageContainer.setOpaque(false);

        scrollPane = new JScrollPane(messageContainer);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        // Ensure scrolling works properly
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setBlockIncrement(64);

        // Add comprehensive resize listener with debounce
        Timer resizeTimer = new Timer(150, e -> {
            updateAllBubbleSizes();
            ensureContentVisible();
        });
        resizeTimer.setRepeats(false);
        
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                // Restart the timer to debounce resize events
                resizeTimer.restart();
            }
        });

        add(scrollPane, BorderLayout.CENTER);
    }
    
    private void updateAllBubbleSizes() {
        // Calculate new bubble width based on current panel width
        int panelWidth = getWidth();
        if (panelWidth <= 0) return; // Skip if panel not visible yet
        
        // Update all bubbles with consistent sizing
        for (JPanel wrapper : messageBubbles) {
            if (wrapper.getComponentCount() > 0) {
                Component bubbleComp = wrapper.getComponent(0);
                if (bubbleComp instanceof JPanel) {
                    JPanel bubblePanel = (JPanel)bubbleComp;
                    
                    // Get the text area using recursive search
                    JTextArea textArea = findTextAreaRecursively(bubblePanel);
                    if (textArea != null) {
                        // Measure the actual content
                        String message = textArea.getText();
                        resizeBubbleToFitContent(bubblePanel, textArea, message, panelWidth);
                    }
                }
            }
        }
        
        // Force layout updates
        messageContainer.revalidate();
        messageContainer.repaint();
        
        // Ensure scroll pane is updated
        scrollPane.revalidate();
        scrollPane.repaint();
    }
    
    private void resizeBubbleToFitContent(JPanel bubblePanel, JTextArea textArea, String message, int panelWidth) {
        if (message == null || message.isEmpty()) return;
        
        // Create a temporary text area to measure text dimensions
        JTextArea measureArea = new JTextArea();
        measureArea.setFont(textArea.getFont());
        measureArea.setLineWrap(true);
        measureArea.setWrapStyleWord(true);
        measureArea.setColumns(1); // Start with minimum columns
        measureArea.setText(message);
        
        // Calculate maximum allowed width (95% of panel width)
        int maxAllowedWidth = (int)(panelWidth * BUBBLE_WIDTH_PERCENT);
        
        // Calculate required width based on text content
        int requiredWidth = Math.min(maxAllowedWidth, Math.max(MIN_BUBBLE_WIDTH, measureArea.getPreferredSize().width + PADDING));
        
        // Calculate required height based on text content
        int requiredHeight = measureArea.getPreferredSize().height + PADDING;
        
        // Update bubble panel size
        bubblePanel.setPreferredSize(new Dimension(requiredWidth, requiredHeight));
        bubblePanel.setMaximumSize(new Dimension(requiredWidth, Integer.MAX_VALUE));
        
        // Update text area size
        int textAreaWidth = requiredWidth - PADDING;
        textArea.setPreferredSize(new Dimension(textAreaWidth, requiredHeight - PADDING));
        textArea.setMaximumSize(new Dimension(textAreaWidth, Integer.MAX_VALUE));
        
        // Force immediate layout update
        bubblePanel.revalidate();
        bubblePanel.repaint();
        
        // Update any parent container that might be holding the text area
        Container parent = textArea.getParent();
        while (parent != null && parent != bubblePanel) {
            if (parent instanceof JPanel) {
                JPanel panel = (JPanel) parent;
                panel.setPreferredSize(new Dimension(textAreaWidth, requiredHeight - PADDING));
                panel.invalidate();
            }
            parent = parent.getParent();
        }
    }

    // Override component resized to ensure bubbles update when chat panel resizes
    @Override
    public void setBounds(int x, int y, int width, int height) {
        boolean sizeChanged = getWidth() != width || getHeight() != height;
        super.setBounds(x, y, width, height);
        
        if (sizeChanged) {
            // Update bubble sizes after a slight delay to ensure layout is complete
            SwingUtilities.invokeLater(this::updateAllBubbleSizes);
        }
    }
    
    @Override
    public void setSize(int width, int height) {
        boolean sizeChanged = getWidth() != width || getHeight() != height;
        super.setSize(width, height);
        
        if (sizeChanged) {
            SwingUtilities.invokeLater(this::updateAllBubbleSizes);
        }
    }
    
    @Override
    public void setSize(Dimension d) {
        boolean sizeChanged = getWidth() != d.width || getHeight() != d.height;
        super.setSize(d);
        
        if (sizeChanged) {
            SwingUtilities.invokeLater(this::updateAllBubbleSizes);
        }
    }
    
    @Override
    public void reshape(int x, int y, int width, int height) {
        boolean sizeChanged = getWidth() != width || getHeight() != height;
        super.reshape(x, y, width, height);
        
        if (sizeChanged) {
            SwingUtilities.invokeLater(this::updateAllBubbleSizes);
        }
    }
    
    @Override
    public void setPreferredSize(Dimension preferredSize) {
        super.setPreferredSize(preferredSize);
        SwingUtilities.invokeLater(this::updateAllBubbleSizes);
    }

    // Add a method to ensure all content is visible after window resizes
    public void ensureContentVisible() {
        SwingUtilities.invokeLater(() -> {
            // Update all bubble sizes first
            updateAllBubbleSizes();
            
            // Force layout update
            messageContainer.invalidate();
            messageContainer.revalidate();
            messageContainer.repaint();
            
            // Ensure scrollpane layout is updated
            scrollPane.invalidate();
            scrollPane.revalidate();
            scrollPane.repaint();
            
            // Ensure parent container is updated
            Container parent = getParent();
            if (parent != null) {
                parent.invalidate();
                parent.revalidate();
                parent.repaint();
            }
        });
    }

    // Add method to create a simple temporary bubble for streaming
    private JPanel createTemporaryStreamingBubble(String sender, String iconPath, String initialText) {
        JPanel bubblePanel = new JPanel(new BorderLayout());
        bubblePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(defaultBorderColor, 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        bubblePanel.setOpaque(false);
        
        // Load icon
        Icon icon = IconLoader.getIcon(iconPath);
        if (icon == null) {
            icon = UIManager.getIcon("OptionPane.informationIcon");
        }

        // Create sender panel with icon
        JPanel senderPanel = new JPanel(new BorderLayout());
        senderPanel.setOpaque(false);
        
        Color nameColor = new Color(0, 102, 204);
        JLabel senderLabel = new JLabel(sender, icon, JLabel.RIGHT);
        senderLabel.setForeground(nameColor);
        senderLabel.setFont(new Font("Dialog", Font.BOLD, 12));
        senderLabel.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
        senderPanel.add(senderLabel, BorderLayout.EAST);
        
        // Add sender panel to the top of the bubble
        bubblePanel.add(senderPanel, BorderLayout.NORTH);
        
        // Create simple text area for streaming indication
        JTextArea textArea = new JTextArea(initialText);
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setBackground(new Color(0, 0, 0, 0));
        textArea.setForeground(Color.WHITE);
        textArea.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        textArea.setOpaque(false);
        
        // Keep a reference to this text area
        temporaryStreamingTextArea = textArea;
        
        // Create scroll pane for text area
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        
        // Add to bubble
        bubblePanel.add(scrollPane, BorderLayout.CENTER);
        
        return bubblePanel;
    }

    // Recursive search for text areas - needed for streaming responses
    private JTextArea findTextAreaRecursively(Container container) {
        // First try direct access by component name
        for (Component comp : container.getComponents()) {
            if (comp instanceof JTextArea) {
                return (JTextArea) comp;
            } else if (comp instanceof JScrollPane) {
                JScrollPane scrollPane = (JScrollPane) comp;
                Component view = scrollPane.getViewport().getView();
                if (view instanceof JTextArea) {
                    return (JTextArea) view;
                }
            } else if (comp instanceof Container) {
                JTextArea textArea = findTextAreaRecursively((Container) comp);
                if (textArea != null) {
                    return textArea;
                }
            }
        }
        return null;
    }

    /**
     * Handles selection of a message bubble.
     * Changes the border color to blue for the selected bubble and
     * restores the original grey color for any previously selected bubble.
     *
     * @param bubble The bubble panel to select
     */
    private void selectBubble(JPanel bubble) {
        // If the same bubble is clicked again, do nothing
        if (bubble == selectedBubble) {
            return;
        }
        
        // Reset previous selection if any
        if (selectedBubble != null) {
            selectedBubble.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(defaultBorderColor, 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));
        }
        
        // Update new selection
        bubble.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(selectedColor, 2), // Make blue border slightly thicker
            BorderFactory.createEmptyBorder(4, 4, 4, 4)      // Adjust inner padding to maintain size
        ));
        
        // Update selected bubble reference
        selectedBubble = bubble;
        
        // Refresh display
        messageContainer.revalidate();
        messageContainer.repaint();
    }

    /**
     * Fallback method to save response directly via HTTP if reflection fails
     * @return The response ID if save was successful, null otherwise
     */
    private String saveResponseDirectly(String sessionId, String response, String responseId, long timeTaken) {
        try {
            System.out.println("Attempting direct save of response");
            // Get configuration from APIConfig
            String endpoint = APIConfig.HISTORY_ENDPOINT;
            String apiKey = APIConfig.API_KEY;
            
            try {
                // Try to get config values via reflection
                Class<?> configClass = Class.forName("com.example.demo11.config.APIConfig");
                Field endpointField = configClass.getDeclaredField("HISTORY_ENDPOINT");
                Field apiKeyField = configClass.getDeclaredField("API_KEY");
                endpointField.setAccessible(true);
                apiKeyField.setAccessible(true);
                endpoint = (String) endpointField.get(null);
                apiKey = (String) apiKeyField.get(null);
            } catch (Exception e) {
                System.err.println("Could not get API config: " + e.getMessage());
                return null; // Cannot proceed without config
            }
            
            if (endpoint.isEmpty()) {
                System.err.println("No history endpoint configured, cannot save");
                return null;
            }
            
            URL url = new URL(endpoint);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setRequestProperty("Content-Type", "application/json");
            if (!apiKey.isEmpty()) {
                connection.setRequestProperty("Authorization", "Bearer " + apiKey);
            }
            connection.setDoOutput(true);
            
            // Clean the response for JSON
            String cleanResponse = response.replace("\"", "\\\"")
                                         .replace("\n", "\\n")
                                         .replace("\r", "\\r");
            
            String jsonPayload = String.format(
                "{\"question\": \"%s\", \"answer\": \"%s\", \"session\": \"%s\", \"response_id\": \"%s\", \"time_taken\": %d, \"model\": \"%s\"}",
                currentQuestion, cleanResponse, sessionId, responseId, timeTaken, currentModel
            );
            
            // Send request
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonPayload.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            int responseCode = connection.getResponseCode();
            System.out.println("Save API response code: " + responseCode);
            
            if (responseCode == 200) {
                System.out.println("Response saved successfully via direct HTTP call");
                // Update the response ID in APIClient
                try {
                    Class<?> apiClientClass = Class.forName("com.example.demo11.api.APIClient");
                    Method setResponseIdMethod = apiClientClass.getDeclaredMethod("setResponseIdForSession", 
                        String.class, String.class);
                    setResponseIdMethod.setAccessible(true);
                    setResponseIdMethod.invoke(null, sessionId, responseId);
                } catch (Exception e) {
                    System.err.println("Could not update response ID: " + e.getMessage());
                }
                return responseId;
            } else {
                System.err.println("Failed to save response: HTTP " + responseCode);
                return null;
            }
        } catch (Exception e) {
            System.err.println("Error in direct save: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Clears all chat messages from the panel
     */
    public void clearChat() {
        messageContainer.removeAll();
        messageBubbles.clear(); // Clear tracked bubbles
        resetStreamingState(); // Reset streaming state
        displayedFeedbacks.clear(); // Clear tracked feedback
        messageBubbleResponseIds.clear();
        messageContainer.revalidate();
        messageContainer.repaint();
    }

    /**
     * Sets the category ID for the backend request
     * @param categoryId The ID of the selected category
     */
    public void setCategoryId(int categoryId) {
        this.currentCategoryId = categoryId;
        System.out.println("Category ID set to: " + categoryId);
        
        // You might want to update any UI elements that show the current category
        // Or store this for the next API request
    }
    
    /**
     * Gets the current category ID
     * @return The current category ID
     */
    public int getCategoryId() {
        return currentCategoryId;
    }

    public void setCurrentModel(String model) {
        this.currentModel = model;
    }

    public JPanel createFeedbackPanel(int messageId, Integer rating, String feedback) {
        JPanel feedbackPanel = new JPanel();
        feedbackPanel.setLayout(new BoxLayout(feedbackPanel, BoxLayout.Y_AXIS));
        feedbackPanel.setOpaque(false);
        feedbackPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        feedbackPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Create a panel for the feedback label and stars
        JPanel ratingPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        ratingPanel.setOpaque(false);
        
        // Add feedback label
        JLabel feedbackLabel = new JLabel("Feedback:");
        feedbackLabel.setFont(new Font("Arial", Font.BOLD, 12));
        feedbackLabel.setForeground(new Color(51, 153, 255)); // Set feedback text to blue color
        ratingPanel.add(feedbackLabel);
        
        // Add star ratings (1-5 stars)
        JLabel[] stars = new JLabel[5];
        for (int i = 0; i < 5; i++) {
            final int starRating = i + 1;
            stars[i] = createStarLabel(starRating, String.valueOf(messageId), ratingPanel);
            ratingPanel.add(stars[i]);
            
            // If there's an existing rating, set the appropriate stars
            if (rating != null && starRating <= rating) {
                if (emptyStarIcon != null && filledStarIcon != null) {
                    stars[i].setIcon(filledStarIcon);
                    stars[i].putClientProperty("filled", true);
                } else {
                    stars[i].setForeground(starHoverColor);
                }
            }
        }
        
        // Create comment button
        JButton commentButton = new JButton();
        
        // Try to load from resources
        Icon commentIcon = IconLoader.getIcon("/icons/comment.svg");
        if (commentIcon == null) {
            // Try PNG as backup
            commentIcon = IconLoader.getIcon("/icons/copy_icon.png"); // Placeholder - use copy icon if comment icon not found
        }
        
        if (commentIcon != null) {
            commentButton.setIcon(commentIcon);
        } else {
            commentButton.setText("💬"); // Fallback to emoji if icon not found
        }
        
        commentButton.setToolTipText("Add Comment");
        commentButton.setBorderPainted(false);
        commentButton.setContentAreaFilled(false);
        commentButton.setFocusPainted(false);
        commentButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add comment button directly to rating panel
        ratingPanel.add(commentButton);
        
        // Create a panel for the entire rating row
        JPanel ratingRow = new JPanel(new BorderLayout());
        ratingRow.setOpaque(false);
        ratingRow.add(ratingPanel, BorderLayout.EAST);
        
        // Add rating row to the feedback panel
        feedbackPanel.add(ratingRow);
        
        // Create a hidden comment panel
        JPanel commentPanel = new JPanel();
        commentPanel.setLayout(new BoxLayout(commentPanel, BoxLayout.Y_AXIS));
        commentPanel.setOpaque(false);
        commentPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createDashedBorder(Color.GRAY, 1, 3, 1, false),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        commentPanel.setVisible(false);
        
        // Add "Write a feedback" label
        JLabel commentLabel = new JLabel("Write a feedback");
        commentLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        commentLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        commentPanel.add(commentLabel);
        commentPanel.add(Box.createVerticalStrut(5));
        
        // Create the comment text area
        JTextArea commentTextArea = new JTextArea(3, 20);
        commentTextArea.setLineWrap(true);
        commentTextArea.setWrapStyleWord(true);
        commentTextArea.setBorder(BorderFactory.createLineBorder(feedbackButtonColor));
        
        // If there's existing feedback, set it
        if (feedback != null) {
            commentTextArea.setText(feedback);
        }
        
        JScrollPane commentScrollPane = new JScrollPane(commentTextArea);
        commentScrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        commentPanel.add(commentScrollPane);
        commentPanel.add(Box.createVerticalStrut(5));
        
        // Create button panel for submit and cancel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Create custom styled submit button
        JButton submitButton = new JButton("Submit") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(feedbackButtonColor);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        submitButton.setForeground(Color.WHITE);
        submitButton.setOpaque(false);
        submitButton.setBorderPainted(false);
        submitButton.setContentAreaFilled(false);
        submitButton.setFocusPainted(false);
        submitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        submitButton.setMargin(new Insets(6, 14, 6, 14));
        
        // Create custom styled cancel button
        JButton cancelButton = new JButton("Cancel") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(220, 53, 69)); // Red color
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setOpaque(false);
        cancelButton.setBorderPainted(false);
        cancelButton.setContentAreaFilled(false);
        cancelButton.setFocusPainted(false);
        cancelButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        cancelButton.setMargin(new Insets(6, 14, 6, 14));
        
        // Add buttons to button panel
        buttonPanel.add(submitButton);
        buttonPanel.add(cancelButton);
        
        commentPanel.add(buttonPanel);
        
        // Submit button action
        submitButton.addActionListener(e -> {
            String comment = commentTextArea.getText();
            if (!comment.trim().isEmpty()) {
                // Change button text to indicate submission
                submitButton.setText("Submitted!");
                
                // Submit the comment
                submitFeedbackComment(String.valueOf(messageId), comment);
                
                // Keep the text area editable to allow changes
                commentTextArea.setEditable(true);
                
                // Schedule restoration of button text after 1.5 seconds
                Timer timer = new Timer(1500, event -> {
                    submitButton.setText("Submit");
                    submitButton.setEnabled(true);
                });
                timer.setRepeats(false);
                timer.start();
                
                // Hide the comment panel
                commentPanel.setVisible(false);
                
                feedbackPanel.revalidate();
                feedbackPanel.repaint();
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> {
            commentPanel.setVisible(false);
            commentTextArea.setEditable(true); // Ensure editable if reopened
            submitButton.setEnabled(true);     // Re-enable submit button
            feedbackPanel.revalidate();
            feedbackPanel.repaint();
        });
        
        // Add comment panel to feedback panel
        feedbackPanel.add(commentPanel);
        
        // Add click listener to comment button
        commentButton.addActionListener(e -> {
            commentPanel.setVisible(!commentPanel.isVisible());
            feedbackPanel.revalidate();
            feedbackPanel.repaint();
            
            // Scroll to make comment panel visible if it's shown
            if (commentPanel.isVisible()) {
                SwingUtilities.invokeLater(() -> {
                    Rectangle bounds = commentPanel.getBounds();
                    scrollPane.getViewport().scrollRectToVisible(bounds);
                });
            }
        });
        
        return feedbackPanel;
    }

    public void addUserMessage(String message) {
        currentQuestion = message; // Store the question when user sends it
        addMessageBubble("You", "/icons/you.jpg", message, true);
    }

    private void addMessageBubble(String sender, String iconPath, String message, boolean isUser) {
        // Create a new message bubble that spans full width
        JPanel bubble = createMessageBubble(sender, iconPath, message, isUser);
        
        // Simple wrapper with minimal padding
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.add(bubble, BorderLayout.CENTER);
        wrapper.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // Add to tracking list
        messageBubbles.add(wrapper);
        
        messageContainer.add(wrapper);
        messageContainer.add(Box.createVerticalStrut(5));
        refreshChat();
    }

    public JPanel createMessageBubble(String sender, String iconPath, String message, boolean isUser) {
        // Main bubble panel with BorderLayout
        JPanel bubblePanel = new JPanel(new BorderLayout());
        bubblePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(defaultBorderColor, 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        bubblePanel.setOpaque(false);
        
        // Add click listener to handle selection
        MouseAdapter clickListener = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectBubble(bubblePanel);
            }
        };
        bubblePanel.addMouseListener(clickListener);

        // Load icon
        Icon icon = IconLoader.getIcon(iconPath);
        if (icon == null) {
            icon = UIManager.getIcon("OptionPane.informationIcon");
        }

        // Create sender panel with icon (NORTH component)
        JPanel senderPanel = new JPanel(new BorderLayout());
        senderPanel.setOpaque(false);
        senderPanel.addMouseListener(clickListener);
        
        // Color for sender name
        Color nameColor = new Color(0, 102, 204);
        JLabel senderLabel = new JLabel(sender, icon, isUser ? JLabel.LEFT : JLabel.RIGHT);
        senderLabel.setForeground(nameColor);
        senderLabel.setFont(new Font("Dialog", Font.BOLD, 12));
        senderLabel.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
        senderLabel.addMouseListener(clickListener);
        
        // Add sender label to the appropriate side of the panel
        if (isUser) {
            senderPanel.add(senderLabel, BorderLayout.WEST); // User icon on left
        } else {
            senderPanel.add(senderLabel, BorderLayout.EAST); // Assistant icon on right
        }
        
        // Add sender panel to the top of the bubble (NORTH component)
        bubblePanel.add(senderPanel, BorderLayout.NORTH);
        
        // Create text area for the message with proper wrapping
        JTextArea textArea = new JTextArea();
        textArea.setName("messageTextArea");
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setBackground(new Color(0, 0, 0, 0));
        textArea.setForeground(Color.WHITE);
        textArea.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        textArea.setOpaque(false);
        textArea.addMouseListener(clickListener);
        
        // Calculate panel width
        int panelWidth = getWidth();
        if (panelWidth <= 0) panelWidth = 400;
        
        // Calculate maximum allowed width (95% of panel width)
        int maxWidth = (int)(panelWidth * BUBBLE_WIDTH_PERCENT);
        
        // Create a temporary text area to measure text dimensions
        JTextArea measureArea = new JTextArea(message);
        measureArea.setFont(textArea.getFont());
        measureArea.setLineWrap(true);
        measureArea.setWrapStyleWord(true);
        measureArea.setSize(maxWidth - 20, Integer.MAX_VALUE); // Set width to force wrapping
        
        // Get preferred size after wrapping
        Dimension preferredSize = measureArea.getPreferredSize();
        
        // Set the actual text
        textArea.setText(message);
        
        // Calculate required width and height
        int requiredWidth = Math.min(maxWidth, Math.max(MIN_BUBBLE_WIDTH, preferredSize.width + 20));
        int requiredHeight = preferredSize.height + 10;
        
        // Create scroll pane for text area to handle overflow
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        
        // Set preferred size for scroll pane
        scrollPane.setPreferredSize(new Dimension(requiredWidth, requiredHeight));
        
        // Add the scroll pane to a panel
        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setOpaque(false);
        textPanel.add(scrollPane, BorderLayout.CENTER);
        textPanel.setBorder(BorderFactory.createEmptyBorder());
        textPanel.addMouseListener(clickListener);
        
        // Add text panel to the bubble
        bubblePanel.add(textPanel, BorderLayout.CENTER);
        
        // Set bubble panel size
        bubblePanel.setPreferredSize(new Dimension(requiredWidth + 10, requiredHeight + 40));
        bubblePanel.setMaximumSize(new Dimension(requiredWidth + 10, Integer.MAX_VALUE));
        
        return bubblePanel;
    }

    public void addAIResponse(String message) {
        if (!isStreaming) {
            // First chunk of the response - create a new streaming bubble
            startStreamingResponse(message);
        } else {
            // Subsequent chunks - append to the existing bubble
            appendToStreamingResponse(message);
        }
    }

    private void startStreamingResponse(String message) {
        System.out.println("Starting streaming response with initial message: " + message);
        isStreaming = true;
        streamingResponseBuilder = new StringBuilder(message);
        
        // Record the start time
        streamingStartTime = System.currentTimeMillis();
        System.out.println("Recording streaming start time: " + streamingStartTime);

        if (useTemporaryBubbleDuringStreaming) {
            // Create a simple temporary bubble for streaming
            temporaryStreamingBubble = createTemporaryStreamingBubble("Assistant", "/icons/assistant.png", message);
            
            // Add to message container
            JPanel wrapper = new JPanel(new BorderLayout());
            wrapper.setOpaque(false);
            wrapper.add(temporaryStreamingBubble, BorderLayout.CENTER);
            wrapper.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            
            currentStreamingWrapper = wrapper;
            messageContainer.add(wrapper);
            messageContainer.add(Box.createVerticalStrut(5));
        } else {
            // Use the original approach - create a regular message bubble
            JPanel bubble = createMessageBubble("Assistant", "/icons/assistant.png", message, false);
            
            // Simple wrapper with minimal padding
            JPanel wrapper = new JPanel(new BorderLayout());
            wrapper.setOpaque(false);
            wrapper.add(bubble, BorderLayout.CENTER);
            wrapper.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

            // Add to tracking list
            messageBubbles.add(wrapper);
            
            // Save references for later updates
            currentStreamingBubble = bubble;
            currentStreamingWrapper = wrapper;
            
            // Find text area using recursive search first
            currentStreamingTextArea = findTextAreaRecursively(bubble);
            if (currentStreamingTextArea != null) {
                System.out.println("Found text area using recursive search");
            } else {
                System.err.println("ERROR: Could not find text area in streaming bubble!");
            }
            
            messageContainer.add(wrapper);
            messageContainer.add(Box.createVerticalStrut(5));
        }
        
        refreshChat();
    }
    
    private void appendToStreamingResponse(String chunk) {
        System.out.println("Appending chunk to streaming response: " + 
                           (chunk.length() > 20 ? chunk.substring(0, 20) + "..." : chunk));
        
        // Append the new chunk to the builder
        streamingResponseBuilder.append(chunk);
        final String fullText = streamingResponseBuilder.toString();
        
        // Update the text in the existing bubble - must be done on EDT
        SwingUtilities.invokeLater(() -> {
            try {
                if (useTemporaryBubbleDuringStreaming && temporaryStreamingTextArea != null) {
                    // For temporary approach, just update text - no complex size calculation needed
                    temporaryStreamingTextArea.setText(fullText);
                } else if (currentStreamingTextArea != null) {
                    // Original approach - set the complete text so far
                    currentStreamingTextArea.setText(fullText);
                    
                    // Calculate new dimensions based on updated text
                    String[] lines = fullText.split("\n");
                    int longestLine = 0;
                    for (String line : lines) {
                        longestLine = Math.max(longestLine, line.length());
                    }
                    
                    int panelWidth = getWidth();
                    if (panelWidth <= 0) panelWidth = 400;
                    
                    // Calculate required dimensions
                    int requiredWidth = Math.min(longestLine * 8 + 20, (int)(panelWidth * 0.95));
                    int requiredHeight = lines.length * 20 + 20;
                    
                    // Update text area size
                    currentStreamingTextArea.setPreferredSize(new Dimension(requiredWidth, requiredHeight));
                    currentStreamingTextArea.setMaximumSize(new Dimension(requiredWidth, Integer.MAX_VALUE));
                    
                    // Update bubble panel size
                    if (currentStreamingBubble != null) {
                        currentStreamingBubble.setPreferredSize(new Dimension(requiredWidth + 10, requiredHeight + 40));
                        currentStreamingBubble.setMaximumSize(new Dimension(requiredWidth + 10, Integer.MAX_VALUE));
                    }
                    
                    // Force immediate layout update
                    currentStreamingTextArea.revalidate();
                    currentStreamingTextArea.repaint();
                    
                    if (currentStreamingBubble != null) {
                        currentStreamingBubble.revalidate();
                        currentStreamingBubble.repaint();
                    }
                }
                
                // Auto-scroll to bottom of chat panel
                scrollPane.getVerticalScrollBar().setValue(scrollPane.getVerticalScrollBar().getMaximum());
                refreshChat();
            } catch (Exception e) {
                System.err.println("Error updating streaming response: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    // Method to complete the streaming response and finalize the bubble
    public void finalizeStreamingResponse() {
        System.out.println("Finalizing streaming response");
        if (!isStreaming) {
            System.out.println("Not streaming, nothing to finalize");
            return;
        }
        
        // Calculate elapsed time
        long endTime = System.currentTimeMillis();
        long timeTaken = endTime - streamingStartTime;
        System.out.println("Streaming completed in " + timeTaken + "ms");
        
        // Get the complete text
        final String completeText = streamingResponseBuilder.toString();
        
        if (useTemporaryBubbleDuringStreaming && currentStreamingWrapper != null) {
            // Remove the temporary bubble
            currentStreamingWrapper.removeAll();
            
            // Create a properly sized bubble with the complete text
            JPanel finalBubble = createMessageBubble("Assistant", "/icons/assistant.png", completeText, false);
            
            // Add to tracking list
            messageBubbles.add(currentStreamingWrapper);
            
            // Add the final bubble to the wrapper
            currentStreamingWrapper.add(finalBubble, BorderLayout.CENTER);
            
            // Force layout update
            SwingUtilities.invokeLater(() -> {
                currentStreamingWrapper.revalidate();
                currentStreamingWrapper.repaint();
                messageContainer.revalidate();
                messageContainer.repaint();
                
                // Update all bubble sizes
                updateAllBubbleSizes();
                
                // Force scroll to bottom
                scrollPane.getVerticalScrollBar().setValue(scrollPane.getVerticalScrollBar().getMaximum());
            });
        }
        
        // Only save if we got a successful response from the streaming API
        if (apiResponseCode == 200) {
            // Call save API with the complete response
            saveCompleteResponse(completeText, timeTaken);
        } else {
            System.err.println("Not saving response or showing feedback due to non-200 status code: " + apiResponseCode);
        }
        
        // Reset streaming state
        resetStreamingState();
    }
    
    /**
     * Ensures the complete response is saved to the API and then shows feedback UI
     */
    private void saveCompleteResponse(String response, long timeTaken) {
        try {
            // Get the session ID
            String sessionId = com.example.demo11.SidepanelFactory.getSessionId();
            if (sessionId == null || sessionId.isEmpty()) {
                System.err.println("Cannot save response: No session ID available");
                return;
            }
            
            // Call the save method in APIClient with only required fields
            String responseId = com.example.demo11.api.APIClient.saveResponse(
                sessionId,
                currentModel,
                currentQuestion,
                response,
                timeTaken
            );
            
            if (responseId != null && !responseId.isEmpty()) {
                System.out.println("Response saved successfully with ID: " + responseId);
                // Show feedback UI with the response ID
                addFeedbackUI(responseId);
            } else {
                System.err.println("Failed to get response ID from save API");
            }
        } catch (Exception e) {
            System.err.println("Error saving response: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Adds a feedback UI (star rating and comment button) after an AI response
     * 
     * @param responseId The ID of the response for which feedback is being collected
     */
    public void addFeedbackUI(String responseId) {
        if (responseId == null || responseId.isEmpty()) {
            System.err.println("Cannot add feedback UI: Invalid response ID");
            return;
        }
        
        // Create a unique identifier for this specific message bubble 
        final String uniqueBubbleId = "bubble_" + System.currentTimeMillis() + "_" + responseId;
        
        System.out.println("DEBUG: addFeedbackUI called for response ID: " + responseId + 
                          " (bubble ID: " + uniqueBubbleId + ")");
        
        // Find the target bubble to attach feedback to
        JPanel targetBubble = currentStreamingWrapper;
        if (targetBubble == null && !messageBubbles.isEmpty()) {
            // If no current wrapper, use the most recent message bubble
            targetBubble = messageBubbles.get(messageBubbles.size() - 1);
        }
        
        // If we have a bubble, check if we already attached feedback to it
        if (targetBubble != null) {
            String existingId = messageBubbleResponseIds.get(targetBubble);
            if (existingId != null) {
                System.out.println("Bubble already has feedback with ID: " + existingId);
                return;
            }
            
            // Remember that we're showing feedback for this bubble
            messageBubbleResponseIds.put(targetBubble, responseId);
        }
        
        System.out.println("Adding feedback UI for response ID: " + responseId + 
                         " to bubble: " + uniqueBubbleId);
        
        // Create a final copy of responseId for use in lambda expressions
        final String finalResponseId = responseId;
        
        JPanel feedbackPanel = new JPanel();
        feedbackPanel.setLayout(new BoxLayout(feedbackPanel, BoxLayout.Y_AXIS));
        feedbackPanel.setOpaque(false);
        feedbackPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        feedbackPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Store a reference to the target bubble in the feedback panel's client properties
        feedbackPanel.putClientProperty("targetBubble", targetBubble);
        feedbackPanel.putClientProperty("responseId", finalResponseId);
        
        // Create a panel for the feedback label and stars
        JPanel ratingPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        ratingPanel.setOpaque(false);
        
        // Add feedback label
        JLabel feedbackLabel = new JLabel("Feedback:");
        feedbackLabel.setFont(new Font("Arial", Font.BOLD, 12));
        feedbackLabel.setForeground(new Color(51, 153, 255)); // Set feedback text to blue color
        ratingPanel.add(feedbackLabel);
        
        // Add star ratings (1-5 stars)
        JLabel[] stars = new JLabel[5];
        for (int i = 0; i < 5; i++) {
            final int rating = i + 1;
            stars[i] = createStarLabel(rating, finalResponseId, ratingPanel);
            ratingPanel.add(stars[i]);
        }
        
        // Create comment button
        JButton commentButton = new JButton();
        
        // Try to load from resources
        Icon commentIcon = IconLoader.getIcon("/icons/comment.svg");
        if (commentIcon == null) {
            // Try PNG as backup
            commentIcon = IconLoader.getIcon("/icons/copy_icon.png"); // Placeholder - use copy icon if comment icon not found
        }
        
        if (commentIcon != null) {
            commentButton.setIcon(commentIcon);
        } else {
            commentButton.setText("💬"); // Fallback to emoji if icon not found
        }
        
        commentButton.setToolTipText("Add Comment");
        commentButton.setBorderPainted(false);
        commentButton.setContentAreaFilled(false);
        commentButton.setFocusPainted(false);
        commentButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add comment button directly to rating panel
        ratingPanel.add(commentButton);
        
        // Create a panel for the entire rating row
        JPanel ratingRow = new JPanel(new BorderLayout());
        ratingRow.setOpaque(false);
        ratingRow.add(ratingPanel, BorderLayout.EAST); // Changed from WEST to EAST
        
        // Add rating row to the feedback panel
        feedbackPanel.add(ratingRow);
        
        // Create a hidden comment panel
        JPanel commentPanel = new JPanel();
        commentPanel.setLayout(new BoxLayout(commentPanel, BoxLayout.Y_AXIS));
        commentPanel.setOpaque(false);
        commentPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createDashedBorder(Color.GRAY, 1, 3, 1, false),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        commentPanel.setVisible(false);
        
        // Add "Write a feedback" label
        JLabel commentLabel = new JLabel("Write a feedback");
        commentLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        commentLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        commentPanel.add(commentLabel);
        commentPanel.add(Box.createVerticalStrut(5));
        
        // Create the comment text area
        JTextArea commentTextArea = new JTextArea(3, 20);
        commentTextArea.setLineWrap(true);
        commentTextArea.setWrapStyleWord(true);
        commentTextArea.setBorder(BorderFactory.createLineBorder(feedbackButtonColor));
        JScrollPane commentScrollPane = new JScrollPane(commentTextArea);
        commentScrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        commentPanel.add(commentScrollPane);
        commentPanel.add(Box.createVerticalStrut(5));
        
        // Create button panel for submit and cancel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Create custom styled submit button
        JButton submitButton = new JButton("Submit") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(feedbackButtonColor);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        submitButton.setForeground(Color.WHITE);
        submitButton.setOpaque(false);
        submitButton.setBorderPainted(false);
        submitButton.setContentAreaFilled(false);
        submitButton.setFocusPainted(false);
        submitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        submitButton.setMargin(new Insets(6, 14, 6, 14));
        
        // Create custom styled cancel button
        JButton cancelButton = new JButton("Cancel") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(220, 53, 69)); // Red color
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setOpaque(false);
        cancelButton.setBorderPainted(false);
        cancelButton.setContentAreaFilled(false);
        cancelButton.setFocusPainted(false);
        cancelButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        cancelButton.setMargin(new Insets(6, 14, 6, 14));
        
        // Add buttons to button panel
        buttonPanel.add(submitButton);
        buttonPanel.add(cancelButton);
        
        commentPanel.add(buttonPanel);
        
        // Submit button action
        submitButton.addActionListener(e -> {
            String comment = commentTextArea.getText();
            if (!comment.trim().isEmpty()) {
                // Change button text to indicate submission
                submitButton.setText("Submitted!");
                
                // Submit the comment
                submitFeedbackComment(finalResponseId, comment);
                
                // Keep the text area editable to allow changes
                commentTextArea.setEditable(true);
                
                // Schedule restoration of button text after 1.5 seconds
                Timer timer = new Timer(1500, event -> {
                    submitButton.setText("Submit");
                    submitButton.setEnabled(true);
                });
                timer.setRepeats(false);
                timer.start();
                
                // Hide the comment panel
                commentPanel.setVisible(false);
                
                feedbackPanel.revalidate();
                feedbackPanel.repaint();
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> {
            commentPanel.setVisible(false);
            commentTextArea.setEditable(true); // Ensure editable if reopened
            submitButton.setEnabled(true);     // Re-enable submit button
            feedbackPanel.revalidate();
            feedbackPanel.repaint();
        });
        
        // Add comment panel to feedback panel
        feedbackPanel.add(commentPanel);
        
        // Add click listener to comment button
        commentButton.addActionListener(e -> {
            commentPanel.setVisible(!commentPanel.isVisible());
            feedbackPanel.revalidate();
            feedbackPanel.repaint();
            
            // Scroll to make comment panel visible if it's shown
            if (commentPanel.isVisible()) {
                SwingUtilities.invokeLater(() -> {
                    Rectangle bounds = commentPanel.getBounds();
                    scrollPane.getViewport().scrollRectToVisible(bounds);
                });
            }
        });
        
        // Add feedback panel to the message container
        messageContainer.add(feedbackPanel);
        messageContainer.revalidate();
        messageContainer.repaint();
        
        // Scroll to show the feedback UI
        refreshChat();
    }
    
    /**
     * Creates a star label with hover effects for the rating
     */
    private JLabel createStarLabel(int rating, String responseId, JPanel parentPanel) {
        JLabel star = new JLabel();
        
        // Try to load star icons
        Icon emptyStarIcon = IconLoader.getIcon("/icons/empty_star.png");
        Icon filledStarIcon = IconLoader.getIcon("/icons/filled_star.png");
        
        if (emptyStarIcon != null && filledStarIcon != null) {
            star.setIcon(emptyStarIcon);
        } else {
            // Fallback to text if icons not found
            star.setText("★");
            star.setFont(new Font("Arial", Font.BOLD, 16));
            star.setForeground(starDefaultColor);
        }
        
        star.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add hover effect
        star.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                // Get parent container and find the position of current star
                Container parent = star.getParent();
                int currentStarPosition = parent.getComponentZOrder(star);
                
                // Highlight all stars up to and including the hovered one
                for (int i = 0; i < parent.getComponentCount(); i++) {
                    Component c = parent.getComponent(i);
                    if (c instanceof JLabel) {
                        JLabel starLabel = (JLabel)c;
                        
                        // Skip the feedback label - only process star labels
                        if (starLabel.getText() != null && starLabel.getText().equals("Feedback:")) {
                            continue;
                        }
                        
                        if (emptyStarIcon != null && filledStarIcon != null) {
                            // Handle icon stars
                            if (i <= currentStarPosition) {
                                starLabel.setIcon(filledStarIcon);
                            }
                        } else {
                            // Handle text stars
                            if (i <= currentStarPosition) {
                                starLabel.setForeground(starHoverColor);
                            }
                        }
                    }
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                // Get parent container to access all stars
                Container parent = star.getParent();
                
                // Reset all stars to their original state unless they're already filled by a click
                for (int i = 0; i < parent.getComponentCount(); i++) {
                    Component c = parent.getComponent(i);
                    if (c instanceof JLabel) {
                        JLabel starLabel = (JLabel)c;
                        
                        // Skip the feedback label - only process star labels
                        if (starLabel.getText() != null && starLabel.getText().equals("Feedback:")) {
                            continue;
                        }
                        
                        if (emptyStarIcon != null && filledStarIcon != null) {
                            // For icon stars, check if it was filled by click
                            if (starLabel.getClientProperty("filled") == null || 
                                !((Boolean)starLabel.getClientProperty("filled"))) {
                                starLabel.setIcon(emptyStarIcon);
                            }
                        } else {
                            // For text stars, reset to default color unless clicked
                            if (starLabel.getClientProperty("filled") == null || 
                                !((Boolean)starLabel.getClientProperty("filled"))) {
                                starLabel.setForeground(starDefaultColor);
                            }
                        }
                    }
                }
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                submitStarRating(responseId, rating);
                
                // Set all stars up to this one to gold/filled
                Container parent = star.getParent();
                for (int i = 0; i < parent.getComponentCount(); i++) {
                    Component c = parent.getComponent(i);
                    if (c instanceof JLabel) {
                        JLabel starLabel = (JLabel)c;
                        
                        // Skip the feedback label - only process star labels
                        if (starLabel.getText() != null && starLabel.getText().equals("Feedback:")) {
                            continue;
                        }
                        
                        if (emptyStarIcon != null && filledStarIcon != null) {
                            // Handle icon stars
                            if (i <= parent.getComponentZOrder(star)) {
                                starLabel.setIcon(filledStarIcon);
                                starLabel.putClientProperty("filled", true);
                            } else {
                                starLabel.setIcon(emptyStarIcon);
                                starLabel.putClientProperty("filled", false);
                            }
                        } else {
                            // Handle text stars
                            if (i <= parent.getComponentZOrder(star)) {
                                starLabel.setForeground(starHoverColor);
                            } else {
                                starLabel.setForeground(starDefaultColor);
                            }
                        }
                    }
                }
            }
        });
        
        return star;
    }
    
    /**
     * Submits a star rating to the backend
     */
    private void submitStarRating(String responseId, int rating) {
        System.out.println("Submitting rating " + rating + " for response ID: " + responseId);
        com.example.demo11.utils.FeedbackManager.submitRating(responseId, rating);
    }
    
    /**
     * Submits a feedback comment to the backend
     */
    private void submitFeedbackComment(String responseId, String comment) {
        System.out.println("Submitting comment for response ID: " + responseId + ": " + comment);
        com.example.demo11.utils.FeedbackManager.submitComment(responseId, comment);
    }

    private void refreshChat() {
        SwingUtilities.invokeLater(() -> {
            // Update all bubble sizes
            updateAllBubbleSizes();
            
            // Revalidate and repaint the container
            messageContainer.revalidate();
            messageContainer.repaint();
            
            // Auto-scroll to the bottom of the panel
            JScrollBar verticalBar = scrollPane.getVerticalScrollBar();
            verticalBar.setValue(verticalBar.getMaximum());
            
            // Ensure parent components are updated
            Container parent = getParent();
            if (parent != null) {
                parent.revalidate();
                parent.repaint();
            }
            
            // Force immediate layout update
            scrollPane.revalidate();
            scrollPane.repaint();
        });
    }

    public JScrollPane getScrollPane() {
        return scrollPane;
    }

    private void resetStreamingState() {
        isStreaming = false;
        currentStreamingBubble = null;
        currentStreamingTextArea = null;
        currentStreamingWrapper = null;
        temporaryStreamingBubble = null;
        temporaryStreamingTextArea = null;
        streamingResponseBuilder = new StringBuilder();
        streamingStartTime = 0;
        apiResponseCode = 200; // Reset to default success
    }

    private JPanel createStreamingBubble(String sender, String iconPath, String initialMessage) {
        JPanel bubblePanel = new JPanel();
        bubblePanel.setLayout(new BoxLayout(bubblePanel, BoxLayout.Y_AXIS));
        
        // Use grey border for the bubble
        bubblePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(defaultBorderColor, 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        bubblePanel.setOpaque(false);
        
        // Add click listener to handle selection
        MouseAdapter clickListener = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectBubble(bubblePanel);
            }
        };
        
        bubblePanel.addMouseListener(clickListener);
        
        // Calculate initial bubble width - use the same width as question bubbles
        int panelWidth = getWidth();
        if (panelWidth <= 0) panelWidth = 300;
        
        // Use the same width calculation as question bubbles
        int bubbleWidth = calculateBubbleWidth(panelWidth);
        bubblePanel.setPreferredSize(null);
        bubblePanel.setMaximumSize(new Dimension(bubbleWidth, Integer.MAX_VALUE));
        bubblePanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Load icon
        Icon icon = IconLoader.getIcon(iconPath);
        if (icon == null) {
            icon = UIManager.getIcon("OptionPane.informationIcon");
        }

        // Sender panel with icon
        JPanel senderPanel = new JPanel(new BorderLayout());
        senderPanel.setOpaque(false);
        senderPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        senderPanel.addMouseListener(clickListener);
        
        Color nameColor = new Color(0, 102, 204);
        JLabel senderLabel = new JLabel(sender, icon, JLabel.RIGHT);
        senderLabel.setForeground(nameColor);
        senderLabel.setFont(new Font("Dialog", Font.BOLD, 12));
        senderLabel.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
        senderPanel.add(senderLabel, BorderLayout.EAST);

        // Create text area for streaming content
        int textAreaWidth = bubbleWidth - 20;
        JTextArea textArea = new JTextArea(initialMessage);
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setBackground(new Color(0, 0, 0, 0));
        textArea.setForeground(Color.WHITE);
        textArea.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
        textArea.setOpaque(false);
        textArea.addMouseListener(clickListener);
        
        currentStreamingTextArea = textArea;
        
        // Calculate initial dimensions
        int columns = Math.max(5, textAreaWidth / 8);
        textArea.setColumns(columns);
        
        // Calculate rows based on content - allow full expansion
        int charPerLine = Math.max(1, columns - 1);
        int messageLength = initialMessage.length();
        int lines = (int)Math.ceil((double)messageLength / charPerLine);
        textArea.setRows(Math.max(1, lines));
        
        // Content panel without scroll pane
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        contentPanel.add(textArea, BorderLayout.CENTER);
        contentPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        contentPanel.addMouseListener(clickListener);
        contentPanel.setPreferredSize(new Dimension(textAreaWidth, contentPanel.getPreferredSize().height));

        bubblePanel.add(senderPanel);
        bubblePanel.add(contentPanel);
        
        return bubblePanel;
    }

    private int calculateBubbleWidth(int panelWidth) {
        // Calculate width as a percentage of panel width
        int calculatedWidth = (int)(panelWidth * BUBBLE_WIDTH_PERCENT);
        return Math.max(calculatedWidth, MIN_BUBBLE_WIDTH);
    }
}
