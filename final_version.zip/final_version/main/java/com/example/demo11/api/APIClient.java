package com.example.demo11.api;

import com.example.demo11.config.APIConfig;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class APIClient {

    // Validates the API key by calling the backend endpoint.
    public static boolean validateApiKey(String apiKey) throws Exception {
        String endpoint = APIConfig.VALIDATE_API_KEY_ENDPOINT + "?apiKey=" + apiKey;
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        int status = connection.getResponseCode();
        connection.disconnect();
        return status == 200;
    }

    // Sends a question to the stream-chat endpoint.
    public static String askQuestion(String model, String question, String category, String sessionId) throws Exception {
        String endpoint = APIConfig.STREAM_CHAT_ENDPOINT;
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(15000);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
        connection.setDoOutput(true);

        question = question.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
        
        String jsonPayload = "{ \"prompt\": \"" + question + "\", \"model\": \"" + model + "\", \"category\": " + category + ", \"session_id\": \"" + sessionId + "\" }";
        System.out.println("Payload sending to backend: " + jsonPayload);
        
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = jsonPayload.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        int responseCode = connection.getResponseCode();
        System.out.println("API Response code: " + responseCode);
        
        if (responseCode != 200) {
            try (BufferedReader errorReader = new BufferedReader(new InputStreamReader(connection.getErrorStream()))) {
                StringBuilder errorResponse = new StringBuilder();
                String line;
                while ((line = errorReader.readLine()) != null) {
                    errorResponse.append(line).append("\n");
                }
                System.err.println("API Error: " + errorResponse.toString());
                return "Error from API (HTTP " + responseCode + "): " + errorResponse.toString();
            } catch (Exception e) {
                System.err.println("Error reading error stream: " + e.getMessage());
                return "Error from API (HTTP " + responseCode + ")";
            }
        }
        
        try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine).append("\n");
            }
            return response.toString();
        } catch (Exception e) {
            System.err.println("Error reading response: " + e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            connection.disconnect();
        }
    }

    // Sends a question to the stream-chat endpoint with time tracking
    public static ChatResult askQuestionWithTiming(String model, String question, String category, String sessionId) throws Exception {
        long startTime = System.currentTimeMillis();
        
        // First get the HTTP status code
        String endpoint = APIConfig.STREAM_CHAT_ENDPOINT;
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(15000);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
        connection.setDoOutput(true);

        question = question.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
        
        String jsonPayload = "{ \"prompt\": \"" + question + "\", \"model\": \"" + model + "\", \"category\": " + category + ", \"session_id\": \"" + sessionId + "\" }";
        System.out.println("Payload sending to backend: " + jsonPayload);
        
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = jsonPayload.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        int responseCode = connection.getResponseCode();
        System.out.println("API Response code: " + responseCode);
        
        String response;
        if (responseCode != 200) {
            try (BufferedReader errorReader = new BufferedReader(new InputStreamReader(connection.getErrorStream()))) {
                StringBuilder errorResponse = new StringBuilder();
                String line;
                while ((line = errorReader.readLine()) != null) {
                    errorResponse.append(line).append("\n");
                }
                System.err.println("API Error: " + errorResponse.toString());
                response = "Error from API (HTTP " + responseCode + "): " + errorResponse.toString();
            } catch (Exception e) {
                System.err.println("Error reading error stream: " + e.getMessage());
                response = "Error from API (HTTP " + responseCode + ")";
            }
        } else {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                StringBuilder responseBuilder = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    responseBuilder.append(inputLine).append("\n");
                }
                response = responseBuilder.toString();
            }
        }
        
        // Calculate elapsed time
        long endTime = System.currentTimeMillis();
        long timeTaken = endTime - startTime;
        
        String responseId = "";
        // Only save interaction if we got a 200 response
        if (responseCode == 200) {
            responseId = saveInteraction(question, response, timeTaken, sessionId);
        }
        
        // Create result object with the response, timing info, and ID
        ChatResult result = new ChatResult(response, timeTaken, responseId);
        
        connection.disconnect();
        return result;
    }
    
    // Save interaction data to the backend
    private static String saveInteraction(String question, String answer, long timeTaken, String sessionId) {
        try {
            String endpoint = APIConfig.HISTORY_ENDPOINT;
            URL url = new URL(endpoint);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
            connection.setDoOutput(true);
            
            // Clean the question and answer for JSON
            question = question.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
            answer = answer.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
            
            // Create JSON payload
            String jsonPayload = String.format(
                "{\"question\": \"%s\", \"answer\": \"%s\", \"time_taken\": %d, \"session\": \"%s\"}",
                question, answer, timeTaken, sessionId
            );
            
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonPayload.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            int responseCode = connection.getResponseCode();
            String responseId = "";
            
            if (responseCode != 200) {
                System.err.println("Failed to save interaction data: HTTP " + responseCode);
            } else {
                System.out.println("Interaction data saved successfully");
                
                // Read the response to get the ID
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    
                    String responseText = response.toString();
                    System.out.println("Save API Response: " + responseText);
                    
                    // First check if response is just a plain ID (number)
                    if (responseText != null && !responseText.isEmpty()) {
                        // Check if it's a plain number/ID
                        if (responseText.matches("\\d+")) {
                            responseId = responseText;
                            System.out.println("Received numeric ID from save API: " + responseId);
                            return responseId;
                        }
                        
                        // If not a plain number, try various JSON formats
                        
                        // Format 1: {"id":"12345"}
                        if (responseText.contains("\"id\"")) {
                            try {
                                int idStartIndex = responseText.indexOf("\"id\"") + 5;
                                int idEndIndex = responseText.indexOf("\"", idStartIndex);
                                if (idStartIndex > 0 && idEndIndex > idStartIndex) {
                                    responseId = responseText.substring(idStartIndex, idEndIndex);
                                    System.out.println("Received ID from save API: " + responseId);
                                }
                            } catch (Exception e) {
                                System.err.println("Error parsing id field: " + e.getMessage());
                            }
                        }
                        
                        // Format 2: {"_id":"12345"}
                        if (responseId.isEmpty() && responseText.contains("\"_id\"")) {
                            try {
                                int idStartIndex = responseText.indexOf("\"_id\"") + 6;
                                int idEndIndex = responseText.indexOf("\"", idStartIndex);
                                if (idStartIndex > 0 && idEndIndex > idStartIndex) {
                                    responseId = responseText.substring(idStartIndex, idEndIndex);
                                    System.out.println("Received _id from save API: " + responseId);
                                }
                            } catch (Exception e) {
                                System.err.println("Error parsing _id field: " + e.getMessage());
                            }
                        }
                        
                        // Format 3: {"data":{"id":"12345"}}
                        if (responseId.isEmpty() && responseText.contains("\"data\"") && responseText.contains("\"id\"")) {
                            try {
                                int dataStart = responseText.indexOf("\"data\"");
                                int idStartIndex = responseText.indexOf("\"id\"", dataStart) + 5;
                                int idEndIndex = responseText.indexOf("\"", idStartIndex);
                                if (idStartIndex > 0 && idEndIndex > idStartIndex) {
                                    responseId = responseText.substring(idStartIndex, idEndIndex);
                                    System.out.println("Received nested ID from save API: " + responseId);
                                }
                            } catch (Exception e) {
                                System.err.println("Error parsing nested id field: " + e.getMessage());
                            }
                        }
                        
                        // If still no ID found, log a warning
                        if (responseId.isEmpty()) {
                            System.err.println("WARNING: Could not extract ID from save API response: " + responseText);
                        }
                    } else {
                        System.err.println("WARNING: Empty response from save API");
                    }
                }
            }
            
            connection.disconnect();
            return responseId;
        } catch (Exception e) {
            System.err.println("Error saving interaction data: " + e.getMessage());
            e.printStackTrace();
            return "";
        }
    }
    
    // Result class to hold response, timing information, and response ID
    public static class ChatResult {
        private final String response;
        private final long timeTaken;
        private final String responseId;
        
        public ChatResult(String response, long timeTaken, String responseId) {
            this.response = response;
            this.timeTaken = timeTaken;
            this.responseId = responseId;
        }
        
        public String getResponse() {
            return response;
        }
        
        public long getTimeTaken() {
            return timeTaken;
        }
        
        public String getResponseId() {
            return responseId;
        }
    }

    // Interface for handling streaming responses
    public interface StreamingResponseHandler {
        void onChunk(String chunk);
        void onComplete(long timeTaken, String responseId);
        void onError(Exception e);
    }

    // Store response IDs for subsequent feedback
    private static final java.util.Map<String, String> sessionToResponseIds = 
            new java.util.HashMap<>();

    /**
     * Streams a chat response from the API, delivering chunks as they arrive
     */
    public static void streamChatResponse(String model, String question, String category, 
                                         String sessionId, StreamingResponseHandler handler) {
        // Create a final copy of the question for use in the lambda
        final String questionInput = question;
        
        new Thread(() -> {
            // Record the start time once at the beginning
            long startTime = System.currentTimeMillis();
            StringBuilder fullResponseBuilder = new StringBuilder();
            
            try {
                String endpoint = APIConfig.STREAM_CHAT_ENDPOINT;
                URL url = new URL(endpoint);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
                connection.setDoOutput(true);

                // Sanitize the question inside the lambda
                String sanitizedQuestion = questionInput.replace("\"", "\\\"")
                                             .replace("\n", "\\n")
                                             .replace("\r", "\\r");
                
                // Add stream:true to request streaming response
                String jsonPayload = "{ \"prompt\": \"" + sanitizedQuestion + "\", \"model\": \"" + model + 
                                   "\", \"category\": " + category + ", \"session_id\": \"" + sessionId + 
                                   "\", \"stream\": true }";
                
                System.out.println("Streaming API request payload: " + jsonPayload);
                
                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = jsonPayload.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int responseCode = connection.getResponseCode();
                System.out.println("Streaming API response code: " + responseCode);
                
                if (responseCode == 200) {
                    try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                        String inputLine;
                        while ((inputLine = in.readLine()) != null) {
                            if (!inputLine.trim().isEmpty()) {
                                // Process the chunk and append to full response
                                fullResponseBuilder.append(inputLine).append("\n");
                                handler.onChunk(inputLine);
                            }
                        }
                    }
                    
                    long timeTaken = System.currentTimeMillis() - startTime;
                    System.out.println("Streaming complete in " + timeTaken + "ms");
                    
                    // Signal completion to handler with time
                    handler.onComplete(timeTaken, null);
                } else {
                    // Handle error response
                    handler.onError(new Exception("API returned status code: " + responseCode));
                }
            } catch (Exception e) {
                System.err.println("Error in streaming response: " + e.getMessage());
                e.printStackTrace();
                handler.onError(e);
            }
        }).start();
    }
    
    public static String saveResponse(String sessionId, String model, String question, 
                                    String response, long timeTaken) {
        try {
            System.out.println("Saving response with time taken: " + timeTaken + "ms");
            
            String endpoint = APIConfig.HISTORY_ENDPOINT;
            URL url = new URL(endpoint);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
            connection.setDoOutput(true);
            
            // Clean the question and response for JSON
            String cleanedQuestion = question.replace("\"", "\\\"")
                                           .replace("\n", "\\n")
                                           .replace("\r", "\\r");
            String cleanedResponse = response.replace("\"", "\\\"")
                                           .replace("\n", "\\n")
                                           .replace("\r", "\\r");
            
            // Create payload with only required fields
            String jsonPayload = String.format(
                "{\"question\": \"%s\", \"answer\": \"%s\", \"session\": \"%s\", \"time_taken\": %d, \"model\": \"%s\"}",
                cleanedQuestion, cleanedResponse, sessionId, timeTaken, model
            );
            
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonPayload.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            int responseCode = connection.getResponseCode();
            System.out.println("Save API response code: " + responseCode);
            
            if (responseCode == 200) {
                // Read the response to extract the new ID
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                    StringBuilder responseBuilder = new StringBuilder();
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        responseBuilder.append(inputLine);
                    }
                    
                    String responseJson = responseBuilder.toString();
                    System.out.println("Save API Response: " + responseJson);
                    
                    // Extract ID from the response
                    String responseId = extractSaveResponseId(responseJson);
                    
                    if (responseId != null && !responseId.isEmpty()) {
                        System.out.println("Extracted ID from save API response: " + responseId);
                        // Store the response ID for this session
                        sessionToResponseIds.put(sessionId, responseId);
                        return responseId;
                    }
                }
            }
            
            System.err.println("Failed to save response: HTTP " + responseCode);
            return null;
        } catch (Exception e) {
            System.err.println("Error saving response: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Extracts the ID from the save API response
     * Expected format: {"status":"success","result":{"id":id,"timestamp":datetime.now()}}
     * Also handles plain numeric responses like "12345"
     */
    private static String extractSaveResponseId(String jsonResponse) {
        try {
            if (jsonResponse == null || jsonResponse.isEmpty()) {
                return null;
            }
            
            // Check if the response is just a plain number (most common for autoincrement IDs)
            if (jsonResponse.trim().matches("\\d+")) {
                System.out.println("Found plain numeric ID in response: " + jsonResponse.trim());
                return jsonResponse.trim();
            }
            
            // Handle nested result object format: {"status":"success","result":{"id":345,"timestamp":"..."}}
            if (jsonResponse.contains("\"result\"") && jsonResponse.contains("\"id\"")) {
                // Try regex pattern for nested id in result
                java.util.regex.Pattern nestedPattern = 
                    java.util.regex.Pattern.compile("\"result\"\\s*:\\s*\\{.*?\"id\"\\s*:\\s*(\\d+)");
                java.util.regex.Matcher nestedMatcher = nestedPattern.matcher(jsonResponse);
                if (nestedMatcher.find()) {
                    String resultId = nestedMatcher.group(1);
                    System.out.println("Found ID in nested result object: " + resultId);
                    return resultId;
                }
                
                // If regex fails, try manual string extraction for result.id
                try {
                    int resultStart = jsonResponse.indexOf("\"result\"");
                    if (resultStart >= 0) {
                        int resultObjStart = jsonResponse.indexOf("{", resultStart);
                        if (resultObjStart >= 0) {
                            int idIndex = jsonResponse.indexOf("\"id\"", resultObjStart);
                            if (idIndex >= 0) {
                                int valueStart = jsonResponse.indexOf(":", idIndex) + 1;
                                // Skip whitespace
                                while (valueStart < jsonResponse.length() && 
                                      Character.isWhitespace(jsonResponse.charAt(valueStart))) {
                                    valueStart++;
                                }
                                
                                // Skip quote if present
                                boolean isQuoted = valueStart < jsonResponse.length() && 
                                                 jsonResponse.charAt(valueStart) == '"';
                                if (isQuoted) valueStart++;
                                
                                int valueEnd = valueStart;
                                while (valueEnd < jsonResponse.length() && 
                                      Character.isDigit(jsonResponse.charAt(valueEnd))) {
                                    valueEnd++;
                                }
                                
                                if (valueEnd > valueStart) {
                                    String resultId = jsonResponse.substring(valueStart, valueEnd);
                                    System.out.println("Extracted ID from result object: " + resultId);
                                    return resultId;
                                }
                            }
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Error extracting ID from result object: " + e.getMessage());
                }
            }
            
            // First check if response has the expected structure
            if (jsonResponse.contains("\"status\"") && jsonResponse.contains("\"id\"")) {
                
                // First try regex extraction
                java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("\"id\"\\s*:\\s*\"?([^,}\"]+)\"?");
                java.util.regex.Matcher matcher = pattern.matcher(jsonResponse);
                if (matcher.find()) {
                    return matcher.group(1);
                }
                
                // If regex fails, try simpler string-based extraction
                int idIndex = jsonResponse.indexOf("\"id\"");
                if (idIndex > 0) {
                    int valueStart = jsonResponse.indexOf(":", idIndex) + 1;
                    // Skip whitespace
                    while (valueStart < jsonResponse.length() && 
                           Character.isWhitespace(jsonResponse.charAt(valueStart))) {
                        valueStart++;
                    }
                    
                    // Check if value is quoted
                    boolean isQuoted = valueStart < jsonResponse.length() && 
                                      jsonResponse.charAt(valueStart) == '"';
                    
                    int valueEnd;
                    if (isQuoted) {
                        valueStart++; // Skip opening quote
                        valueEnd = jsonResponse.indexOf("\"", valueStart);
                    } else {
                        valueEnd = jsonResponse.indexOf(",", valueStart);
                        if (valueEnd < 0) {
                            valueEnd = jsonResponse.indexOf("}", valueStart);
                        }
                    }
                    
                    if (valueEnd > valueStart) {
                        return jsonResponse.substring(valueStart, valueEnd).trim();
                    }
                }
            } else {
                // Check for other JSON formats that might contain an ID
                
                // Format: {"id": 12345}
                java.util.regex.Pattern idPattern = java.util.regex.Pattern.compile("\"id\"\\s*:\\s*\"?([^,}\"]+)\"?");
                java.util.regex.Matcher idMatcher = idPattern.matcher(jsonResponse);
                if (idMatcher.find()) {
                    return idMatcher.group(1);
                }
                
                // Try to find any number in the response as a last resort
                java.util.regex.Pattern numPattern = java.util.regex.Pattern.compile("(\\d+)");
                java.util.regex.Matcher numMatcher = numPattern.matcher(jsonResponse);
                if (numMatcher.find()) {
                    String foundNumber = numMatcher.group(1);
                    System.out.println("Found number in response as fallback ID: " + foundNumber);
                    return foundNumber;
                }
            }
            
            return null;
        } catch (Exception e) {
            System.err.println("Error extracting ID from save response: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Gets the latest response ID for a session
     */
    public static String getResponseIdForSession(String sessionId) {
        return sessionToResponseIds.get(sessionId);
    }

    /**
     * Simple helper method to extract values from JSON strings without requiring a library
     */
    private static String extractJsonValue(String json, String key) {
        // Look for the key pattern: "key": "value" or "key":"value"
        String pattern = "\"" + key + "\"\\s*:\\s*\"([^\"]*)\"";
        java.util.regex.Pattern r = java.util.regex.Pattern.compile(pattern);
        java.util.regex.Matcher m = r.matcher(json);
        
        if (m.find()) {
            return m.group(1);
        }
        
        // Also check for non-string values: "key": value
        pattern = "\"" + key + "\"\\s*:\\s*([^,}\\s][^,}]*)";
        r = java.util.regex.Pattern.compile(pattern);
        m = r.matcher(json);
        
        if (m.find()) {
            String value = m.group(1);
            // Remove any trailing commas
            if (value.endsWith(",")) {
                value = value.substring(0, value.length() - 1);
            }
            return value;
        }
        
        return null;
    }
}
