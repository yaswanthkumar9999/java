package com.example.demo11.api;

import com.example.demo11.ui.ChatPanel;
import javax.swing.*;
import java.awt.Component;
import java.awt.Container;
import java.awt.Window;
import java.util.List;

public class AIResponseWorker extends SwingWorker<Void, Object> {
    private final ChatPanel chatPanel;
    private final String userInput;
    private final String model;
    private final String category;
    private final String sessionId;
    private long responseTime;
    private String responseId;

    public AIResponseWorker(ChatPanel chatPanel, String userInput, String model, String category, String sessionId) {
        this.chatPanel = chatPanel;
        this.userInput = userInput;
        this.model = model;
        this.category = category;
        this.sessionId = sessionId;
        this.responseTime = 0;
        this.responseId = "";
    }

    @Override
    protected Void doInBackground() throws Exception {
        try {
            System.out.println("Starting true streaming request to API...");
            
            // Set the current model in the ChatPanel
            chatPanel.setCurrentModel(model);
            
            // First publish empty string to create the streaming bubble
            publish("");
            
            // Use the new streaming API implementation
            APIClient.streamChatResponse(model, userInput, category, sessionId, new APIClient.StreamingResponseHandler() {
                @Override
                public void onChunk(String chunk) {
                    // Publish each chunk as it arrives from the API
                    System.out.println("Received chunk from API, length: " + chunk.length());
                    publish(chunk);
                }
                
                @Override
                public void onComplete(long timeTaken, String resId) {
                    // Store the response metrics - this only happens ONCE at the end of streaming
                    responseTime = timeTaken;
                    responseId = resId;
                    System.out.println("Streaming complete, total time: " + responseTime + "ms, ID: " + responseId);
                    
                    // Signal streaming completion to UI
                    publish(new StreamingComplete());
                    
                    // Publish response info for feedback UI - only happens once
                    publish(new ResponseInfo(responseTime, responseId));
                }
                
                @Override
                public void onError(Exception e) {
                    System.err.println("Streaming error: " + e.getMessage());
                    publish("Error: " + e.getMessage());
                }
            });
            
        } catch (Exception e) {
            e.printStackTrace();
            publish("Error: " + e.getMessage());
            System.err.println("Error in AIResponseWorker: " + e.getMessage());
        }
        return null;
    }
    
    /**
     * Splits the response into smaller chunks for more natural streaming
     */
    private String[] splitResponseIntoChunks(String response) {
        // First try to split by sentences
        String[] sentences = response.split("(?<=[.!?])\\s+");
        
        // If we have very long sentences, split them further
        if (sentences.length < 3 || findMaxLength(sentences) > 100) {
            return splitIntoSmallerChunks(response);
        }
        
        return sentences;
    }
    
    private int findMaxLength(String[] chunks) {
        int max = 0;
        for (String chunk : chunks) {
            max = Math.max(max, chunk.length());
        }
        return max;
    }
    
    private String[] splitIntoSmallerChunks(String text) {
        // Split into smaller chunks (around 30-50 chars)
        java.util.List<String> chunks = new java.util.ArrayList<>();
        
        int chunkSize = 40;
        int index = 0;
        
        while (index < text.length()) {
            // Find a good breakpoint (space, punctuation)
            int end = Math.min(index + chunkSize, text.length());
            
            if (end < text.length()) {
                // Try to find a good breaking point
                int breakPoint = text.lastIndexOf(' ', end);
                int punctuation = Math.max(
                    Math.max(text.lastIndexOf('.', end), text.lastIndexOf('!', end)),
                    Math.max(text.lastIndexOf('?', end), text.lastIndexOf(',', end))
                );
                
                // Prefer punctuation over space if it's close enough
                if (punctuation > breakPoint - 10 && punctuation > index) {
                    end = punctuation + 1;
                } else if (breakPoint > index) {
                    end = breakPoint + 1;
                }
            }
            
            chunks.add(text.substring(index, end));
            index = end;
        }
        
        return chunks.toArray(new String[0]);
    }

    @Override
    protected void process(List<Object> chunks) {
        System.out.println("Processing " + chunks.size() + " chunks from API");
        
        // Handle initialization chunk (empty string)
        boolean hasInitChunk = false;
        boolean hasTextChunks = false;
        boolean hasCompletionSignal = false;
        ResponseInfo responseInfo = null;
        
        // First scan to identify what we're dealing with
        for (Object chunk : chunks) {
            if (chunk instanceof String) {
                String textChunk = (String)chunk;
                if (textChunk.isEmpty()) {
                    hasInitChunk = true;
                } else {
                    hasTextChunks = true;
                }
            } else if (chunk instanceof StreamingComplete) {
                hasCompletionSignal = true;
            } else if (chunk instanceof ResponseInfo) {
                responseInfo = (ResponseInfo)chunk;
            }
        }
        
        // Handle initialization chunk first if present
        if (hasInitChunk) {
            System.out.println("Initializing streaming bubble with empty string");
            chatPanel.addAIResponse("");
        }
        
        // Collect and process all text chunks
        if (hasTextChunks) {
            StringBuilder combinedText = new StringBuilder();
            for (Object chunk : chunks) {
                if (chunk instanceof String && !((String)chunk).isEmpty()) {
                    combinedText.append(chunk);
                }
            }
            
            if (combinedText.length() > 0) {
                System.out.println("Adding streaming text, length: " + combinedText.length());
                chatPanel.addAIResponse(combinedText.toString());
            }
        }
        
        // Handle streaming completion (must be after text processing)
        if (hasCompletionSignal) {
            System.out.println("Finalizing streaming response");
            chatPanel.finalizeStreamingResponse();
        }
        
        // Finally, handle response info for feedback UI (only happens once)
        if (responseInfo != null) {
            System.out.println("Processing complete response info: " + responseInfo.getResponseId());
            
            if (responseInfo.getResponseId() != null && !responseInfo.getResponseId().isEmpty()) {
                System.out.println("Response ID received: " + responseInfo.getResponseId());
                // The response ID is already stored in APIClient during save, no need to update it here
            }
        }
    }
    
    @Override
    protected void done() {
        try {
            get(); // Will re-throw any exception that occurred
            
            // Re-enable the input field using the static reference
            SwingUtilities.invokeLater(() -> {
                // Try to find InputPanel through various methods
                System.out.println("Trying to re-enable input field...");
                
                // First, try using the static reference
                com.example.demo11.ui.InputPanel inputPanel = com.example.demo11.SidepanelFactory.getCurrentInputPanel();
                if (inputPanel != null) {
                    System.out.println("Found InputPanel through static reference, re-enabling input...");
                    inputPanel.setInputEnabled(true);
                    // Make sure submitButton is disabled after re-enabling input
                    inputPanel.disableSubmitButton();
                    return;
                }
                
                // If static reference fails, try finding through parent hierarchy
                Component parent = chatPanel.getParent();
                if (parent != null) {
                    System.out.println("Found parent container, looking for InputPanel...");
                    // Look for the InputPanel in the same container as the ChatPanel
                    if (parent instanceof Container) {
                        Container container = (Container) parent;
                        boolean found = false;
                        for (Component component : container.getComponents()) {
                            if (component instanceof com.example.demo11.ui.InputPanel) {
                                System.out.println("InputPanel found, re-enabling input...");
                                com.example.demo11.ui.InputPanel panel = (com.example.demo11.ui.InputPanel)component;
                                panel.setInputEnabled(true);
                                // Make sure submitButton is disabled after re-enabling input
                                panel.disableSubmitButton();
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("WARNING: InputPanel not found in container. Components: " + container.getComponentCount());
                            // Try using the original method as fallback
                            Component current = chatPanel;
                            while (current != null) {
                                current = current.getParent();
                                if (current instanceof com.example.demo11.ui.InputPanel) {
                                    System.out.println("Found InputPanel via parent hierarchy instead");
                                    com.example.demo11.ui.InputPanel panel = (com.example.demo11.ui.InputPanel)current;
                                    panel.setInputEnabled(true);
                                    // Make sure submitButton is disabled after re-enabling input
                                    panel.disableSubmitButton();
                                    break;
                                }
                            }
                        }
                    } else {
                        System.out.println("WARNING: ChatPanel parent is not a Container");
                    }
                } else {
                    System.out.println("WARNING: ChatPanel parent is null, cannot find InputPanel through hierarchy");
                    System.out.println("Trying fallback options...");
                    
                    // Last resort: Try to find all InputPanel instances
                    findAndEnableInputPanels();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            chatPanel.addAIResponse("Error: " + e.getMessage());
            System.err.println("Error in done(): " + e.getMessage());
            
            // Re-enable input even if there was an error
            SwingUtilities.invokeLater(() -> {
                System.out.println("Enabling input after error...");
                
                // Try static reference first
                com.example.demo11.ui.InputPanel inputPanel = com.example.demo11.SidepanelFactory.getCurrentInputPanel();
                if (inputPanel != null) {
                    System.out.println("Found InputPanel through static reference after error, re-enabling input...");
                    inputPanel.setInputEnabled(true);
                    // Make sure submitButton is disabled after re-enabling input
                    inputPanel.disableSubmitButton();
                    return;
                }
                
                // Fallback to hierarchy search
                Component parent = chatPanel.getParent();
                if (parent != null && parent instanceof Container) {
                    // Look for the InputPanel in the same container as the ChatPanel
                    Container container = (Container) parent;
                    boolean found = false;
                    for (Component component : container.getComponents()) {
                        if (component instanceof com.example.demo11.ui.InputPanel) {
                            System.out.println("InputPanel found after error, re-enabling input...");
                            com.example.demo11.ui.InputPanel panel = (com.example.demo11.ui.InputPanel)component;
                            panel.setInputEnabled(true);
                            // Make sure submitButton is disabled after re-enabling input
                            panel.disableSubmitButton();
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("WARNING: InputPanel not found after error, trying fallback...");
                        findAndEnableInputPanels();
                    }
                } else {
                    System.out.println("WARNING: ChatPanel parent is invalid after error, trying fallback...");
                    findAndEnableInputPanels();
                }
            });
        }
    }
    
    // Helper method to find all InputPanel instances in the window hierarchy
    private void findAndEnableInputPanels() {
        System.out.println("Searching all windows for InputPanel instances...");
        for (Window window : Window.getWindows()) {
            findInputPanelInWindow(window);
        }
    }
    
    // Recursively search for InputPanel in a window
    private void findInputPanelInWindow(Container container) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof com.example.demo11.ui.InputPanel) {
                System.out.println("Found InputPanel in window hierarchy, enabling...");
                com.example.demo11.ui.InputPanel panel = (com.example.demo11.ui.InputPanel) comp;
                panel.setInputEnabled(true);
                // Make sure submitButton is disabled after re-enabling input
                panel.disableSubmitButton();
                return;
            }
            
            if (comp instanceof Container) {
                findInputPanelInWindow((Container) comp);
            }
        }
    }
    
    // Inner class to track response information
    private static class ResponseInfo {
        private final long responseTime;
        private final String responseId;
        
        public ResponseInfo(long responseTime, String responseId) {
            this.responseTime = responseTime;
            this.responseId = responseId;
        }
        
        public long getResponseTime() {
            return responseTime;
        }
        
        public String getResponseId() {
            return responseId;
        }
    }
    
    // Class to signal streaming completion
    private static class StreamingComplete {
    }
    
    // Class to track HTTP response status code from the API
    private static class ResponseStatusInfo {
        private final int statusCode;
        
        public ResponseStatusInfo(int statusCode) {
            this.statusCode = statusCode;
        }
        
        public int getStatusCode() {
            return statusCode;
        }
    }
}
