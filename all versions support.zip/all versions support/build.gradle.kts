plugins {
  id("java")
  id("org.jetbrains.kotlin.jvm") version "1.9.25"
  id("org.jetbrains.intellij") version "1.17.4"
}

group = "com.example"
version = "1.0-SNAPSHOT"

repositories {
  mavenCentral()
}

dependencies {
  implementation("org.json:json:20240303")
}

// Configure Gradle IntelliJ Plugin
// Read more: https://plugins.jetbrains.com/docs/intellij/tools-gradle-intellij-plugin.html
intellij {
  version.set("2021.3")  // Using a more compatible base version
  type.set("IC")  // Community edition for widest compatibility
  
  // Add required Java plugin dependency to match plugin.xml
  plugins.set(listOf("java"))
  
  // Support plugins marketplace downloads
  updateSinceUntilBuild.set(false)
  sandboxDir.set("${project.buildDir}/idea-sandbox")
}

tasks {
  // Set the JVM compatibility versions
  withType<JavaCompile> {
    sourceCompatibility = "11"  // Changed to 11 for wider compatibility
    targetCompatibility = "11"  // Changed to 11 for wider compatibility
  }
  withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile> {
    kotlinOptions.jvmTarget = "11"  // Changed to 11 for wider compatibility
  }

  patchPluginXml {
    // Remove version restrictions to work across different IDE versions
    sinceBuild.set("145")        // Support from 2020.3
    untilBuild.set("999.*")      // Support for all future versions
    
    // Add PyCharm and IntelliJ IDEA compatibility
    pluginDescription.set("""
      This plugin works with all JetBrains IDEs including:
      - IntelliJ IDEA (All versions)
      - PyCharm (All versions)
      - All other IntelliJ-based IDEs
      
      Compatible with IDE versions from 2020.3 onwards.
    """)
    
    // Define which products this plugin is compatible with
    changeNotes.set("""
      <ul>
        <li>Compatible with IntelliJ IDEA (all versions)</li>
        <li>Compatible with PyCharm (all versions)</li>
        <li>Support for all IDE versions from 2020.3 and newer</li>
      </ul>  
    """)
  }

  signPlugin {
    certificateChain.set(System.getenv("CERTIFICATE_CHAIN"))
    privateKey.set(System.getenv("PRIVATE_KEY"))
    password.set(System.getenv("PRIVATE_KEY_PASSWORD"))
  }

  publishPlugin {
    token.set(System.getenv("PUBLISH_TOKEN"))
  }
}
