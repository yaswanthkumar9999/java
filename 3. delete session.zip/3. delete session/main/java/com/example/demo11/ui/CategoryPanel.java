package com.example.demo11.ui;

import com.intellij.openapi.util.IconLoader;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.editor.SelectionModel;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.project.ProjectManager;
import com.intellij.openapi.ui.popup.JBPopupFactory;
import com.intellij.openapi.ui.popup.Balloon;
import com.intellij.openapi.ui.popup.BalloonBuilder;
import com.intellij.openapi.ui.MessageType;
import com.intellij.openapi.wm.WindowManager;
import com.intellij.ui.JBColor;
import com.intellij.ui.awt.RelativePoint;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CategoryPanel extends JPanel {
    // Constants for category options
    private static final String[] CATEGORY_OPTIONS = {"Test", "Documentation", "Debug", "Refactor", "Optimize"};
    private static final String[] CATEGORY_ICONS = {"/icons/test.png", "/icons/documentation.jpg", 
                                                   "/icons/debug.png", "/icons/refactor.jfif", 
                                                   "/icons/optimize.png"};
    // Category IDs for API
    private static final int[] CATEGORY_IDS = {1, 3, 4, 5, 6}; // Test, Documentation, Debug, Refactor, Optimize
    
    private static final Color CATEGORY_TEXT_COLOR = Color.WHITE;
    private static final Color CATEGORY_HOVER_COLOR = new Color(235, 235, 235);
    private static final int CATEGORY_BOX_PADDING = 10;
    private static final int CATEGORY_BOX_SPACING = 20;
    private static final int CATEGORY_ICON_SIZE = 20;
    
    private final ChatPanel chatPanel;
    private boolean isVisible = false;
    private JPanel optionsContainer;

    public CategoryPanel(ChatPanel chatPanel) {
        this.chatPanel = chatPanel;
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        setOpaque(false);
        setVisible(false); // Initially hidden
        
        // Create the options container
        optionsContainer = createOptionsPanel();
        add(optionsContainer, BorderLayout.CENTER);
    }
    
    private JPanel createOptionsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setOpaque(false);
        
        // First row - Test and Documentation
        JPanel firstRow = new JPanel(new FlowLayout(FlowLayout.CENTER, CATEGORY_BOX_SPACING, 0));
        firstRow.setOpaque(false);
        firstRow.add(createCategoryBox(0)); // Test
        firstRow.add(createCategoryBox(1)); // Documentation
        panel.add(firstRow);
        
        panel.add(Box.createVerticalStrut(10));
        
        // Second row - Debug and Refactor
        JPanel secondRow = new JPanel(new FlowLayout(FlowLayout.CENTER, CATEGORY_BOX_SPACING, 0));
        secondRow.setOpaque(false);
        secondRow.add(createCategoryBox(2)); // Debug
        secondRow.add(createCategoryBox(3)); // Refactor
        panel.add(secondRow);
        
        panel.add(Box.createVerticalStrut(10));
        
        // Third row - Optimize (centered)
        JPanel thirdRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        thirdRow.setOpaque(false);
        thirdRow.add(createCategoryBox(4)); // Optimize
        panel.add(thirdRow);
        
        return panel;
    }
    
    private JPanel createCategoryBox(int index) {
        String categoryName = CATEGORY_OPTIONS[index];
        String iconPath = CATEGORY_ICONS[index];
        int categoryId = CATEGORY_IDS[index];
        
        // Create box panel with border but transparent background
        JPanel boxPanel = new JPanel(new BorderLayout(10, 0));
        boxPanel.setOpaque(false); // Make it transparent
        boxPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 220, 220), 1, true),
                BorderFactory.createEmptyBorder(CATEGORY_BOX_PADDING, CATEGORY_BOX_PADDING, 
                                             CATEGORY_BOX_PADDING, CATEGORY_BOX_PADDING)));
        
        // Set a minimum and preferred size for the box - make it wider to ensure text is visible
        boxPanel.setMinimumSize(new Dimension(150, 45));
        boxPanel.setPreferredSize(new Dimension(180, 45));
        
        // Add icon
        JLabel iconLabel = new JLabel();
        try {
            Icon icon = IconLoader.getIcon(iconPath);
            if (icon instanceof ImageIcon) {
                ImageIcon originalIcon = (ImageIcon) icon;
                Image scaledImage = originalIcon.getImage().getScaledInstance(
                        CATEGORY_ICON_SIZE, CATEGORY_ICON_SIZE, Image.SCALE_SMOOTH);
                ImageIcon scaledIcon = new ImageIcon(scaledImage);
                iconLabel.setIcon(scaledIcon);
            } else {
                iconLabel.setIcon(icon);
            }
        } catch (Exception e) {
            // Fallback if icon can't be loaded
            iconLabel.setText("📁");
        }
        
        iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
        boxPanel.add(iconLabel, BorderLayout.WEST);
        
        // Add text - make it more prominent with white color
        JLabel textLabel = new JLabel(categoryName);
        textLabel.setForeground(CATEGORY_TEXT_COLOR);
        textLabel.setFont(new Font(textLabel.getFont().getName(), Font.BOLD, 13));
        // Add some padding to the text label
        textLabel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        boxPanel.add(textLabel, BorderLayout.CENTER);
        
        // Add hover effect and click handling
        boxPanel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                boxPanel.setCursor(new Cursor(Cursor.HAND_CURSOR));
                // No color change on hover
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                // No color change on exit
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                System.out.println("Category option clicked: " + categoryName);
                
                // Get selected text from the active editor
                String selectedText = getSelectedTextFromEditor();
                
                // Check if we have selected text
                if (selectedText != null && !selectedText.trim().isEmpty()) {
                    System.out.println("Selected text found, sending to chat");
                    
                    // Set the category ID for backend request
                    chatPanel.setCategoryId(categoryId);
                    
                    // Add selected text as a message to the chat panel
                    chatPanel.addUserMessage(selectedText);
                    
                    // Get the InputPanel from SidepanelFactory to send the message
                    try {
                        // Get the current input panel from SidepanelFactory
                        com.example.demo11.ui.InputPanel inputPanel = 
                            com.example.demo11.SidepanelFactory.getCurrentInputPanel();
                        
                        if (inputPanel != null) {
                            // This will trigger the API call with the current category ID
                            inputPanel.sendMessage(selectedText);
                        } else {
                            System.err.println("Failed to get InputPanel reference");
                        }
                    } catch (Exception ex) {
                        System.err.println("Error sending message: " + ex.getMessage());
                        ex.printStackTrace();
                    }
                    
                    // Hide the category panel
                    setVisible(false);
                } else {
                    System.out.println("No text selected, showing warning");
                    // Show warning popup
                    showWarningPopup("Please select some code before using this option.");
                }
            }
        });
        
        return boxPanel;
    }
    
    /**
     * Gets the currently selected text from the active editor
     */
    private String getSelectedTextFromEditor() {
        try {
            Project[] projects = ProjectManager.getInstance().getOpenProjects();
            if (projects.length == 0) {
                System.out.println("No open projects found");
                return null;
            }
            
            // Get the active project
            Project project = projects[0];
            Editor editor = FileEditorManager.getInstance(project).getSelectedTextEditor();
            
            if (editor == null) {
                System.out.println("No active editor found");
                return null;
            }
            
            SelectionModel selectionModel = editor.getSelectionModel();
            if (selectionModel.hasSelection()) {
                String selectedText = selectionModel.getSelectedText();
                System.out.println("Selected text: " + (selectedText != null ? selectedText : "null"));
                return selectedText;
            } else {
                System.out.println("No text is selected in editor");
                return null;
            }
        } catch (Exception e) {
            System.err.println("Error getting selected text: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Shows a warning popup at the bottom right of the IDE
     */
    private void showWarningPopup(String message) {
        SwingUtilities.invokeLater(() -> {
            try {
                Project[] projects = ProjectManager.getInstance().getOpenProjects();
                if (projects.length == 0) return;
                
                Project project = projects[0];
                
                // Get IDE frame
                JFrame ideFrame = WindowManager.getInstance().getIdeFrame(project).getComponent().getRootPane().getParent() instanceof JFrame ? 
                    (JFrame) WindowManager.getInstance().getIdeFrame(project).getComponent().getRootPane().getParent() : null;
                
                if (ideFrame == null) {
                    System.err.println("Could not find IDE frame, falling back to dialog");
                    JOptionPane.showMessageDialog(null, message, "Warning", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                // Create balloon with error message
                BalloonBuilder builder = JBPopupFactory.getInstance()
                        .createHtmlTextBalloonBuilder(
                                "<html><body><strong>Warning:</strong> " + message + "</body></html>", 
                                MessageType.WARNING, 
                                null)
                        .setFadeoutTime(3000)
                        .setHideOnClickOutside(true)
                        .setHideOnKeyOutside(true)
                        .setHideOnAction(true)
                        .setShadow(true);
                
                Balloon balloon = builder.createBalloon();
                
                // Position balloon at bottom right corner of IDE frame
                int x = ideFrame.getWidth() - 20; 
                int y = ideFrame.getHeight() - 40;
                
                // Show balloon at the bottom right
                balloon.show(new RelativePoint(ideFrame, new Point(x, y)), Balloon.Position.above);
                
            } catch (Exception e) {
                // Log the error
                System.err.println("Error showing warning popup: " + e.getMessage());
                e.printStackTrace();
                
                // Fallback to simple message if popup fails
                JOptionPane.showMessageDialog(null, message, "Warning", JOptionPane.WARNING_MESSAGE);
            }
        });
    }
    
    /**
     * Sets the category ID for the backend request
     */
    private void setCategoryId(int categoryId) {
        try {
            // Call API with the selected category ID
            // This needs to be implemented based on how your backend API is structured
            System.out.println("Category selected: " + categoryId);
            
            // You might need to implement this method in your ChatPanel class
            chatPanel.setCategoryId(categoryId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void toggleVisibility() {
        setVisible(!isVisible());
        isVisible = isVisible();
        revalidate();
        repaint();
    }
} 