package com.example.demo11.ui;

import com.example.demo11.SidepanelFactory;
import com.intellij.openapi.util.IconLoader;
import javax.swing.*;
import java.awt.*;

public class HeaderPanel extends JPanel {
    private JComboBox<String> modelComboBox;
    private JButton refreshButton;
    private JButton categoryButton;
    private JButton historyButton;
    private JButton backButton;
    private JLabel titleLabel;
    private JPanel leftPanel;
    private JPanel rightPanel;
    private SidepanelFactory factory;
    private ChatPanel chatPanel;
    private InputPanel inputPanel; // Will be set later
    private CategoryPanel categoryPanel; // Will be set later
    private HistoryPanel historyPanel; // Will be set later
    private CardLayout cardLayout;
    private JPanel cardPanel;

    public HeaderPanel(SidepanelFactory factory, ChatPanel chatPanel) {
        this.factory = factory;
        this.chatPanel = chatPanel;

        setLayout(new BorderLayout());
        // Add border to the entire header panel
        setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 1));
        setBackground(Color.DARK_GRAY);

        // Card panel to switch between normal and history mode
        cardPanel = new JPanel();
        cardLayout = new CardLayout();
        cardPanel.setLayout(cardLayout);
        cardPanel.setOpaque(false);

        // Normal mode panel
        JPanel normalPanel = new JPanel(new BorderLayout());
        normalPanel.setOpaque(false);

        // Left panel for model selection.
        leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        leftPanel.setOpaque(false);
        JLabel modelLabel = new JLabel("Model: ");
        modelLabel.setForeground(Color.WHITE);
        modelComboBox = new JComboBox<>(new String[]{"Professional", "Simple"});
        leftPanel.add(modelLabel);
        leftPanel.add(modelComboBox);

        // Right panel with buttons
        rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.setOpaque(false);
        
        // Category button
        categoryButton = new JButton(IconLoader.getIcon("/icons/category.jfif"));
        categoryButton.setToolTipText("Category");
        categoryButton.setFocusPainted(false);
        categoryButton.setBorderPainted(false);
        categoryButton.setContentAreaFilled(false);
        categoryButton.setOpaque(false);
        categoryButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // History button
        historyButton = new JButton(IconLoader.getIcon("/icons/history.jfif"));
        historyButton.setToolTipText("Chat History");
        historyButton.setFocusPainted(false);
        historyButton.setBorderPainted(false);
        historyButton.setContentAreaFilled(false);
        historyButton.setOpaque(false);
        historyButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Refresh button
        refreshButton = new JButton(IconLoader.getIcon("/icons/refresh.png"));
        refreshButton.setToolTipText("Start New Chat");
        refreshButton.setFocusPainted(false);
        refreshButton.setBorderPainted(false);
        refreshButton.setContentAreaFilled(false);
        refreshButton.setOpaque(false);
        refreshButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add category button action
        categoryButton.addActionListener(e -> {
            if (categoryPanel != null) {
                categoryPanel.toggleVisibility();
            }
        });
        
        // Add history button action
        historyButton.addActionListener(e -> {
            if (historyPanel != null) {
                historyPanel.toggleVisibility();
            }
        });

        // Refresh button action: calls factory.resetSession with inputPanel and chatPanel.
        refreshButton.addActionListener(e -> {
            if (inputPanel != null && chatPanel != null) {
                factory.resetSession(inputPanel, chatPanel);
            }
        });

        // Add buttons to right panel
        rightPanel.add(categoryButton);
        rightPanel.add(historyButton);
        rightPanel.add(refreshButton);

        normalPanel.add(leftPanel, BorderLayout.WEST);
        normalPanel.add(rightPanel, BorderLayout.EAST);
        
        // History mode panel
        JPanel historyModePanel = new JPanel(new BorderLayout());
        historyModePanel.setOpaque(false);
        
        // Title label for history mode
        titleLabel = new JLabel("Chat History");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font(titleLabel.getFont().getName(), Font.BOLD, 14));
        
        // Back button
        backButton = new JButton("Back");
        backButton.setFocusPainted(false);
        backButton.setToolTipText("Back to Chat");
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        backButton.addActionListener(e -> {
            if (historyPanel != null) {
                historyPanel.toggleVisibility();
            }
        });
        
        JPanel historyTitlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        historyTitlePanel.setOpaque(false);
        historyTitlePanel.add(titleLabel);
        
        JPanel historyButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        historyButtonPanel.setOpaque(false);
        historyButtonPanel.add(backButton);
        
        historyModePanel.add(historyTitlePanel, BorderLayout.WEST);
        historyModePanel.add(historyButtonPanel, BorderLayout.EAST);
        
        // Add panels to card layout
        cardPanel.add(normalPanel, "normal");
        cardPanel.add(historyModePanel, "history");
        
        // Show normal mode by default
        cardLayout.show(cardPanel, "normal");
        
        add(cardPanel, BorderLayout.CENTER);
    }

    public void showHistoryMode(boolean showHistory) {
        if (showHistory) {
            cardLayout.show(cardPanel, "history");
        } else {
            cardLayout.show(cardPanel, "normal");
        }
    }

    public JComboBox<String> getModelComboBox() {
        return modelComboBox;
    }

    public void setInputPanel(InputPanel inputPanel) {
        this.inputPanel = inputPanel;
    }
    
    public void setCategoryPanel(CategoryPanel categoryPanel) {
        this.categoryPanel = categoryPanel;
    }
    
    public void setHistoryPanel(HistoryPanel historyPanel) {
        this.historyPanel = historyPanel;
    }
}
