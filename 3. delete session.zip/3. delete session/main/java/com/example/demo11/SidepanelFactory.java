package com.example.demo11;

import com.example.demo11.ui.APIKeyValidationPanel;
import com.example.demo11.ui.ChatPanel;
import com.example.demo11.ui.HeaderPanel;
import com.example.demo11.ui.InputPanel;
import com.example.demo11.ui.CategoryPanel;
import com.example.demo11.ui.HistoryPanel;
import com.example.demo11.api.SessionHistoryWorker;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowFactory;
import com.intellij.ui.content.Content;
import com.intellij.ui.content.ContentFactory;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.awt.*;

public class SidepanelFactory implements ToolWindowFactory {
    private static String sessionId;
    private static InputPanel currentInputPanel;
    private static CategoryPanel currentCategoryPanel;
    private static HistoryPanel currentHistoryPanel;

    @Override
    public void createToolWindowContent(@NotNull Project project, @NotNull ToolWindow toolWindow) {
        // Create main panel with card layout to switch between validation and chat
        JPanel mainPanel = new JPanel(new CardLayout());
        mainPanel.setBackground(new Color(43, 43, 43));

        // Create API Key validation panel
        APIKeyValidationPanel validationPanel = new APIKeyValidationPanel(() -> {
            // This will be called when API key is validated successfully
            // Generate session ID when chat panel is first shown
            sessionId = SessionHistoryWorker.generateSessionID(com.example.demo11.config.APIConfig.API_KEY);
            
            CardLayout cl = (CardLayout) mainPanel.getLayout();
            cl.show(mainPanel, "chat");
        });

        // Create chat panel components
        JPanel chatPanelContainer = new JPanel(new BorderLayout());
        chatPanelContainer.setBackground(new Color(43, 43, 43));

        // Create chat panel first
        ChatPanel chatPanel = new ChatPanel();
        // Create header panel with references to factory and chatPanel
        HeaderPanel headerPanel = new HeaderPanel(this, chatPanel);
        // Create category panel
        CategoryPanel categoryPanel = new CategoryPanel(chatPanel);
        currentCategoryPanel = categoryPanel;
        // Create history panel
        HistoryPanel historyPanel = new HistoryPanel(chatPanel, headerPanel);
        currentHistoryPanel = historyPanel;
        // Create input panel now and pass the header panel
        InputPanel inputPanel = new InputPanel(chatPanel, headerPanel, this);
        // Store the input panel reference
        currentInputPanel = inputPanel;
        // Set initial session ID for the input panel
        inputPanel.setSessionId(sessionId);
        // Let header panel know about the input panel (for refresh action)
        headerPanel.setInputPanel(inputPanel);
        // Let header panel know about the category panel (for category button action)
        headerPanel.setCategoryPanel(categoryPanel);
        // Let header panel know about the history panel (for history button action)
        headerPanel.setHistoryPanel(historyPanel);

        // Create center panel to stack chat panel and history panel
        JPanel centerPanel = new JPanel(new CardLayout());
        centerPanel.add(chatPanel.getScrollPane(), "chat");
        centerPanel.add(historyPanel.getScrollPane(), "history");
        
        // Listen for history panel visibility changes to show appropriate center panel
        historyPanel.addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentShown(java.awt.event.ComponentEvent e) {
                ((CardLayout) centerPanel.getLayout()).show(centerPanel, "history");
            }
            
            @Override
            public void componentHidden(java.awt.event.ComponentEvent e) {
                ((CardLayout) centerPanel.getLayout()).show(centerPanel, "chat");
            }
        });

        // Create south panel to hold both category and input panels
        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.add(categoryPanel, BorderLayout.NORTH);
        southPanel.add(inputPanel, BorderLayout.CENTER);

        chatPanelContainer.add(headerPanel, BorderLayout.NORTH);
        chatPanelContainer.add(centerPanel, BorderLayout.CENTER);
        chatPanelContainer.add(southPanel, BorderLayout.SOUTH);

        // Add both panels to the card layout
        mainPanel.add(validationPanel, "validation");
        mainPanel.add(chatPanelContainer, "chat");

        // Show validation panel first
        CardLayout cl = (CardLayout) mainPanel.getLayout();
        cl.show(mainPanel, "validation");

        Content content = ContentFactory.getInstance().createContent(mainPanel, "", false);
        toolWindow.getContentManager().addContent(content);
    }

    // Called when the refresh button is pressed in HeaderPanel
    public void resetSession(InputPanel inputPanel, ChatPanel chatPanel) {
        sessionId = SessionHistoryWorker.generateSessionID(com.example.demo11.config.APIConfig.API_KEY);
        chatPanel.clearChat();
        chatPanel.setCurrentModel("default"); // Reset the model to default
        inputPanel.setSessionId(sessionId);
        currentInputPanel = inputPanel;
        
        // Hide the category panel if it's visible
        if (currentCategoryPanel != null) {
            currentCategoryPanel.setVisible(false);
            currentCategoryPanel.revalidate();
            currentCategoryPanel.repaint();
        }
        
        // Hide the history panel if it's visible
        if (currentHistoryPanel != null) {
            currentHistoryPanel.setVisible(false);
            currentHistoryPanel.revalidate();
            currentHistoryPanel.repaint();
        }
    }

    public static String getSessionId() {
        return sessionId;
    }
    
    public static InputPanel getCurrentInputPanel() {
        return currentInputPanel;
    }
    
    public static CategoryPanel getCurrentCategoryPanel() {
        return currentCategoryPanel;
    }
    
    public static HistoryPanel getCurrentHistoryPanel() {
        return currentHistoryPanel;
    }
}
