package com.example.demo11.api;

import com.example.demo11.config.APIConfig;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class SessionHistoryWorker {
    public static String generateSessionID(String apiKey) {
        try {
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            String data = apiKey + timestamp;
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error generating session ID", e);
        }
    }
    
    public static List<SessionHistory> getSessionHistory() throws Exception {
        List<SessionHistory> sessionHistoryList = new ArrayList<>();
        
        String endpoint = APIConfig.GET_SESSION_IDS_ENDPOINT;
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
        connection.setDoOutput(true);
        
        // Create payload
        String jsonPayload = "{\"ide_type\":7}";
        
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = jsonPayload.getBytes("utf-8");
            os.write(input, 0, input.length);
        }
        
        int responseCode = connection.getResponseCode();
        
        if (responseCode == 200) {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                
                // Parse JSON response
                JSONObject jsonResponse = new JSONObject(response.toString());
                if (jsonResponse.getString("status").equals("Success")) {
                    JSONArray resultArray = jsonResponse.getJSONArray("result");
                    
                    for (int i = 0; i < resultArray.length(); i++) {
                        JSONObject sessionObj = resultArray.getJSONObject(i);
                        String sessionId = sessionObj.getString("session_id");
                        String createdDate = sessionObj.getString("created_date");
                        int count = sessionObj.getInt("count");
                        String firstPrompt = sessionObj.getString("first_prompt");
                        
                        sessionHistoryList.add(new SessionHistory(sessionId, createdDate, count, firstPrompt));
                    }
                }
            }
        }
        
        connection.disconnect();
        return sessionHistoryList;
    }
    
    public static boolean deleteSession(String sessionId) throws Exception {
        String endpoint = APIConfig.DELETE_SESSION_ENDPOINT + "/" + sessionId;
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("DELETE");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
        
        int responseCode = connection.getResponseCode();
        boolean success = responseCode == 200;
        
        if (success) {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                StringBuilder response = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                
                // You can parse the response here if needed
                System.out.println("Delete Session Response: " + response.toString());
            }
        } else {
            System.err.println("Failed to delete session: HTTP " + responseCode);
        }
        
        connection.disconnect();
        return success;
    }
}
