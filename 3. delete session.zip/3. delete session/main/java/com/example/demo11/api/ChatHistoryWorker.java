package com.example.demo11.api;

import com.example.demo11.config.APIConfig;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ChatHistoryWorker {
    public static class ChatHistoryItem {
        private final int id;
        private final String prompt;
        private final String response;
        private Integer rating;
        private String feedback;
        private final String timestamp;

        public ChatHistoryItem(int id, String prompt, String response, Integer rating, String feedback, String timestamp) {
            this.id = id;
            this.prompt = prompt;
            this.response = response;
            this.rating = rating;
            this.feedback = feedback;
            this.timestamp = timestamp;
        }

        public int getId() { return id; }
        public String getPrompt() { return prompt; }
        public String getResponse() { return response; }
        public Integer getRating() { return rating; }
        public String getFeedback() { return feedback; }
        public String getTimestamp() { return timestamp; }
        public void setRating(Integer rating) { this.rating = rating; }
        public void setFeedback(String feedback) { this.feedback = feedback; }
    }

    public static List<ChatHistoryItem> getChatHistory(String sessionId, int index, int limit) throws Exception {
        List<ChatHistoryItem> chatHistoryList = new ArrayList<>();
        
        String endpoint = APIConfig.GET_CHAT_HISTORY_ENDPOINT;
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
        connection.setDoOutput(true);
        
        // Create payload
        String jsonPayload = String.format(
            "{\"index\":%d,\"limit\":%d,\"ide_type\":7,\"session_id\":\"%s\"}",
            index, limit, sessionId
        );
        
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = jsonPayload.getBytes("utf-8");
            os.write(input, 0, input.length);
        }
        
        int responseCode = connection.getResponseCode();
        
        if (responseCode == 200) {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                StringBuilder apiResponse = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    apiResponse.append(inputLine);
                }
                
                // Parse JSON response
                JSONObject jsonResponse = new JSONObject(apiResponse.toString());
                if (jsonResponse.getString("status").equals("Success")) {
                    JSONArray resultArray = jsonResponse.getJSONArray("result");
                    
                    for (int i = 0; i < resultArray.length(); i++) {
                        JSONObject chatObj = resultArray.getJSONObject(i);
                        int id = chatObj.getInt("ps_user_prompt_history_id");
                        String prompt = chatObj.getString("prompt");
                        String messageResponse = chatObj.getString("response");
                        Integer rating = chatObj.isNull("rating") ? null : chatObj.getInt("rating");
                        String feedback = chatObj.isNull("feedback") ? null : chatObj.getString("feedback");
                        String timestamp = chatObj.getString("timestamp");
                        
                        chatHistoryList.add(new ChatHistoryItem(id, prompt, messageResponse, rating, feedback, timestamp));
                    }
                }
            }
        }
        
        connection.disconnect();
        return chatHistoryList;
    }
} 