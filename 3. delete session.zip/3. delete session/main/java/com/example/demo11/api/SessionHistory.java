package com.example.demo11.api;

public class SessionHistory {
    private String sessionId;
    private String createdDate;
    private int count;
    private String firstPrompt;

    public SessionHistory(String sessionId, String createdDate, int count, String firstPrompt) {
        this.sessionId = sessionId;
        this.createdDate = createdDate;
        this.count = count;
        this.firstPrompt = firstPrompt;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public int getCount() {
        return count;
    }

    public String getFirstPrompt() {
        return firstPrompt;
    }

    public String getDisplayName() {
        if (firstPrompt != null && firstPrompt.length() > 20) {
            return firstPrompt.substring(0, 20) + "...";
        }
        return firstPrompt;
    }
} 