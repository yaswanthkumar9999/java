package com.example.demo11.utils;

import javax.swing.border.Border;
import java.awt.*;

public class RoundedBorder implements Border {
    private final int radius;
    private final int thickness;
    private final Color borderColor;
    private final Color backgroundColor;
    private final boolean fillBackground;

    public RoundedBorder(int thickness, int radius) {
        this(thickness, radius, Color.LIGHT_GRAY, null, false);
    }
    
    public RoundedBorder(int thickness, int radius, Color borderColor, Color backgroundColor, boolean fillBackground) {
        this.thickness = thickness;
        this.radius = radius;
        this.borderColor = borderColor;
        this.backgroundColor = backgroundColor;
        this.fillBackground = fillBackground;
    }

    @Override
    public Insets getBorderInsets(Component c) {
        return new Insets(thickness + radius/2, thickness + radius/2, thickness + radius/2, thickness + radius/2);
    }

    @Override
    public boolean isBorderOpaque() {
        return fillBackground;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Fill background if specified with solid colors (no transparency)
        if (fillBackground && backgroundColor != null) {
            g2d.setColor(backgroundColor);
            g2d.fillRoundRect(
                    x,
                    y,
                    width - 1,
                    height - 1,
                    radius,
                    radius
            );
        }
        
        // Draw border with stronger thickness
        g2d.setColor(borderColor);
        g2d.setStroke(new BasicStroke(Math.max(thickness, 2)));
        g2d.drawRoundRect(
                x + thickness/2,
                y + thickness/2,
                width - thickness - 1,
                height - thickness - 1,
                radius,
                radius
        );
        g2d.dispose();
    }
}