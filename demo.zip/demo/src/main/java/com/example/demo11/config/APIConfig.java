package com.example.demo11.config;

public class APIConfig {
    // Change the BASE_URL if your backend server IP/port changes.
    public static final String BASE_URL = "http://localhost:3000";

    // Endpoints.
    public static final String VALIDATE_API_KEY_ENDPOINT = BASE_URL + "/validate-key";
    public static final String STREAM_CHAT_ENDPOINT = BASE_URL + "/stream-chat";
    public static final String HISTORY_ENDPOINT = BASE_URL + "/save";
    public static final String FEEDBACK_ENDPOINT = BASE_URL + "/feedback";

    // API Key is set by the user.
    public static String API_KEY = "";

    public static void setApiKey(String apiKey) {
        API_KEY = apiKey;
    }
}
