package com.example.demo11.ui;

import com.example.demo11.api.APIClient;
import com.example.demo11.config.APIConfig;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URI;

public class APIKeyValidationPanel extends JPanel {
    private JTextField apiKeyField;
    private JButton validateButton;
    private JLabel messageLabel;
    private static final String PLACEHOLDER_TEXT = "Enter API Key";
    private final Runnable onValidationSuccess;

    public APIKeyValidationPanel(Runnable onValidationSuccess) {
        this.onValidationSuccess = onValidationSuccess;
        setLayout(new GridBagLayout());
        setBackground(new Color(43, 43, 43)); // Dark background

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.CENTER;

        // API Key input field with placeholder
        JLabel promptLabel = new JLabel("API Key:");
        promptLabel.setForeground(Color.WHITE);
        apiKeyField = new JTextField(20);
        apiKeyField.setPreferredSize(new Dimension(200, 35));
        apiKeyField.setForeground(Color.WHITE);
        apiKeyField.setBackground(new Color(60, 60, 60));
        apiKeyField.setCaretColor(Color.WHITE);
        apiKeyField.setText(PLACEHOLDER_TEXT);

        // Placeholder behavior
        apiKeyField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (apiKeyField.getText().equals(PLACEHOLDER_TEXT)) {
                    apiKeyField.setText("");
                    apiKeyField.setForeground(Color.WHITE);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (apiKeyField.getText().isEmpty()) {
                    apiKeyField.setText(PLACEHOLDER_TEXT);
                    apiKeyField.setForeground(Color.GRAY);
                }
            }
        });

        // Create validate button
        validateButton = new JButton("Validate") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        validateButton.setFont(new Font("Arial", Font.BOLD, 14));
        validateButton.setForeground(Color.WHITE);
        validateButton.setBackground(new Color(0, 102, 204));
        validateButton.setOpaque(false);
        validateButton.setContentAreaFilled(false);
        validateButton.setBorderPainted(false);
        validateButton.setFocusPainted(false);
        validateButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        validateButton.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        validateButton.setPreferredSize(new Dimension(90, 35));

        // Add hover and press effects
        validateButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                validateButton.setBackground(new Color(0, 122, 224));
                validateButton.repaint();
            }

            @Override
            public void mouseExited(MouseEvent e) {
                validateButton.setBackground(new Color(0, 102, 204));
                validateButton.repaint();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                validateButton.setBackground(new Color(0, 82, 184));
                validateButton.repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                validateButton.setBackground(new Color(0, 102, 204));
                validateButton.repaint();
            }
        });
        validateButton.repaint();
        // Error message label
        messageLabel = new JLabel(" ", SwingConstants.CENTER);
        messageLabel.setForeground(Color.RED);
        messageLabel.setPreferredSize(new Dimension(100, 20));

        // API Key link
        JPanel linkPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel apiKeyLink = new JLabel("<html><u>To get API Key: http://localhost:3001</u></html>");
        apiKeyLink.setForeground(new Color(0, 122, 224));
        apiKeyLink.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        apiKeyLink.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI("http://localhost:3000"));
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        linkPanel.add(apiKeyLink);

        // Layout components
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        add(promptLabel, gbc);

        gbc.gridx = 1;
        add(apiKeyField, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        add(validateButton, gbc);

        gbc.gridy = 2;
        add(messageLabel, gbc);

        gbc.gridy = 3;
        add(linkPanel, gbc);

        // Validate button action
        validateButton.addActionListener(e -> validateApiKey());
    }

    private void validateApiKey() {
        String apiKey = apiKeyField.getText().trim();

        if (apiKey.isEmpty() || apiKey.equals(PLACEHOLDER_TEXT)) {
            messageLabel.setText("Please enter the API Key.");
            return;
        }

        try {
            boolean valid = APIClient.validateApiKey(apiKey);
            if (valid) {
                APIConfig.setApiKey(apiKey);
                messageLabel.setText("API Key validated successfully!");
                messageLabel.setForeground(new Color(0, 150, 0));
                // Call the success callback after a short delay
                Timer timer = new Timer(1000, e -> {
                    onValidationSuccess.run();
                });
                timer.setRepeats(false);
                timer.start();
            } else {
                messageLabel.setText("Invalid API Key. Please enter a valid one.");
                messageLabel.setForeground(Color.RED);
            }
        } catch (Exception ex) {
            messageLabel.setText("Error: " + ex.getMessage());
            messageLabel.setForeground(Color.RED);
        }
    }
} 