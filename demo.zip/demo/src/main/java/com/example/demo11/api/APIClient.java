package com.example.demo11.api;

import com.example.demo11.config.APIConfig;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class APIClient {

    // Validates the API key by calling the backend endpoint.
    public static boolean validateApiKey(String apiKey) throws Exception {
        String endpoint = APIConfig.VALIDATE_API_KEY_ENDPOINT + "?apiKey=" + apiKey;
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);
        int status = connection.getResponseCode();
        connection.disconnect();
        return status == 200;
    }

    // Sends a question to the stream-chat endpoint.
    public static String askQuestion(String model, String question, String category, String sessionId) throws Exception {
        String endpoint = APIConfig.STREAM_CHAT_ENDPOINT;
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(15000);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
        connection.setDoOutput(true);

        question = question.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
        
        String jsonPayload = "{ \"prompt\": \"" + question + "\", \"model\": \"" + model + "\", \"category\": " + category + ", \"session_id\": \"" + sessionId + "\" }";
        System.out.println("Payload sending to backend: " + jsonPayload);
        
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = jsonPayload.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        int responseCode = connection.getResponseCode();
        System.out.println("API Response code: " + responseCode);
        
        if (responseCode != 200) {
            try (BufferedReader errorReader = new BufferedReader(new InputStreamReader(connection.getErrorStream()))) {
                StringBuilder errorResponse = new StringBuilder();
                String line;
                while ((line = errorReader.readLine()) != null) {
                    errorResponse.append(line).append("\n");
                }
                System.err.println("API Error: " + errorResponse.toString());
                return "Error from API (HTTP " + responseCode + "): " + errorResponse.toString();
            } catch (Exception e) {
                System.err.println("Error reading error stream: " + e.getMessage());
                return "Error from API (HTTP " + responseCode + ")";
            }
        }
        
        try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine).append("\n");
            }
            return response.toString();
        } catch (Exception e) {
            System.err.println("Error reading response: " + e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            connection.disconnect();
        }
    }

    // Sends a question to the stream-chat endpoint with time tracking
    public static ChatResult askQuestionWithTiming(String model, String question, String category, String sessionId) throws Exception {
        long startTime = System.currentTimeMillis();
        
        // First get the HTTP status code
        String endpoint = APIConfig.STREAM_CHAT_ENDPOINT;
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(15000);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
        connection.setDoOutput(true);

        question = question.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
        
        String jsonPayload = "{ \"prompt\": \"" + question + "\", \"model\": \"" + model + "\", \"category\": " + category + ", \"session_id\": \"" + sessionId + "\" }";
        System.out.println("Payload sending to backend: " + jsonPayload);
        
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = jsonPayload.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        int responseCode = connection.getResponseCode();
        System.out.println("API Response code: " + responseCode);
        
        String response;
        if (responseCode != 200) {
            try (BufferedReader errorReader = new BufferedReader(new InputStreamReader(connection.getErrorStream()))) {
                StringBuilder errorResponse = new StringBuilder();
                String line;
                while ((line = errorReader.readLine()) != null) {
                    errorResponse.append(line).append("\n");
                }
                System.err.println("API Error: " + errorResponse.toString());
                response = "Error from API (HTTP " + responseCode + "): " + errorResponse.toString();
            } catch (Exception e) {
                System.err.println("Error reading error stream: " + e.getMessage());
                response = "Error from API (HTTP " + responseCode + ")";
            }
        } else {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                StringBuilder responseBuilder = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    responseBuilder.append(inputLine).append("\n");
                }
                response = responseBuilder.toString();
            }
        }
        
        // Calculate elapsed time
        long endTime = System.currentTimeMillis();
        long timeTaken = endTime - startTime;
        
        String responseId = "";
        // Only save interaction if we got a 200 response
        if (responseCode == 200) {
            responseId = saveInteraction(question, response, timeTaken, sessionId);
        }
        
        // Create result object with the response, timing info, and ID
        ChatResult result = new ChatResult(response, timeTaken, responseId);
        
        connection.disconnect();
        return result;
    }
    
    // Save interaction data to the backend
    private static String saveInteraction(String question, String answer, long timeTaken, String sessionId) {
        try {
            String endpoint = APIConfig.HISTORY_ENDPOINT;
            URL url = new URL(endpoint);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
            connection.setDoOutput(true);
            
            // Clean the question and answer for JSON
            question = question.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
            answer = answer.replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
            
            // Create JSON payload
            String jsonPayload = String.format(
                "{\"question\": \"%s\", \"answer\": \"%s\", \"time_taken\": %d, \"session\": \"%s\"}",
                question, answer, timeTaken, sessionId
            );
            
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonPayload.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            int responseCode = connection.getResponseCode();
            String responseId = "";
            
            if (responseCode != 200) {
                System.err.println("Failed to save interaction data: HTTP " + responseCode);
            } else {
                System.out.println("Interaction data saved successfully");
                
                // Read the response to get the ID
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                    
                    String responseText = response.toString();
                    System.out.println("Save API Response: " + responseText);
                    
                    // First check if response is just a plain ID (number)
                    if (responseText != null && !responseText.isEmpty()) {
                        // Check if it's a plain number/ID
                        if (responseText.matches("\\d+")) {
                            responseId = responseText;
                            System.out.println("Received numeric ID from save API: " + responseId);
                            return responseId;
                        }
                        
                        // If not a plain number, try various JSON formats
                        
                        // Format 1: {"id":"12345"}
                        if (responseText.contains("\"id\"")) {
                            try {
                                int idStartIndex = responseText.indexOf("\"id\"") + 5;
                                int idEndIndex = responseText.indexOf("\"", idStartIndex);
                                if (idStartIndex > 0 && idEndIndex > idStartIndex) {
                                    responseId = responseText.substring(idStartIndex, idEndIndex);
                                    System.out.println("Received ID from save API: " + responseId);
                                }
                            } catch (Exception e) {
                                System.err.println("Error parsing id field: " + e.getMessage());
                            }
                        }
                        
                        // Format 2: {"_id":"12345"}
                        if (responseId.isEmpty() && responseText.contains("\"_id\"")) {
                            try {
                                int idStartIndex = responseText.indexOf("\"_id\"") + 6;
                                int idEndIndex = responseText.indexOf("\"", idStartIndex);
                                if (idStartIndex > 0 && idEndIndex > idStartIndex) {
                                    responseId = responseText.substring(idStartIndex, idEndIndex);
                                    System.out.println("Received _id from save API: " + responseId);
                                }
                            } catch (Exception e) {
                                System.err.println("Error parsing _id field: " + e.getMessage());
                            }
                        }
                        
                        // Format 3: {"data":{"id":"12345"}}
                        if (responseId.isEmpty() && responseText.contains("\"data\"") && responseText.contains("\"id\"")) {
                            try {
                                int dataStart = responseText.indexOf("\"data\"");
                                int idStartIndex = responseText.indexOf("\"id\"", dataStart) + 5;
                                int idEndIndex = responseText.indexOf("\"", idStartIndex);
                                if (idStartIndex > 0 && idEndIndex > idStartIndex) {
                                    responseId = responseText.substring(idStartIndex, idEndIndex);
                                    System.out.println("Received nested ID from save API: " + responseId);
                                }
                            } catch (Exception e) {
                                System.err.println("Error parsing nested id field: " + e.getMessage());
                            }
                        }
                        
                        // If still no ID found, log a warning
                        if (responseId.isEmpty()) {
                            System.err.println("WARNING: Could not extract ID from save API response: " + responseText);
                        }
                    } else {
                        System.err.println("WARNING: Empty response from save API");
                    }
                }
            }
            
            connection.disconnect();
            return responseId;
        } catch (Exception e) {
            System.err.println("Error saving interaction data: " + e.getMessage());
            e.printStackTrace();
            return "";
        }
    }
    
    // Result class to hold response, timing information, and response ID
    public static class ChatResult {
        private final String response;
        private final long timeTaken;
        private final String responseId;
        
        public ChatResult(String response, long timeTaken, String responseId) {
            this.response = response;
            this.timeTaken = timeTaken;
            this.responseId = responseId;
        }
        
        public String getResponse() {
            return response;
        }
        
        public long getTimeTaken() {
            return timeTaken;
        }
        
        public String getResponseId() {
            return responseId;
        }
    }

    // Interface for handling streaming responses
    public interface StreamingResponseHandler {
        void onChunk(String chunk);
        void onComplete(long timeTaken, String responseId);
        void onError(Exception e);
    }

    /**
     * Streams a chat response from the API, delivering chunks as they arrive
     */
    public static void streamChatResponse(String model, String question, String category, 
                                         String sessionId, StreamingResponseHandler handler) {
        // Create a final copy of the question for use in the lambda
        final String questionInput = question;
        
        new Thread(() -> {
            // Record the start time once at the beginning
            long startTime = System.currentTimeMillis();
            StringBuilder fullResponseBuilder = new StringBuilder();
            String responseId = "";
            
            try {
                String endpoint = APIConfig.STREAM_CHAT_ENDPOINT;
                URL url = new URL(endpoint);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
                connection.setDoOutput(true);

                // Sanitize the question inside the lambda
                String sanitizedQuestion = questionInput.replace("\"", "\\\"")
                                             .replace("\n", "\\n")
                                             .replace("\r", "\\r");
                
                // Add stream:true to request streaming response
                String jsonPayload = "{ \"prompt\": \"" + sanitizedQuestion + "\", \"model\": \"" + model + 
                                   "\", \"category\": " + category + ", \"session_id\": \"" + sessionId + 
                                   "\", \"stream\": true }";
                
                System.out.println("Streaming API request payload: " + jsonPayload);
                
                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = jsonPayload.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }

                int responseCode = connection.getResponseCode();
                System.out.println("Streaming API response code: " + responseCode);
                
                if (responseCode == 200) {
                    try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                        String line;
                        
                        while ((line = in.readLine()) != null) {
                            if (line.isEmpty()) continue;
                            
                            if (line.startsWith("data: ")) {
                                String content = line.substring(6); // Remove "data: " prefix
                                if (content.equals("[DONE]")) {
                                    System.out.println("Received [DONE] marker from API");
                                    break;
                                }
                                
                                // Simple string-based parsing instead of using JSONObject
                                try {
                                    // Check if it looks like JSON
                                    if (content.startsWith("{") && content.endsWith("}")) {
                                        // Try to extract text field
                                        String chunkText = extractJsonValue(content, "text");
                                        
                                        // If no text field, try content field
                                        if (chunkText == null) {
                                            chunkText = extractJsonValue(content, "content");
                                        }
                                        
                                        // If we found text content, send it to handler
                                        if (chunkText != null) {
                                            // Add to full response builder
                                            fullResponseBuilder.append(chunkText);
                                            
                                            handler.onChunk(chunkText);
                                            System.out.println("Received streaming chunk: " + 
                                                chunkText.substring(0, Math.min(20, chunkText.length())) + "...");
                                        }
                                        
                                        // Try to extract response_id
                                        String respId = extractJsonValue(content, "response_id");
                                        if (respId != null && responseId.isEmpty()) {
                                            responseId = respId;
                                        }
                                    } else {
                                        // Plain text response
                                        fullResponseBuilder.append(content);
                                        handler.onChunk(content);
                                        System.out.println("Received plain text chunk: " + 
                                            content.substring(0, Math.min(20, content.length())) + "...");
                                    }
                                } catch (Exception e) {
                                    // If parsing fails, just send the raw content
                                    System.out.println("JSON parsing failed, sending raw content");
                                    fullResponseBuilder.append(content);
                                    handler.onChunk(content);
                                }
                            } else {
                                // Not in SSE format, treat as plain text
                                fullResponseBuilder.append(line);
                                handler.onChunk(line);
                                System.out.println("Received non-SSE line: " + 
                                    line.substring(0, Math.min(20, line.length())) + "...");
                            }
                        }
                    }
                    
                    // Calculate the time taken for the entire API call
                    long timeTaken = System.currentTimeMillis() - startTime;
                    System.out.println("Streaming complete in " + timeTaken + "ms, response ID: " + responseId);
                    
                    // If no response ID yet, generate one and save the response
                    if (responseId.isEmpty()) {
                        responseId = generateResponseId(sessionId);
                    }
                    
                    // Save complete response only once at the end
                    String fullResponse = fullResponseBuilder.toString();
                    saveResponse(sessionId, model, questionInput, fullResponse, responseId, timeTaken);
                    
                    // Signal completion to handler with time and ID
                    handler.onComplete(timeTaken, responseId);
                } else {
                    // Handle error
                    StringBuilder errorResponse = new StringBuilder();
                    try (BufferedReader errorReader = new BufferedReader(
                            new InputStreamReader(connection.getErrorStream()))) {
                        String errorLine;
                        while ((errorLine = errorReader.readLine()) != null) {
                            errorResponse.append(errorLine);
                        }
                    }
                    
                    // Create a more detailed error message including HTTP status code
                    String errorMessage = "API returned status code: " + responseCode;
                    if (errorResponse.length() > 0) {
                        errorMessage += ", Error: " + errorResponse.toString();
                    }
                    
                    // Notify handler of HTTP response code
                    notifyHandlerOfStatusCode(handler, responseCode);
                    
                    Exception error = new Exception(errorMessage);
                    System.err.println(error.getMessage());
                    handler.onError(error);
                }
            } catch (Exception e) {
                e.printStackTrace();
                handler.onError(e);
            }
        }).start();
    }
    
    /**
     * Saves the complete API response to the database
     */
    private static void saveResponse(String sessionId, String model, String question, 
                                    String response, String responseId, long timeTaken) {
        try {
            System.out.println("Saving complete response (length: " + response.length() + 
                             ") with ID: " + responseId + ", time taken: " + timeTaken + "ms");
            
            // Make an actual API call to save the response
            String endpoint = APIConfig.HISTORY_ENDPOINT;
            URL url = new URL(endpoint);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Authorization", "Bearer " + APIConfig.API_KEY);
            connection.setDoOutput(true);
            
            // Clean the question and response for JSON
            String cleanedQuestion = question.replace("\"", "\\\"")
                                           .replace("\n", "\\n")
                                           .replace("\r", "\\r");
            
            String cleanedResponse = response.replace("\"", "\\\"")
                                           .replace("\n", "\\n")
                                           .replace("\r", "\\r");
            
            // Use provided time taken instead of calculating
            if (timeTaken <= 0) {
                // Fallback calculation only if no valid time was provided
                try {
                    // Try to extract time from responseId if it has our timestamp format
                    if (responseId.contains("_")) {
                        String[] parts = responseId.split("_");
                        if (parts.length > 1) {
                            String timestampStr = parts[parts.length - 1];
                            try {
                                long timestamp = Long.parseLong(timestampStr);
                                timeTaken = System.currentTimeMillis() - timestamp;
                                if (timeTaken < 0) timeTaken = 0; // Safety check
                            } catch (NumberFormatException nfe) {
                                // Not a timestamp, ignore
                            }
                        }
                    }
                } catch (Exception e) {
                    // Ignore parsing errors
                }
            }
            
            String jsonPayload = String.format(
                "{\"question\": \"%s\", \"answer\": \"%s\", \"time_taken\": %d, \"session\": \"%s\", \"response_id\": \"%s\", \"model\": \"%s\"}",
                cleanedQuestion, cleanedResponse, timeTaken, sessionId, responseId, model
            );
            
            try (OutputStream os = connection.getOutputStream()) {
                byte[] input = jsonPayload.getBytes("utf-8");
                os.write(input, 0, input.length);
            }
            
            int responseCode = connection.getResponseCode();
            System.out.println("Save API response code: " + responseCode);
            
            if (responseCode == 200) {
                // Read the response to extract the new ID
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                    StringBuilder responseBuilder = new StringBuilder();
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        responseBuilder.append(inputLine);
                    }
                    
                    String responseJson = responseBuilder.toString();
                    System.out.println("Save API Response: " + responseJson);
                    
                    // Try to extract ID from the response format:
                    // {"status":"success","result":{"id":id,"timestamp":datetime.now()}}
                    String extractedId = extractSaveResponseId(responseJson);
                    
                    if (extractedId != null && !extractedId.isEmpty()) {
                        System.out.println("Extracted ID from save API response: " + extractedId);
                        
                        // Update the response ID that will be used for feedback
                        responseId = extractedId;
                        
                        // Store this ID in a static variable or pass it up through the chain
                        // This ensures the feedback API uses the correct ID
                        updateResponseIdForFeedback(sessionId, extractedId);
                    } else {
                        System.err.println("Could not extract ID from save API response");
                    }
                }
                System.out.println("Response saved successfully");
            } else {
                System.err.println("Failed to save response: HTTP " + responseCode);
            }
            
            connection.disconnect();
        } catch (Exception e) {
            System.err.println("Error saving response: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Extracts the ID from the save API response
     * Expected format: {"status":"success","result":{"id":id,"timestamp":datetime.now()}}
     */
    private static String extractSaveResponseId(String jsonResponse) {
        try {
            if (jsonResponse == null || jsonResponse.isEmpty()) {
                return null;
            }
            
            // First check if response has the expected structure
            if (jsonResponse.contains("\"status\"") && jsonResponse.contains("\"result\"") && 
                jsonResponse.contains("\"id\"")) {
                
                // First try regex extraction
                java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("\"id\"\\s*:\\s*\"?([^,}\"]+)\"?");
                java.util.regex.Matcher matcher = pattern.matcher(jsonResponse);
                if (matcher.find()) {
                    return matcher.group(1);
                }
                
                // If regex fails, try simpler string-based extraction
                int idIndex = jsonResponse.indexOf("\"id\"");
                if (idIndex > 0) {
                    int valueStart = jsonResponse.indexOf(":", idIndex) + 1;
                    // Skip whitespace
                    while (valueStart < jsonResponse.length() && 
                           Character.isWhitespace(jsonResponse.charAt(valueStart))) {
                        valueStart++;
                    }
                    
                    // Check if value is quoted
                    boolean isQuoted = valueStart < jsonResponse.length() && 
                                      jsonResponse.charAt(valueStart) == '"';
                    
                    int valueEnd;
                    if (isQuoted) {
                        valueStart++; // Skip opening quote
                        valueEnd = jsonResponse.indexOf("\"", valueStart);
                    } else {
                        valueEnd = jsonResponse.indexOf(",", valueStart);
                        if (valueEnd < 0) {
                            valueEnd = jsonResponse.indexOf("}", valueStart);
                        }
                    }
                    
                    if (valueEnd > valueStart) {
                        return jsonResponse.substring(valueStart, valueEnd).trim();
                    }
                }
            }
            
            return null;
        } catch (Exception e) {
            System.err.println("Error extracting ID from save response: " + e.getMessage());
            return null;
        }
    }
    
    // Store response IDs for subsequent feedback
    private static final java.util.Map<String, String> sessionToResponseId = 
            new java.util.HashMap<>();
    
    /**
     * Updates the response ID for a session that will be used for feedback
     */
    public static void updateResponseIdForFeedback(String sessionId, String responseId) {
        sessionToResponseId.put(sessionId, responseId);
        System.out.println("Updated response ID for session " + sessionId + ": " + responseId);
    }
    
    /**
     * Gets the latest response ID for a session
     */
    public static String getResponseIdForSession(String sessionId) {
        return sessionToResponseId.get(sessionId);
    }
    
    /**
     * Generates a unique response ID if one wasn't provided by the API
     */
    private static String generateResponseId(String sessionId) {
        return "resp_" + sessionId + "_" + System.currentTimeMillis();
    }
    
    /**
     * Simple helper method to extract values from JSON strings without requiring a library
     */
    private static String extractJsonValue(String json, String key) {
        // Look for the key pattern: "key": "value" or "key":"value"
        String pattern = "\"" + key + "\"\\s*:\\s*\"([^\"]*)\"";
        java.util.regex.Pattern r = java.util.regex.Pattern.compile(pattern);
        java.util.regex.Matcher m = r.matcher(json);
        
        if (m.find()) {
            return m.group(1);
        }
        
        // Also check for non-string values: "key": value
        pattern = "\"" + key + "\"\\s*:\\s*([^,}\\s][^,}]*)";
        r = java.util.regex.Pattern.compile(pattern);
        m = r.matcher(json);
        
        if (m.find()) {
            String value = m.group(1);
            // Remove any trailing commas
            if (value.endsWith(",")) {
                value = value.substring(0, value.length() - 1);
            }
            return value;
        }
        
        return null;
    }

    /**
     * Helper method to notify the handler of HTTP status code
     */
    private static void notifyHandlerOfStatusCode(StreamingResponseHandler handler, int statusCode) {
        if (handler instanceof AdvancedStreamingResponseHandler) {
            ((AdvancedStreamingResponseHandler) handler).onStatusCode(statusCode);
        }
    }
    
    /**
     * Extended interface that also receives HTTP status codes
     */
    public interface AdvancedStreamingResponseHandler extends StreamingResponseHandler {
        void onStatusCode(int statusCode);
    }
}
