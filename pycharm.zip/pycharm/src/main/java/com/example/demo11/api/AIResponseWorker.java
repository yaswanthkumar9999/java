package com.example.demo11.api;

import com.example.demo11.ui.ChatPanel;
import javax.swing.*;
import java.awt.Component;
import java.awt.Container;
import java.awt.Window;
import java.util.List;

public class AIResponseWorker extends SwingWorker<Void, Object> {
    private final ChatPanel chatPanel;
    private final String userInput;
    private final String model;
    private final String category;
    private final String sessionId;
    private long responseTime;
    private String responseId;

    public AIResponseWorker(ChatPanel chatPanel, String userInput, String model, String category, String sessionId) {
        this.chatPanel = chatPanel;
        this.userInput = userInput;
        this.model = model;
        this.category = category;
        this.sessionId = sessionId;
        this.responseTime = 0;
        this.responseId = "";
    }

    @Override
    protected Void doInBackground() throws Exception {
        try {
            System.out.println("Sending request to API...");
            
            // Use the new method with timing
            APIClient.ChatResult result = APIClient.askQuestionWithTiming(model, userInput, category, sessionId);
            String response = result.getResponse();
            responseTime = result.getTimeTaken();
            responseId = result.getResponseId();
            
            System.out.println("API Response received in " + responseTime + "ms: " + 
                    (response != null ? response.substring(0, Math.min(50, response.length())) + "..." : "null"));
            
            if (response == null || response.trim().isEmpty()) {
                publish("No response received from the API. Please try again.");
                return null;
            }
            
            String[] lines = response.split("\n");
            System.out.println("Split response into " + lines.length + " lines");
            for (String line : lines) {
                publish(line);
                System.out.println("Publishing line: " + line);
            }
            
            // Publish the response info including time and ID
            publish(new ResponseInfo(responseTime, responseId));
            
        } catch (Exception e) {
            e.printStackTrace();
            publish("Error: " + e.getMessage());
            System.err.println("Error in AIResponseWorker: " + e.getMessage());
        }
        return null;
    }

    @Override
    protected void process(List<Object> chunks) {
        System.out.println("Processing " + chunks.size() + " chunks");
        for (Object chunk : chunks) {
            if (chunk instanceof String) {
                System.out.println("Adding to UI: " + chunk);
                chatPanel.addAIResponse((String)chunk);
            } else if (chunk instanceof ResponseInfo) {
                ResponseInfo info = (ResponseInfo)chunk;
                System.out.println("Response time: " + info.getResponseTime() + "ms, ID: " + info.getResponseId());
                
                // Only add feedback UI if we have a valid response ID from save API
                if (info.getResponseId() != null && !info.getResponseId().isEmpty()) {
                    System.out.println("Adding feedback UI with response ID: " + info.getResponseId());
                    chatPanel.addFeedbackUI(info.getResponseId());
                } else {
                    System.out.println("No response ID available, feedback UI will not be shown");
                }
            }
        }
    }
    
    @Override
    protected void done() {
        try {
            get(); // Will re-throw any exception that occurred
            
            // Re-enable the input field using the static reference
            SwingUtilities.invokeLater(() -> {
                // Try to find InputPanel through various methods
                System.out.println("Trying to re-enable input field...");
                
                // First, try using the static reference
                com.example.demo11.ui.InputPanel inputPanel = com.example.demo11.SidepanelFactory.getCurrentInputPanel();
                if (inputPanel != null) {
                    System.out.println("Found InputPanel through static reference, re-enabling input...");
                    inputPanel.setInputEnabled(true);
                    return;
                }
                
                // If static reference fails, try finding through parent hierarchy
                Component parent = chatPanel.getParent();
                if (parent != null) {
                    System.out.println("Found parent container, looking for InputPanel...");
                    // Look for the InputPanel in the same container as the ChatPanel
                    if (parent instanceof Container) {
                        Container container = (Container) parent;
                        boolean found = false;
                        for (Component component : container.getComponents()) {
                            if (component instanceof com.example.demo11.ui.InputPanel) {
                                System.out.println("InputPanel found, re-enabling input...");
                                ((com.example.demo11.ui.InputPanel)component).setInputEnabled(true);
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            System.out.println("WARNING: InputPanel not found in container. Components: " + container.getComponentCount());
                            // Try using the original method as fallback
                            Component current = chatPanel;
                            while (current != null) {
                                current = current.getParent();
                                if (current instanceof com.example.demo11.ui.InputPanel) {
                                    System.out.println("Found InputPanel via parent hierarchy instead");
                                    ((com.example.demo11.ui.InputPanel)current).setInputEnabled(true);
                                    break;
                                }
                            }
                        }
                    } else {
                        System.out.println("WARNING: ChatPanel parent is not a Container");
                    }
                } else {
                    System.out.println("WARNING: ChatPanel parent is null, cannot find InputPanel through hierarchy");
                    System.out.println("Trying fallback options...");
                    
                    // Last resort: Try to find all InputPanel instances
                    findAndEnableInputPanels();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            chatPanel.addAIResponse("Error: " + e.getMessage());
            System.err.println("Error in done(): " + e.getMessage());
            
            // Re-enable input even if there was an error
            SwingUtilities.invokeLater(() -> {
                System.out.println("Enabling input after error...");
                
                // Try static reference first
                com.example.demo11.ui.InputPanel inputPanel = com.example.demo11.SidepanelFactory.getCurrentInputPanel();
                if (inputPanel != null) {
                    System.out.println("Found InputPanel through static reference after error, re-enabling input...");
                    inputPanel.setInputEnabled(true);
                    return;
                }
                
                // Fallback to hierarchy search
                Component parent = chatPanel.getParent();
                if (parent != null && parent instanceof Container) {
                    // Look for the InputPanel in the same container as the ChatPanel
                    Container container = (Container) parent;
                    boolean found = false;
                    for (Component component : container.getComponents()) {
                        if (component instanceof com.example.demo11.ui.InputPanel) {
                            System.out.println("InputPanel found after error, re-enabling input...");
                            ((com.example.demo11.ui.InputPanel)component).setInputEnabled(true);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        System.out.println("WARNING: InputPanel not found after error, trying fallback...");
                        findAndEnableInputPanels();
                    }
                } else {
                    System.out.println("WARNING: ChatPanel parent is invalid after error, trying fallback...");
                    findAndEnableInputPanels();
                }
            });
        }
    }
    
    // Helper method to find all InputPanel instances in the window hierarchy
    private void findAndEnableInputPanels() {
        System.out.println("Searching all windows for InputPanel instances...");
        for (Window window : Window.getWindows()) {
            findInputPanelInWindow(window);
        }
    }
    
    // Recursively search for InputPanel in a window
    private void findInputPanelInWindow(Container container) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof com.example.demo11.ui.InputPanel) {
                System.out.println("Found InputPanel in window hierarchy, enabling...");
                ((com.example.demo11.ui.InputPanel) comp).setInputEnabled(true);
                return;
            }
            
            if (comp instanceof Container) {
                findInputPanelInWindow((Container) comp);
            }
        }
    }
    
    // Inner class to track response information
    private static class ResponseInfo {
        private final long responseTime;
        private final String responseId;
        
        public ResponseInfo(long responseTime, String responseId) {
            this.responseTime = responseTime;
            this.responseId = responseId;
        }
        
        public long getResponseTime() {
            return responseTime;
        }
        
        public String getResponseId() {
            return responseId;
        }
    }
}
