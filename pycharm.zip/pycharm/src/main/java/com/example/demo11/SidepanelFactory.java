package com.example.demo11;

import com.example.demo11.ui.APIKeyValidationDialog;
import com.example.demo11.ui.ChatPanel;
import com.example.demo11.ui.HeaderPanel;
import com.example.demo11.ui.InputPanel;
import com.example.demo11.api.SessionHistoryWorker;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowFactory;
import com.intellij.ui.content.Content;
import com.intellij.ui.content.ContentFactory;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.awt.*;

public class SidepanelFactory implements ToolWindowFactory {
    private static String sessionId; // Persistent session ID
    // Add a static reference to the InputPanel
    private static InputPanel currentInputPanel;

    @Override
    public void createToolWindowContent(@NotNull Project project, @NotNull ToolWindow toolWindow) {
        // Show API Key Validation Dialog
        JFrame parentFrame = new JFrame();
        APIKeyValidationDialog dialog = new APIKeyValidationDialog(parentFrame);
        if (!dialog.isValidApiKey()) {
            return; // Exit if API Key is invalid
        }

        // Generate session ID once per session
        sessionId = SessionHistoryWorker.generateSessionID(com.example.demo11.config.APIConfig.API_KEY);

        JPanel mainPanel = new JPanel(new BorderLayout());

        // Create chat panel first.
        ChatPanel chatPanel = new ChatPanel();
        // Create header panel with references to factory and chatPanel.
        HeaderPanel headerPanel = new HeaderPanel(this, chatPanel);
        // Create input panel now and pass the header panel.
        InputPanel inputPanel = new InputPanel(chatPanel, headerPanel, this);
        // Store the input panel reference
        currentInputPanel = inputPanel;
        // Let header panel know about the input panel (for refresh action).
        headerPanel.setInputPanel(inputPanel);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(chatPanel.getScrollPane(), BorderLayout.CENTER);
        mainPanel.add(inputPanel, BorderLayout.SOUTH);

        Content content = ContentFactory.getInstance().createContent(mainPanel, "", false);
        toolWindow.getContentManager().addContent(content);
    }

    // Called when the refresh button is pressed in HeaderPanel.
    public void resetSession(InputPanel inputPanel, ChatPanel chatPanel) {
        sessionId = SessionHistoryWorker.generateSessionID(com.example.demo11.config.APIConfig.API_KEY);
        chatPanel.clearChat(); // Clear previous chat messages (make sure this method exists in ChatPanel)
        inputPanel.setSessionId(sessionId); // Update InputPanel with new session ID
        // Update the static reference
        currentInputPanel = inputPanel;
    }

    public static String getSessionId() {
        return sessionId;
    }
    
    // Getter for the InputPanel
    public static InputPanel getCurrentInputPanel() {
        return currentInputPanel;
    }
}
