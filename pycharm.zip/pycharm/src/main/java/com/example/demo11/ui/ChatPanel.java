package com.example.demo11.ui;

import com.example.demo11.utils.RoundedBorder;
import com.intellij.openapi.util.IconLoader;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.Border;
import java.util.ArrayList;
import java.util.List;

public class ChatPanel extends JPanel {
    private final JPanel messageContainer;
    private final JScrollPane scrollPane;
    private static final int MIN_BUBBLE_WIDTH = 180;
    private static final double BUBBLE_WIDTH_PERCENT = 0.8; // Use percentage of panel width
    
    // Track message bubbles for updating when resized
    private final List<JPanel> messageBubbles = new ArrayList<>();
    
    // Track the currently selected bubble
    private JPanel selectedBubble = null;
    private final Color selectedColor = new Color(51, 153, 255); // Blue color for selection
    private final Color defaultBorderColor = new Color(169, 169, 169); // Default grey border

    // Colors for star rating
    private final Color starDefaultColor = Color.WHITE;
    private final Color starHoverColor = new Color(255, 215, 0); // Gold
    private final Color feedbackButtonColor = new Color(51, 153, 255); // Blue

    public ChatPanel() {
        setLayout(new BorderLayout());
        messageContainer = new JPanel();
        messageContainer.setLayout(new BoxLayout(messageContainer, BoxLayout.Y_AXIS));
        messageContainer.setOpaque(false);

        scrollPane = new JScrollPane(messageContainer);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        // Ensure scrolling works properly
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getVerticalScrollBar().setBlockIncrement(64);

        // Add component listener to handle resize events
        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                updateAllBubbleSizes();
                refreshChat();
            }
        });

        add(scrollPane, BorderLayout.CENTER);
    }

    private void updateAllBubbleSizes() {
        // Calculate new bubble width based on current panel width
        int panelWidth = getWidth();
        if (panelWidth <= 0) return; // Skip if panel not visible yet
        
        for (JPanel wrapper : messageBubbles) {
            if (wrapper.getComponentCount() > 0) {
                Component bubbleComp = wrapper.getComponent(0);
                if (bubbleComp instanceof JPanel) {
                    JPanel bubblePanel = (JPanel)bubbleComp;
                    
                    // Get the text area to determine appropriate width
                    JTextArea textArea = findTextArea(bubblePanel);
                    if (textArea != null) {
                        String message = textArea.getText();
                        int messageLength = message.length();
                        
                        // Calculate new bubble width based on panel size and message length
                        double widthFactor = Math.min(0.8, Math.max(0.3, messageLength / 100.0));
                        int bubbleWidth = Math.min((int)(panelWidth * widthFactor), calculateBubbleWidth(panelWidth));
                        bubbleWidth = Math.max(bubbleWidth, Math.min(MIN_BUBBLE_WIDTH, messageLength * 8));
                        
                        // Update bubble size
                        bubblePanel.setMaximumSize(new Dimension(bubbleWidth, Integer.MAX_VALUE));
                        
                        // Calculate new text area width
                        int textAreaWidth = bubbleWidth - 20;
                        int columns = Math.max(10, textAreaWidth / 8);
                        
                        // Update text area constraints
                        textArea.setColumns(columns);
                        
                        // Update parent containers (scroll pane, content panel)
                        Component parent = textArea.getParent().getParent(); // Skip scroll pane to get to content panel
                        if (parent instanceof JPanel) {
                            JPanel contentPanel = (JPanel) parent;
                            contentPanel.setPreferredSize(new Dimension(textAreaWidth, contentPanel.getPreferredSize().height));
                        }
                    }
                }
            }
        }
        
        // Force layout updates
        messageContainer.revalidate();
        messageContainer.repaint();
    }
    
    private JTextArea findTextArea(JPanel panel) {
        // Search in nested components for the text area
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JPanel) {
                for (Component innerComp : ((JPanel)comp).getComponents()) {
                    if (innerComp instanceof JScrollPane) {
                        JScrollPane scrollPane = (JScrollPane)innerComp;
                        Component view = scrollPane.getViewport().getView();
                        if (view instanceof JTextArea) {
                            return (JTextArea)view;
                        }
                    }
                }
            }
        }
        return null;
    }
    
    private int calculateBubbleWidth(int panelWidth) {
        // Calculate width as a percentage of panel width
        int calculatedWidth = (int)(panelWidth * BUBBLE_WIDTH_PERCENT);
        return Math.max(calculatedWidth, MIN_BUBBLE_WIDTH);
    }

    public void addUserMessage(String message) {
        addMessageBubble("You", "/icons/you.png", message, true);
    }

    public void addAIResponse(String message) {
        addMessageBubble("Assistant", "/icons/assistant.png", message, false);
    }

    private void addMessageBubble(String sender, String iconPath, String message, boolean isUser) {
        JPanel bubble = createMessageBubble(sender, iconPath, message, isUser);
        
        // Use a centered layout to keep bubbles aligned in the center
        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.add(bubble, BorderLayout.CENTER); // Center alignment for all bubbles
        wrapper.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        // Add to tracking list
        messageBubbles.add(wrapper);
        
        messageContainer.add(wrapper);
        messageContainer.add(Box.createVerticalStrut(5));
        refreshChat();
    }

    private JPanel createMessageBubble(String sender, String iconPath, String message, boolean isUser) {
        JPanel bubblePanel = new JPanel();
        bubblePanel.setLayout(new BoxLayout(bubblePanel, BoxLayout.Y_AXIS));
        
        // Use grey border for both user and assistant bubbles
        bubblePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(defaultBorderColor, 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        bubblePanel.setOpaque(false);
        
        // Add click listener to handle selection
        MouseAdapter clickListener = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectBubble(bubblePanel);
            }
        };
        
        // Add click listener to the main bubble panel
        bubblePanel.addMouseListener(clickListener);
        
        // Calculate dynamic bubble width based on panel width AND message length
        int panelWidth = getWidth();
        if (panelWidth <= 0) panelWidth = 300; // Smaller fallback width
        
        // More aggressive width scaling for small messages
        int messageLength = message.length();
        
        // Calculate base width based on text length (approximately 7 pixels per character)
        int baseWidth = Math.max(100, messageLength * 7);
        
        // Calculate maximum allowed width (40% of panel width for short messages)
        int maxWidth = (int)(panelWidth * 0.4);
        
        // For longer messages, allow up to 80% of panel width
        if (messageLength > 100) {
            maxWidth = (int)(panelWidth * 0.8);
        }
        
        // Set bubble width to the smaller of base width and max width
        int bubbleWidth = Math.min(baseWidth, maxWidth);
        
        // Ensure minimum width
        bubbleWidth = Math.max(bubbleWidth, 100);
        
        // Set width constraints - no height constraints
        bubblePanel.setPreferredSize(null);
        bubblePanel.setMaximumSize(new Dimension(bubbleWidth, Integer.MAX_VALUE));
        
        // Centered alignment
        bubblePanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Load icon
        Icon icon = IconLoader.getIcon(iconPath);
        if (icon == null) {
            icon = UIManager.getIcon("OptionPane.informationIcon");
        }

        // Sender panel with icon
        JPanel senderPanel = new JPanel(new BorderLayout());
        senderPanel.setOpaque(false);
        senderPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        senderPanel.addMouseListener(clickListener); // Add click listener to sender panel
        
        // Use blue color for assistant's name, keep user color as is
        Color nameColor = isUser ? new Color(70, 130, 180) : new Color(0, 102, 204); // Royal blue for assistant
        JLabel senderLabel = new JLabel(sender, icon, isUser ? JLabel.LEFT : JLabel.RIGHT);
        senderLabel.setForeground(nameColor);
        senderLabel.setFont(new Font("Dialog", Font.BOLD, 12));
        senderLabel.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
        senderLabel.addMouseListener(clickListener); // Add click listener to sender label
        
        // Add sender to panel - position varies by sender
        if (isUser) {
            senderPanel.add(senderLabel, BorderLayout.WEST);
        } else {
            senderPanel.add(senderLabel, BorderLayout.EAST);
        }

        // Calculate width for text area with minimal padding
        int textAreaWidth = bubbleWidth - 10;
        
        // Use ScrollPane + JTextArea for text that adjusts to width
        JTextArea textArea = new JTextArea(message);
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setFont(new Font("Arial", Font.PLAIN, 14));
        textArea.setBackground(new Color(0, 0, 0, 0));
        textArea.setForeground(Color.WHITE);
        textArea.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
        textArea.setOpaque(false);
        textArea.addMouseListener(clickListener); // Add click listener to text area
        
        // Calculate columns based on text width
        int columns = Math.max(5, textAreaWidth / 8);
        textArea.setColumns(columns);
        
        // Calculate rows based on text length and columns
        int charPerLine = Math.max(1, columns - 1);
        int lines = (int)Math.ceil((double)messageLength / charPerLine);
        textArea.setRows(Math.min(10, Math.max(1, lines)));
        
        // Wrap in scroll pane for overflow
        JScrollPane textScrollPane = new JScrollPane(textArea);
        textScrollPane.setBorder(BorderFactory.createEmptyBorder());
        textScrollPane.setOpaque(false);
        textScrollPane.getViewport().setOpaque(false);
        textScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        textScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        textScrollPane.addMouseListener(clickListener); // Add click listener to scroll pane
        
        // Content panel with minimal padding
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(3, 3, 3, 3));
        contentPanel.add(textScrollPane, BorderLayout.CENTER);
        contentPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        contentPanel.addMouseListener(clickListener); // Add click listener to content panel
        
        // Set width to match bubble
        contentPanel.setPreferredSize(new Dimension(textAreaWidth, contentPanel.getPreferredSize().height));

        bubblePanel.add(senderPanel);
        bubblePanel.add(contentPanel);
        
        return bubblePanel;
    }

    private void refreshChat() {
        // Force layout update
        messageContainer.revalidate();
        messageContainer.repaint();
        
        // Adjust scrollbar visibility
        boolean needsScroll = messageContainer.getPreferredSize().height > scrollPane.getViewport().getHeight();
        scrollPane.setVerticalScrollBarPolicy(needsScroll ? 
            ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS : 
            ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        
        // Scroll to bottom
        SwingUtilities.invokeLater(() -> {
            try {
                JScrollBar vertical = scrollPane.getVerticalScrollBar();
                vertical.setValue(vertical.getMaximum());
                System.out.println("Container height: " + messageContainer.getPreferredSize().height + 
                                 ", Viewport height: " + scrollPane.getViewport().getHeight() +
                                 ", Scrollbar visible: " + needsScroll);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public JScrollPane getScrollPane() {
        return scrollPane;
    }

    public void clearChat() {
        messageContainer.removeAll();
        messageBubbles.clear(); // Clear tracked bubbles
        messageContainer.revalidate();
        messageContainer.repaint();
    }
    
    /**
     * Handles selection of a message bubble.
     * Changes the border color to blue for the selected bubble and
     * restores the original grey color for any previously selected bubble.
     *
     * @param bubble The bubble panel to select
     */
    private void selectBubble(JPanel bubble) {
        // If the same bubble is clicked again, do nothing
        if (bubble == selectedBubble) {
            return;
        }
        
        // Reset previous selection if any
        if (selectedBubble != null) {
            selectedBubble.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(defaultBorderColor, 1),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));
        }
        
        // Update new selection
        bubble.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(selectedColor, 2), // Make blue border slightly thicker
            BorderFactory.createEmptyBorder(4, 4, 4, 4)      // Adjust inner padding to maintain size
        ));
        
        // Update selected bubble reference
        selectedBubble = bubble;
        
        // Refresh display
        messageContainer.revalidate();
        messageContainer.repaint();
    }

    /**
     * Adds a feedback UI (star rating and comment button) after an AI response
     * 
     * @param responseId The ID of the response for which feedback is being collected
     */
    public void addFeedbackUI(String responseId) {
        JPanel feedbackPanel = new JPanel();
        feedbackPanel.setLayout(new BoxLayout(feedbackPanel, BoxLayout.Y_AXIS));
        feedbackPanel.setOpaque(false);
        feedbackPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));
        feedbackPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Create a panel for the feedback label and stars
        JPanel ratingPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        ratingPanel.setOpaque(false);
        
        // Add feedback label
        JLabel feedbackLabel = new JLabel("Feedback:");
        feedbackLabel.setFont(new Font("Arial", Font.BOLD, 12));
        ratingPanel.add(feedbackLabel);
        
        // Add star ratings (1-5 stars)
        JLabel[] stars = new JLabel[5];
        for (int i = 0; i < 5; i++) {
            final int rating = i + 1;
            stars[i] = createStarLabel(rating, responseId);
            ratingPanel.add(stars[i]);
        }
        
        // Create comment button
        JButton commentButton = new JButton();
        
        // Try to load from resources
        Icon commentIcon = IconLoader.getIcon("/icons/comment.svg");
        if (commentIcon == null) {
            // Try PNG as backup
            commentIcon = IconLoader.getIcon("/icons/copy_icon.png"); // Placeholder - use copy icon if comment icon not found
        }
        
        if (commentIcon != null) {
            commentButton.setIcon(commentIcon);
        } else {
            commentButton.setText("💬"); // Fallback to emoji if icon not found
        }
        
        commentButton.setToolTipText("Add Comment");
        commentButton.setBorderPainted(false);
        commentButton.setContentAreaFilled(false);
        commentButton.setFocusPainted(false);
        commentButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add a separate panel for the comment button to align it properly
        JPanel commentButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        commentButtonPanel.setOpaque(false);
        commentButtonPanel.add(commentButton);
        
        // Create a panel for the entire rating row (stars + comment button)
        JPanel ratingRow = new JPanel(new BorderLayout());
        ratingRow.setOpaque(false);
        ratingRow.add(ratingPanel, BorderLayout.WEST);
        ratingRow.add(commentButtonPanel, BorderLayout.EAST);
        
        // Add rating row to the feedback panel
        feedbackPanel.add(ratingRow);
        
        // Create a hidden comment panel
        JPanel commentPanel = new JPanel();
        commentPanel.setLayout(new BoxLayout(commentPanel, BoxLayout.Y_AXIS));
        commentPanel.setOpaque(false);
        commentPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createDashedBorder(Color.GRAY, 1, 3, 1, false),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        commentPanel.setVisible(false);
        
        // Add "Write a feedback" label
        JLabel commentLabel = new JLabel("Write a feedback");
        commentLabel.setFont(new Font("Arial", Font.ITALIC, 12));
        commentLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        commentPanel.add(commentLabel);
        commentPanel.add(Box.createVerticalStrut(5));
        
        // Create the comment text area
        JTextArea commentTextArea = new JTextArea(3, 20);
        commentTextArea.setLineWrap(true);
        commentTextArea.setWrapStyleWord(true);
        commentTextArea.setBorder(BorderFactory.createLineBorder(feedbackButtonColor));
        JScrollPane commentScrollPane = new JScrollPane(commentTextArea);
        commentScrollPane.setAlignmentX(Component.LEFT_ALIGNMENT);
        commentPanel.add(commentScrollPane);
        commentPanel.add(Box.createVerticalStrut(5));
        
        // Create button panel for submit and cancel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
        
        // Create submit button
        JButton submitButton = new JButton("Submit");
        submitButton.setBackground(feedbackButtonColor);
        submitButton.setForeground(Color.WHITE);
        submitButton.setFocusPainted(false);
        
        // Create cancel button
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setFocusPainted(false);
        
        // Add buttons to button panel
        buttonPanel.add(submitButton);
        buttonPanel.add(cancelButton);
        
        commentPanel.add(buttonPanel);
        
        // Submit button action
        submitButton.addActionListener(e -> {
            String comment = commentTextArea.getText();
            if (!comment.trim().isEmpty()) {
                submitFeedbackComment(responseId, comment);
                commentPanel.setVisible(false);
                commentTextArea.setText("");
                feedbackPanel.revalidate();
                feedbackPanel.repaint();
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(e -> {
            commentPanel.setVisible(false);
            commentTextArea.setText("");
            feedbackPanel.revalidate();
            feedbackPanel.repaint();
        });
        
        // Add comment panel to feedback panel
        feedbackPanel.add(commentPanel);
        
        // Add click listener to comment button
        commentButton.addActionListener(e -> {
            commentPanel.setVisible(!commentPanel.isVisible());
            feedbackPanel.revalidate();
            feedbackPanel.repaint();
            
            // Scroll to make comment panel visible if it's shown
            if (commentPanel.isVisible()) {
                SwingUtilities.invokeLater(() -> {
                    Rectangle bounds = commentPanel.getBounds();
                    scrollPane.getViewport().scrollRectToVisible(bounds);
                });
            }
        });
        
        // Add feedback panel to the message container
        messageContainer.add(feedbackPanel);
        messageContainer.revalidate();
        messageContainer.repaint();
        
        // Scroll to show the feedback UI
        SwingUtilities.invokeLater(this::refreshChat);
    }
    
    /**
     * Creates a star label with hover effects for the rating
     */
    private JLabel createStarLabel(int rating, String responseId) {
        JLabel star = new JLabel();
        
        // Try to load star icons
        Icon emptyStarIcon = IconLoader.getIcon("/icons/empty_star.png");
        Icon filledStarIcon = IconLoader.getIcon("/icons/filled_star.png");
        
        if (emptyStarIcon != null && filledStarIcon != null) {
            star.setIcon(emptyStarIcon);
        } else {
            // Fallback to text if icons not found
            star.setText("★");
            star.setFont(new Font("Arial", Font.BOLD, 16));
            star.setForeground(starDefaultColor);
        }
        
        star.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Add hover effect
        star.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (emptyStarIcon != null && filledStarIcon != null) {
                    star.setIcon(filledStarIcon);
                } else {
                    star.setForeground(starHoverColor);
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                if (emptyStarIcon != null && filledStarIcon != null) {
                    if (star.getClientProperty("filled") == null || 
                        !((Boolean)star.getClientProperty("filled"))) {
                        star.setIcon(emptyStarIcon);
                    }
                } else {
                    star.setForeground(starDefaultColor);
                }
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                submitStarRating(responseId, rating);
                
                // Set all stars up to this one to gold/filled
                Container parent = star.getParent();
                for (int i = 0; i < parent.getComponentCount(); i++) {
                    Component c = parent.getComponent(i);
                    if (c instanceof JLabel) {
                        JLabel starLabel = (JLabel)c;
                        
                        if (emptyStarIcon != null && filledStarIcon != null) {
                            // Handle icon stars
                            if (i <= parent.getComponentZOrder(star)) {
                                starLabel.setIcon(filledStarIcon);
                                starLabel.putClientProperty("filled", true);
                            } else {
                                starLabel.setIcon(emptyStarIcon);
                                starLabel.putClientProperty("filled", false);
                            }
                        } else {
                            // Handle text stars
                            if (i <= parent.getComponentZOrder(star)) {
                                starLabel.setForeground(starHoverColor);
                            } else {
                                starLabel.setForeground(starDefaultColor);
                            }
                        }
                    }
                }
            }
        });
        
        return star;
    }
    
    /**
     * Submits a star rating to the backend
     */
    private void submitStarRating(String responseId, int rating) {
        System.out.println("Submitting rating " + rating + " for response ID: " + responseId);
        com.example.demo11.utils.FeedbackManager.submitRating(responseId, rating);
    }
    
    /**
     * Submits a feedback comment to the backend
     */
    private void submitFeedbackComment(String responseId, String comment) {
        System.out.println("Submitting comment for response ID: " + responseId + ": " + comment);
        com.example.demo11.utils.FeedbackManager.submitComment(responseId, comment);
    }
}
