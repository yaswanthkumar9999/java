package com.example.demo11.ui;

import com.example.demo11.SidepanelFactory;
import com.intellij.openapi.util.IconLoader;
import javax.swing.*;
import java.awt.*;

public class HeaderPanel extends JPanel {
    private JComboBox<String> modelComboBox;
    private JButton refreshButton;
    private SidepanelFactory factory;
    private ChatPanel chatPanel;
    private InputPanel inputPanel; // Will be set later

    public HeaderPanel(SidepanelFactory factory, ChatPanel chatPanel) {
        this.factory = factory;
        this.chatPanel = chatPanel;

        setLayout(new BorderLayout());
        // Add border to the entire header panel
        setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 1));
        setBackground(Color.DARK_GRAY);

        // Left panel for model selection.
        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        leftPanel.setOpaque(false);
        JLabel modelLabel = new JLabel("Model: ");
        modelLabel.setForeground(Color.WHITE);
        modelComboBox = new JComboBox<>(new String[]{"Professional", "Simple"});
        leftPanel.add(modelLabel);
        leftPanel.add(modelComboBox);

        // Right panel with refresh button.
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.setOpaque(false);
        refreshButton = new JButton(IconLoader.getIcon("/icons/refresh.png"));
        refreshButton.setToolTipText("Start New Chat");
        refreshButton.setFocusPainted(false);
        refreshButton.setBorderPainted(false);
        refreshButton.setContentAreaFilled(false);
        refreshButton.setOpaque(false);
        rightPanel.add(refreshButton);

        // Refresh button action: calls factory.resetSession with inputPanel and chatPanel.
        refreshButton.addActionListener(e -> {
            if (inputPanel != null && chatPanel != null) {
                factory.resetSession(inputPanel, chatPanel);
            }
        });

        add(leftPanel, BorderLayout.WEST);
        add(rightPanel, BorderLayout.EAST);
    }

    public JComboBox<String> getModelComboBox() {
        return modelComboBox;
    }

    public void setInputPanel(InputPanel inputPanel) {
        this.inputPanel = inputPanel;
    }
}
