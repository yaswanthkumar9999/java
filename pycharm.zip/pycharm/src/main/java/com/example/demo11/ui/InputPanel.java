package com.example.demo11.ui;

import com.example.demo11.api.AIResponseWorker;
import com.example.demo11.api.SessionHistoryWorker;
import com.example.demo11.config.APIConfig;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class InputPanel extends JPanel {
    private JTextArea inputTextArea;
    private JButton submitButton;
    private String sessionId;
    private static final String PLACEHOLDER_TEXT = "Ask a question...";
    private DocumentListener documentListener;
    // Store the original background color
    private Color originalBackgroundColor;

    public InputPanel(ChatPanel chatPanel, HeaderPanel headerPanel, com.example.demo11.SidepanelFactory factory) {
        setLayout(new BorderLayout(5, 0)); // Add horizontal gap
        setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // Create text area with placeholder and improved responsiveness
        inputTextArea = new JTextArea(1, 30);
        inputTextArea.setText(PLACEHOLDER_TEXT);
        inputTextArea.setForeground(Color.GRAY);
        inputTextArea.setWrapStyleWord(true);
        inputTextArea.setLineWrap(true);
        inputTextArea.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.GRAY),
            BorderFactory.createEmptyBorder(3, 5, 3, 5)
        ));
        inputTextArea.setFont(new Font("Arial", Font.PLAIN, 14));
        
        // Store the original background color after initial setup
        originalBackgroundColor = inputTextArea.getBackground();
        System.out.println("Original background color: " + originalBackgroundColor);
        
        // Create scroll pane for the text area
        JScrollPane scrollPane = new JScrollPane(inputTextArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null); // Remove scroll pane border
        scrollPane.getViewport().setBackground(inputTextArea.getBackground());
        
        // Set fixed preferred height for the scroll pane
        scrollPane.setPreferredSize(new Dimension(300, 30));
        
        // Add component listener for dynamic resizing
        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                int width = getWidth();
                scrollPane.setPreferredSize(new Dimension(width - 100, 30));
                revalidate();
            }
        });

        // Add focus listener for placeholder behavior
        inputTextArea.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                if (inputTextArea.getText().equals(PLACEHOLDER_TEXT)) {
                    inputTextArea.setText("");
                    inputTextArea.setForeground(Color.WHITE);
                }
            }
            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                if (inputTextArea.getText().trim().isEmpty()) {
                    inputTextArea.setText(PLACEHOLDER_TEXT);
                    inputTextArea.setForeground(Color.GRAY);
                }
            }
        });

        // Replace KeyListener with KeyBinding for better Enter key handling
        InputMap inputMap = inputTextArea.getInputMap(JComponent.WHEN_FOCUSED);
        ActionMap actionMap = inputTextArea.getActionMap();
        
        // Remove the default Enter key binding
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "submit");
        actionMap.put("submit", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                submitQuestion(chatPanel, headerPanel);
            }
        });
        
        // Allow Shift+Enter for new line
        inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, KeyEvent.SHIFT_DOWN_MASK), "insert-break");

        // Create the submit button with improved styling - fully blue
        submitButton = new JButton("Ask AI") {
            @Override
            protected void paintComponent(Graphics g) {
                if (!isEnabled()) {
                    g.setColor(new Color(100, 150, 200, 150)); // Light blue when disabled
                } else {
                    g.setColor(new Color(30, 144, 255)); // Full blue when enabled
                }
                g.fillRect(0, 0, getWidth(), getHeight()); // Fill the entire button
                
                // Set up text drawing
                FontMetrics fm = g.getFontMetrics();
                int textWidth = fm.stringWidth(getText());
                int textHeight = fm.getHeight();
                
                // Draw text in white
                g.setColor(Color.WHITE);
                g.drawString(getText(), (getWidth() - textWidth) / 2, 
                             (getHeight() - textHeight) / 2 + fm.getAscent());
            }
        };
        submitButton.setFont(new Font("Arial", Font.BOLD, 14));
        submitButton.setEnabled(false);
        submitButton.setContentAreaFilled(false);
        submitButton.setBorderPainted(false);
        submitButton.setFocusPainted(false);
        submitButton.setOpaque(true);
        submitButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        submitButton.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        submitButton.setPreferredSize(new Dimension(80, 30));

        // Enable/disable the button based on document changes
        documentListener = new DocumentListener() {
            private void updateButtonState() {
                String text = inputTextArea.getText().trim();
                submitButton.setEnabled(!text.isEmpty() && !text.equals(PLACEHOLDER_TEXT));
            }
            @Override
            public void insertUpdate(DocumentEvent e) { updateButtonState(); }
            @Override
            public void removeUpdate(DocumentEvent e) { updateButtonState(); }
            @Override
            public void changedUpdate(DocumentEvent e) { updateButtonState(); }
        };
        inputTextArea.getDocument().addDocumentListener(documentListener);

        // Add components with proper layout
        JPanel inputContainer = new JPanel(new BorderLayout(5, 0));
        inputContainer.add(scrollPane, BorderLayout.CENTER);
        inputContainer.add(submitButton, BorderLayout.EAST);
        add(inputContainer, BorderLayout.CENTER);

        // Generate session ID once (using the API key set previously)
        sessionId = SessionHistoryWorker.generateSessionID(APIConfig.API_KEY);
        System.out.println("Session ID: " + sessionId); // For debugging

        // Add action listener for the submit button
        submitButton.addActionListener(e -> submitQuestion(chatPanel, headerPanel));
    }

    private void submitQuestion(ChatPanel chatPanel, HeaderPanel headerPanel) {
        String question = inputTextArea.getText().trim();
        if (!question.isEmpty() && !question.equals(PLACEHOLDER_TEXT)) {
            // Disable input while waiting for response
            System.out.println("Disabling input before sending question to API...");
            setInputEnabled(false);
            
            // Submit the question.
            chatPanel.addUserMessage(question);
            String model = headerPanel.getModelComboBox().getSelectedItem().toString();
            String category = "2"; // Fixed category
            
            // Create and execute the worker to handle the response
            AIResponseWorker worker = new AIResponseWorker(chatPanel, question, model, category, sessionId);
            worker.execute();
            
            // Reset text field to empty first, then set placeholder when focus is lost
            inputTextArea.setText("");
            inputTextArea.setForeground(Color.WHITE);
            
            // Add a small delay before resetting to placeholder to allow focus events to process
            SwingUtilities.invokeLater(() -> {
                if (inputTextArea.getText().trim().isEmpty() && !inputTextArea.hasFocus()) {
                    inputTextArea.setText(PLACEHOLDER_TEXT);
                    inputTextArea.setForeground(Color.GRAY);
                }
            });
        } else {
            // Just clear if it was the placeholder text
            inputTextArea.setText("");
            inputTextArea.setForeground(Color.WHITE);
        }
    }

    /**
     * Enables or disables the input field and submit button
     * @param enabled true to enable, false to disable
     */
    public void setInputEnabled(boolean enabled) {
        System.out.println("InputPanel.setInputEnabled(" + enabled + ") called");
        inputTextArea.setEnabled(enabled);
        submitButton.setEnabled(enabled);
        
        // Update visual appearance when disabled
        if (!enabled) {
            System.out.println("Disabling input field and changing appearance...");
            inputTextArea.setBackground(new Color(50, 50, 50)); // Darker background when disabled
            inputTextArea.setForeground(Color.GRAY);
            // Disable the document listener temporarily
            inputTextArea.getDocument().removeDocumentListener(documentListener);
        } else {
            System.out.println("Enabling input field and restoring appearance...");
            // Use the original background color instead of black
            inputTextArea.setBackground(originalBackgroundColor);
            // Restore text color based on whether it's placeholder or not
            if (inputTextArea.getText().equals(PLACEHOLDER_TEXT)) {
                inputTextArea.setForeground(Color.GRAY);
            } else {
                inputTextArea.setForeground(Color.WHITE);
            }
            // Re-enable the document listener
            inputTextArea.getDocument().addDocumentListener(documentListener);
        }
    }

    // Called from factory on refresh.
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
}
